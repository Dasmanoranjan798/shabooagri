--
-- PostgreSQL database dump
--

\restrict jNvvFfsAMaCrqyy0hjZwcIbKuDF4qiPpKBhMNJUfUdSdGcVBb5FQ9txXun5ZLl8

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AvailabilityStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."AvailabilityStatus" AS ENUM (
    'AVAILABLE',
    'ON_JOB',
    'OFF_DUTY'
);


ALTER TYPE public."AvailabilityStatus" OWNER TO shabooagri;

--
-- Name: BookingStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."BookingStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'ON_THE_WAY',
    'WORKING',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."BookingStatus" OWNER TO shabooagri;

--
-- Name: CompensationType; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."CompensationType" AS ENUM (
    'HOURLY',
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."CompensationType" OWNER TO shabooagri;

--
-- Name: ContactEnquiryStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."ContactEnquiryStatus" AS ENUM (
    'UNREAD',
    'IN_REVIEW',
    'RESOLVED'
);


ALTER TYPE public."ContactEnquiryStatus" OWNER TO shabooagri;

--
-- Name: CustomerFeedbackStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."CustomerFeedbackStatus" AS ENUM (
    'SUBMITTED',
    'IN_REVIEW',
    'PLANNED',
    'RESOLVED',
    'CLOSED'
);


ALTER TYPE public."CustomerFeedbackStatus" OWNER TO shabooagri;

--
-- Name: EmploymentStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."EmploymentStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public."EmploymentStatus" OWNER TO shabooagri;

--
-- Name: FuelType; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."FuelType" AS ENUM (
    'DIESEL',
    'PETROL',
    'ELECTRIC',
    'OTHER'
);


ALTER TYPE public."FuelType" OWNER TO shabooagri;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'UNPAID',
    'PARTIALLY_PAID',
    'PAID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO shabooagri;

--
-- Name: JobExecutionMode; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."JobExecutionMode" AS ENUM (
    'LIVE',
    'MANUAL'
);


ALTER TYPE public."JobExecutionMode" OWNER TO shabooagri;

--
-- Name: JobStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."JobStatus" AS ENUM (
    'NOT_STARTED',
    'WORKING',
    'PAUSED',
    'COMPLETED'
);


ALTER TYPE public."JobStatus" OWNER TO shabooagri;

--
-- Name: LicenseStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."LicenseStatus" AS ENUM (
    'REGISTERED',
    'PAYMENT_PENDING',
    'PAYMENT_VERIFIED',
    'LICENSE_ACTIVE',
    'EXPIRING_SOON',
    'EXPIRED',
    'RENEWED'
);


ALTER TYPE public."LicenseStatus" OWNER TO shabooagri;

--
-- Name: MachineStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."MachineStatus" AS ENUM (
    'WORKING',
    'AVAILABLE',
    'REPAIR',
    'OFFLINE'
);


ALTER TYPE public."MachineStatus" OWNER TO shabooagri;

--
-- Name: OtpPurpose; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."OtpPurpose" AS ENUM (
    'LOGIN',
    'VERIFY',
    'RESET'
);


ALTER TYPE public."OtpPurpose" OWNER TO shabooagri;

--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CASH',
    'UPI',
    'BANK_TRANSFER',
    'CREDIT'
);


ALTER TYPE public."PaymentMethod" OWNER TO shabooagri;

--
-- Name: SaasLeadStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."SaasLeadStatus" AS ENUM (
    'NEW',
    'CONTACTED',
    'IN_CONVERSATION',
    'CONVERTED',
    'CLOSED'
);


ALTER TYPE public."SaasLeadStatus" OWNER TO shabooagri;

--
-- Name: SaasPaymentStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."SaasPaymentStatus" AS ENUM (
    'PENDING',
    'SUCCESS',
    'FAILED',
    'REFUNDED'
);


ALTER TYPE public."SaasPaymentStatus" OWNER TO shabooagri;

--
-- Name: SaasUserStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."SaasUserStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED'
);


ALTER TYPE public."SaasUserStatus" OWNER TO shabooagri;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: shabooagri
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public."UserStatus" OWNER TO shabooagri;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO shabooagri;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid,
    user_id uuid,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    action text NOT NULL,
    changes jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    saas_user_id uuid
);


ALTER TABLE public.audit_log OWNER TO shabooagri;

--
-- Name: booking_attachments; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.booking_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    booking_id uuid NOT NULL,
    file_url text NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.booking_attachments OWNER TO shabooagri;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    booking_number text NOT NULL,
    customer_id uuid NOT NULL,
    village_id uuid NOT NULL,
    location text,
    machine_id uuid,
    driver_id uuid,
    manager_id uuid NOT NULL,
    scheduled_date date NOT NULL,
    scheduled_time time without time zone,
    estimated_hours numeric(6,2),
    estimated_acres numeric(8,2),
    pricing_method_id uuid NOT NULL,
    rate numeric(10,2) NOT NULL,
    status public."BookingStatus" DEFAULT 'PENDING'::public."BookingStatus" NOT NULL,
    notes text,
    created_by uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bookings OWNER TO shabooagri;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.companies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    logo_url text,
    theme_color text DEFAULT '#1B7A3E'::text,
    accent_color text,
    currency text DEFAULT 'INR'::text NOT NULL,
    timezone text DEFAULT 'Asia/Kolkata'::text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    invoice_prefix text DEFAULT 'INV'::text,
    print_layout jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    next_booking_number integer DEFAULT 1 NOT NULL,
    next_invoice_number integer DEFAULT 1 NOT NULL,
    address text,
    city text,
    district text,
    state text,
    pincode text,
    country text DEFAULT 'India'::text,
    phone text,
    email text,
    is_gst_registered boolean DEFAULT false NOT NULL,
    gstin text,
    pan text,
    bank_name text,
    account_number text,
    ifsc_code text,
    upi_id text,
    default_tax_rate numeric(5,2) DEFAULT 0,
    tax_inclusive boolean DEFAULT false NOT NULL,
    insurance_alert_days integer DEFAULT 30 NOT NULL,
    license_alert_days integer DEFAULT 30 NOT NULL,
    require_job_fuel_log boolean DEFAULT false NOT NULL,
    require_job_photo boolean DEFAULT false NOT NULL,
    service_alert_hours integer DEFAULT 50 NOT NULL
);


ALTER TABLE public.companies OWNER TO shabooagri;

--
-- Name: contact_enquiries; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.contact_enquiries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    business_name text,
    phone text NOT NULL,
    email text NOT NULL,
    subject text NOT NULL,
    message text NOT NULL,
    status public."ContactEnquiryStatus" DEFAULT 'UNREAD'::public."ContactEnquiryStatus" NOT NULL,
    response_notes text,
    assigned_admin_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_enquiries OWNER TO shabooagri;

--
-- Name: customer_feedbacks; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.customer_feedbacks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    saas_user_id uuid NOT NULL,
    company_id uuid,
    category text NOT NULL,
    rating integer,
    comment text NOT NULL,
    status public."CustomerFeedbackStatus" DEFAULT 'SUBMITTED'::public."CustomerFeedbackStatus" NOT NULL,
    admin_notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.customer_feedbacks OWNER TO shabooagri;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    user_id uuid,
    name text NOT NULL,
    village_id uuid NOT NULL,
    phone text,
    address text,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_gst_applicable boolean DEFAULT false NOT NULL,
    gstin text
);


ALTER TABLE public.customers OWNER TO shabooagri;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.drivers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    license_number text,
    license_expiry_date date,
    availability_status public."AvailabilityStatus" DEFAULT 'AVAILABLE'::public."AvailabilityStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.drivers OWNER TO shabooagri;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.employees (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    user_id uuid,
    name text NOT NULL,
    phone text,
    role_title text,
    employment_status public."EmploymentStatus" DEFAULT 'ACTIVE'::public."EmploymentStatus" NOT NULL,
    joined_date date,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    compensation_type public."CompensationType" DEFAULT 'HOURLY'::public."CompensationType" NOT NULL,
    hourly_rate numeric(10,2),
    monthly_salary numeric(10,2),
    yearly_salary numeric(10,2)
);


ALTER TABLE public.employees OWNER TO shabooagri;

--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.expense_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.expense_categories OWNER TO shabooagri;

--
-- Name: expenses; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.expenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    category_id uuid NOT NULL,
    machine_id uuid,
    amount numeric(10,2) NOT NULL,
    description text,
    incurred_by uuid NOT NULL,
    expense_date date NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.expenses OWNER TO shabooagri;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    invoice_number text NOT NULL,
    booking_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    paid_amount numeric(10,2) DEFAULT 0 NOT NULL,
    balance_amount numeric(10,2) DEFAULT 0 NOT NULL,
    status public."InvoiceStatus" DEFAULT 'UNPAID'::public."InvoiceStatus" NOT NULL,
    invoice_date date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    due_date date,
    print_layout_snapshot jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    is_gst_applicable boolean DEFAULT false NOT NULL,
    subtotal_amount numeric(10,2),
    tax_rate numeric(5,2) DEFAULT 0,
    tax_amount numeric(10,2) DEFAULT 0,
    cgst_amount numeric(10,2) DEFAULT 0,
    sgst_amount numeric(10,2) DEFAULT 0,
    igst_amount numeric(10,2) DEFAULT 0
);


ALTER TABLE public.invoices OWNER TO shabooagri;

--
-- Name: job_fuel_entries; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.job_fuel_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    job_id uuid NOT NULL,
    machine_id uuid NOT NULL,
    litres numeric(8,2) NOT NULL,
    cost numeric(10,2),
    recorded_by uuid NOT NULL,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.job_fuel_entries OWNER TO shabooagri;

--
-- Name: job_photos; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.job_photos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    job_id uuid NOT NULL,
    file_url text NOT NULL,
    caption text,
    uploaded_by uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.job_photos OWNER TO shabooagri;

--
-- Name: job_status_log; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.job_status_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    job_id uuid NOT NULL,
    status public."JobStatus" NOT NULL,
    changed_by uuid NOT NULL,
    changed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text
);


ALTER TABLE public.job_status_log OWNER TO shabooagri;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    booking_id uuid NOT NULL,
    machine_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    status public."JobStatus" DEFAULT 'NOT_STARTED'::public."JobStatus" NOT NULL,
    start_time timestamp(3) without time zone,
    end_time timestamp(3) without time zone,
    total_paused_duration_sec integer DEFAULT 0 NOT NULL,
    actual_hours numeric(6,2),
    completed_acres numeric(8,2),
    fuel_used_litres numeric(8,2),
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    execution_mode public."JobExecutionMode" DEFAULT 'LIVE'::public."JobExecutionMode" NOT NULL
);


ALTER TABLE public.jobs OWNER TO shabooagri;

--
-- Name: licenses; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.licenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    license_number text NOT NULL,
    saas_user_id uuid NOT NULL,
    company_id uuid,
    payment_id uuid,
    start_date timestamp(3) without time zone,
    expiry_date timestamp(3) without time zone,
    status public."LicenseStatus" DEFAULT 'REGISTERED'::public."LicenseStatus" NOT NULL,
    renewal_count integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.licenses OWNER TO shabooagri;

--
-- Name: machine_types; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.machine_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.machine_types OWNER TO shabooagri;

--
-- Name: machines; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.machines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    machine_type_id uuid NOT NULL,
    registration_number text NOT NULL,
    brand text,
    model text,
    purchase_year integer,
    fuel_type public."FuelType" DEFAULT 'DIESEL'::public."FuelType" NOT NULL,
    status public."MachineStatus" DEFAULT 'AVAILABLE'::public."MachineStatus" NOT NULL,
    hour_meter_reading numeric(10,2) DEFAULT 0 NOT NULL,
    insurance_number text,
    insurance_expiry_date date,
    assigned_driver_id uuid,
    next_service_due_hours numeric(10,2),
    last_service_date date,
    last_service_hour_meter numeric(10,2),
    photo_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.machines OWNER TO shabooagri;

--
-- Name: maintenance_records; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.maintenance_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    machine_id uuid NOT NULL,
    maintenance_schedule_id uuid,
    service_date date NOT NULL,
    hour_meter_at_service numeric(10,2),
    description text,
    cost numeric(10,2),
    performed_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.maintenance_records OWNER TO shabooagri;

--
-- Name: maintenance_schedules; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.maintenance_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    machine_id uuid NOT NULL,
    interval_hours numeric(8,2),
    interval_days integer,
    description text,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.maintenance_schedules OWNER TO shabooagri;

--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.otp_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier text NOT NULL,
    code_hash text NOT NULL,
    purpose public."OtpPurpose" NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    consumed_at timestamp(3) without time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.otp_codes OWNER TO shabooagri;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_method public."PaymentMethod" NOT NULL,
    reference_number text,
    received_by uuid NOT NULL,
    received_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.payments OWNER TO shabooagri;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.permissions OWNER TO shabooagri;

--
-- Name: pricing_methods; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.pricing_methods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    unit text,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.pricing_methods OWNER TO shabooagri;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    revoked_at timestamp(3) without time zone,
    user_agent text,
    ip_address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO shabooagri;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO shabooagri;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    system_key text,
    name text NOT NULL,
    is_system_role boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.roles OWNER TO shabooagri;

--
-- Name: saas_customer_profiles; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.saas_customer_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    saas_user_id uuid NOT NULL,
    business_name text NOT NULL,
    contact_person text NOT NULL,
    phone text NOT NULL,
    email text,
    address text,
    city text,
    state text,
    pincode text,
    gstin text,
    pan text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.saas_customer_profiles OWNER TO shabooagri;

--
-- Name: saas_leads; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.saas_leads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    business_name text,
    phone text NOT NULL,
    email text,
    source text DEFAULT 'WEBSITE'::text,
    status public."SaasLeadStatus" DEFAULT 'NEW'::public."SaasLeadStatus" NOT NULL,
    follow_up_notes text,
    assigned_admin_id uuid,
    created_by_saas_user_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.saas_leads OWNER TO shabooagri;

--
-- Name: saas_payments; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.saas_payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    saas_user_id uuid NOT NULL,
    license_id uuid,
    gateway_order_id text,
    gateway_payment_id text,
    gateway_signature text,
    payment_reference text,
    base_amount numeric(10,2) NOT NULL,
    gst_amount numeric(10,2) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    cgst_amount numeric(10,2),
    sgst_amount numeric(10,2),
    igst_amount numeric(10,2),
    currency text DEFAULT 'INR'::text NOT NULL,
    status public."SaasPaymentStatus" DEFAULT 'PENDING'::public."SaasPaymentStatus" NOT NULL,
    payment_method text,
    gateway_payload jsonb,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.saas_payments OWNER TO shabooagri;

--
-- Name: saas_users; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.saas_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    phone text,
    password_hash text NOT NULL,
    is_email_verified boolean DEFAULT false NOT NULL,
    status public."SaasUserStatus" DEFAULT 'ACTIVE'::public."SaasUserStatus" NOT NULL,
    is_platform_admin boolean DEFAULT false NOT NULL,
    last_login_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.saas_users OWNER TO shabooagri;

--
-- Name: sso_tokens; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.sso_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token_hash text NOT NULL,
    saas_user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    user_id uuid NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sso_tokens OWNER TO shabooagri;

--
-- Name: terminology_settings; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.terminology_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    term_key text NOT NULL,
    display_label_singular text NOT NULL,
    display_label_plural text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.terminology_settings OWNER TO shabooagri;

--
-- Name: users; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    role_id uuid NOT NULL,
    full_name text NOT NULL,
    email text,
    mobile_number text,
    password_hash text,
    pin_hash text,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    last_login_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO shabooagri;

--
-- Name: villages; Type: TABLE; Schema: public; Owner: shabooagri
--

CREATE TABLE public.villages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.villages OWNER TO shabooagri;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4a9809c9-9fd2-41e4-80c6-24a5c03ed482	e45a03e1584e135416faf11e6da54b60165a9cdabf0bbe38f17e01c168c2d25d	2026-08-07 18:43:56.875947+00	20260807184356_init_phase1_schema	\N	\N	2026-08-07 18:43:56.546719+00	1
fe1c516c-ac90-404e-964f-4face1116846	4ae1606c816b2111c43048d2e56764ae2c4f5396658d6b9e150ba5117c9d20d9	2026-08-08 05:23:23.983209+00	20260808052323_add_company_next_booking_number	\N	\N	2026-08-08 05:23:23.977385+00	1
f85ddf84-bf1a-455b-937b-e79a19c2b7e9	ecf34eb9b55db7d4fb4f0c0b6f505fe0a4c011d9bd942ab617ce6fa45c2df317	2026-08-08 11:20:38.121722+00	20260808112038_add_company_next_invoice_number	\N	\N	2026-08-08 11:20:38.112797+00	1
db609393-c524-403c-a48c-7d041c3e0c8e	30a10fdeea8216fcccd2e4d0c8ace808fc291a8d6fab08edaa5b31cf3aaa1477	2026-08-09 05:08:59.725084+00	20260809051000_add_phase_b_business_identity_tax_bank_fields	\N	\N	2026-08-09 05:08:59.705616+00	1
88dcec8a-77ea-4450-826c-6cb214e6296a	ec96a0846f762d62196595193f3b9ba4545136933d7f4a80df51424eaa734de0	2026-08-09 05:35:02.117068+00	20260809053500_add_phase_c_operational_rules		\N	2026-08-09 05:35:02.117068+00	0
e53fc79e-52b8-4584-8efa-58fe77697fc6	9341f4e7e6ffe3df90e0914946a41f2084a1405ae11613937c572629577e2032	\N	20260809063000_add_s1_saas_foundation	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260809063000_add_s1_saas_foundation\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "SaasUserStatus" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"SaasUserStatus\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260809063000_add_s1_saas_foundation"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260809063000_add_s1_saas_foundation"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-08-09 08:44:26.707526+00	2026-08-09 08:44:21.461985+00	0
9b118d83-0e17-44d8-9195-6b045b6549ed	9341f4e7e6ffe3df90e0914946a41f2084a1405ae11613937c572629577e2032	2026-08-09 08:44:26.709501+00	20260809063000_add_s1_saas_foundation		\N	2026-08-09 08:44:26.709501+00	0
8b19b1f1-bd2b-4ae4-9852-31cde1226965	c6a1e7d0d765cf973de66bd49c401f001915b96e319b6175ee6672a1260a046e	2026-08-09 08:59:25.759506+00	20260809090000_add_s3_sso_tokens	\N	\N	2026-08-09 08:59:25.729582+00	1
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.audit_log (id, company_id, user_id, entity_type, entity_id, action, changes, created_at, saas_user_id) FROM stdin;
cf9b5994-44fd-4541-a581-dbd6d6b9b926	\N	\N	SaasUser	567db271-c727-48d8-a006-cbffd4ef6125	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265135652@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:45:36.084	567db271-c727-48d8-a006-cbffd4ef6125
eeac847d-edcf-4d15-8970-d01056d85458	\N	\N	SaasUser	eb7c5f04-73cd-4cab-9482-9d226ad5a76d	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265152673@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:45:53.106	eb7c5f04-73cd-4cab-9482-9d226ad5a76d
d6703aa9-5e33-43ef-a476-2eff98e834cb	\N	\N	SaasUser	8f50bd4d-ff05-4f80-b4a0-30467581d715	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265153355@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:45:53.526	8f50bd4d-ff05-4f80-b4a0-30467581d715
2f774b32-fbe8-464d-8a3e-82c2f67891fa	\N	\N	License	18aefb21-5ba6-42d9-866c-f7de51559e9a	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "8f50bd4d-ff05-4f80-b4a0-30467581d715", "licenseNumber": "SAG-2026-CAEA19"}	2026-08-09 08:45:53.548	eb7c5f04-73cd-4cab-9482-9d226ad5a76d
1cd3b4e2-bbf9-46e3-96e7-92bfc5580c65	\N	\N	SaasUser	b2dd6b3c-c0af-460c-a1b1-2f51787c621a	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265162992@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:46:03.375	b2dd6b3c-c0af-460c-a1b1-2f51787c621a
55c5e4e5-fe0d-4c73-a544-bcc735984acd	\N	\N	SaasUser	dca6e873-da45-4439-a37c-02ac7e773bfe	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265163624@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:46:03.79	dca6e873-da45-4439-a37c-02ac7e773bfe
4bc6e0e9-2bd0-4794-af9c-b24e872a1e58	\N	\N	License	2cfd6129-cae2-48e4-9f42-9a3d98a9167e	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "dca6e873-da45-4439-a37c-02ac7e773bfe", "licenseNumber": "SAG-2026-1CC6D2"}	2026-08-09 08:46:03.814	b2dd6b3c-c0af-460c-a1b1-2f51787c621a
29ae1ffc-e654-4018-9bff-136a3cdf8926	\N	\N	SaasUser	c3682f6c-b267-4092-a4a4-4a2ea61eb217	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265170936@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:46:11.389	c3682f6c-b267-4092-a4a4-4a2ea61eb217
e154c8e5-4aab-4ac6-802f-870fe25a2500	\N	\N	SaasUser	334379fe-8e73-44c0-b273-e85494b33631	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265171601@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:46:11.764	334379fe-8e73-44c0-b273-e85494b33631
674a472d-42c6-4b9a-b37a-9e25a288ad83	\N	\N	License	59692180-b040-47a9-98f5-16a2338cd453	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "334379fe-8e73-44c0-b273-e85494b33631", "licenseNumber": "SAG-2026-E00B3E"}	2026-08-09 08:46:11.786	c3682f6c-b267-4092-a4a4-4a2ea61eb217
96e0f3ee-c308-4e30-ad83-6b01d19756e5	\N	\N	SaasUser	93db087c-2924-4c4a-bdbd-06fd6cacd476	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265180226@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:46:20.609	93db087c-2924-4c4a-bdbd-06fd6cacd476
71db6862-df77-4d3a-92d0-a62cbc6fb326	\N	\N	SaasUser	db6fe497-8cab-411a-8155-806b0f7b97c2	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265180854@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:46:21.027	db6fe497-8cab-411a-8155-806b0f7b97c2
110f5d38-5eb4-4c64-968f-5d261b299218	\N	\N	License	6a72f046-c496-45ce-844c-d003988ffc89	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "db6fe497-8cab-411a-8155-806b0f7b97c2", "licenseNumber": "SAG-2026-B15ADC"}	2026-08-09 08:46:21.051	93db087c-2924-4c4a-bdbd-06fd6cacd476
ca48b142-49df-40ab-b710-599a578cee0e	\N	\N	SaasUser	2a511485-aa8b-4935-8df8-c0342f273d0d	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265187570@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:46:27.969	2a511485-aa8b-4935-8df8-c0342f273d0d
d27bab8d-c610-437e-a360-5f514bd98904	\N	\N	SaasUser	cc521f60-b071-42d3-8181-7a3fc57ca34d	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265188225@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:46:28.413	cc521f60-b071-42d3-8181-7a3fc57ca34d
6472d52b-9fb6-4573-bd75-9225c55801fb	\N	\N	License	e5928390-9d9c-4d0c-b142-0efefd644b72	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "cc521f60-b071-42d3-8181-7a3fc57ca34d", "licenseNumber": "SAG-2026-7B7E04"}	2026-08-09 08:46:28.435	2a511485-aa8b-4935-8df8-c0342f273d0d
849ae066-dee2-401f-a75f-65a10bd6695e	\N	\N	SaaSPayment	03cbe04e-f4cd-4d6e-9dd4-bb5382801245	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "cc521f60-b071-42d3-8181-7a3fc57ca34d", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 08:46:28.472	2a511485-aa8b-4935-8df8-c0342f273d0d
bc116f4f-3b87-4885-9ba6-ceda3edc76b6	\N	\N	SaasUser	fb72511f-4cfc-4336-83b6-89ad5f3a6c33	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265194641@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:46:35.048	fb72511f-4cfc-4336-83b6-89ad5f3a6c33
06c82a54-2715-4a01-bf1a-35b19398836d	\N	\N	SaasUser	b2044d11-22a7-4df3-b2fe-5513b1011e2f	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265195305@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:46:35.474	b2044d11-22a7-4df3-b2fe-5513b1011e2f
eadffe46-d6db-42af-8d12-7115798ba472	\N	\N	License	0e399854-4b1a-4607-ad33-e592a9af6054	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "b2044d11-22a7-4df3-b2fe-5513b1011e2f", "licenseNumber": "SAG-2026-06E8B7"}	2026-08-09 08:46:35.498	fb72511f-4cfc-4336-83b6-89ad5f3a6c33
cbc7e29d-4747-46c7-9dc5-38616ff1fbcc	\N	\N	SaaSPayment	9ce19928-8cca-46c6-ac95-792b819b7928	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "b2044d11-22a7-4df3-b2fe-5513b1011e2f", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 08:46:35.541	fb72511f-4cfc-4336-83b6-89ad5f3a6c33
655d9cee-9f4d-4e93-9434-44c0bce36ef2	\N	\N	SaasUser	ccdcf26c-e31f-447e-b0df-6f637e12bcce	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265207886@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:46:48.282	ccdcf26c-e31f-447e-b0df-6f637e12bcce
02d887a8-9783-40ac-9c06-85f2cdb5f537	\N	\N	SaasUser	42111db9-0356-432f-a7da-3d4d2d0ae543	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265208536@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:46:48.723	42111db9-0356-432f-a7da-3d4d2d0ae543
3cd18644-ee50-4f3f-8709-f6b598a6c6b5	\N	\N	License	992b8f14-ea14-45ba-afab-63f5a00aa2e1	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "42111db9-0356-432f-a7da-3d4d2d0ae543", "licenseNumber": "SAG-2026-3098A3"}	2026-08-09 08:46:48.745	ccdcf26c-e31f-447e-b0df-6f637e12bcce
0e20fe49-0f49-479a-948d-eff42c274eb0	\N	\N	SaaSPayment	615b5f17-6c81-431c-a091-f79933668875	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "42111db9-0356-432f-a7da-3d4d2d0ae543", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 08:46:48.781	ccdcf26c-e31f-447e-b0df-6f637e12bcce
8b351927-762c-4250-bacf-da72ca3b83e0	\N	\N	SaasUser	77ee71dd-600e-45ff-b9c6-2d16d46b0406	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265219179@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:46:59.573	77ee71dd-600e-45ff-b9c6-2d16d46b0406
3e0c379e-d4d8-4bd0-b323-f836e77193dd	\N	\N	SaasUser	c3e57732-ffb8-4289-b355-b5be0b7a4c4e	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265219840@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:47:00.007	c3e57732-ffb8-4289-b355-b5be0b7a4c4e
94e8c128-8ee0-49da-a210-6f505351986c	\N	\N	License	837c815e-bb57-475d-a3a8-caefb62ad072	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "c3e57732-ffb8-4289-b355-b5be0b7a4c4e", "licenseNumber": "SAG-2026-82E4CF"}	2026-08-09 08:47:00.038	77ee71dd-600e-45ff-b9c6-2d16d46b0406
105e1c7f-6949-48f9-a513-6bdc7388e147	\N	\N	SaaSPayment	b6a3740c-0cae-41cf-89a1-75280a762bf8	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "c3e57732-ffb8-4289-b355-b5be0b7a4c4e", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 08:47:00.085	77ee71dd-600e-45ff-b9c6-2d16d46b0406
f70b3a30-31da-4ce7-96e3-722602cbcd23	\N	\N	SaasUser	c29cdcea-68f7-42f8-b256-7478920a89bb	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265265823@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:47:45.985	\N
f07bf43b-8b0e-4be7-8298-c6925be1b2ab	\N	\N	SaasUser	98bc18db-e107-43ff-9bd8-2fd37118933d	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265265145@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:47:45.57	\N
a51d5c3e-45a2-4d0d-8f9b-6a6513170895	\N	\N	License	fbf439d2-d7b5-42a2-8b2a-4c93969226bc	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "c29cdcea-68f7-42f8-b256-7478920a89bb", "licenseNumber": "SAG-2026-1D3694"}	2026-08-09 08:47:46.006	\N
43f80abb-95b4-4bf1-bead-32c8b6d7c84e	\N	\N	SaaSPayment	a1de61ba-dc49-4242-abd5-26bb8ede5b5a	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "c29cdcea-68f7-42f8-b256-7478920a89bb", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 08:47:46.051	\N
42d32d2a-edca-4f02-ae9f-db9f422d63e5	\N	\N	SaasUser	a496c386-1bcf-4f1a-98d2-3a44f96575b5	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265274438@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:47:54.88	\N
bd454da6-e8b3-46d4-a6cd-b2bf5bb84554	\N	\N	License	7c14b94a-c0ce-4008-9817-bfd553679d92	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "ea646728-3cce-4aea-a212-a2be10fc5066", "licenseNumber": "SAG-2026-B8EA9B"}	2026-08-09 08:47:55.276	\N
f3a8fb28-c6ec-4a33-8679-253ede902a0e	\N	\N	SaaSPayment	aaf91a4d-5b7d-42a6-804a-70193bcb0083	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "ea646728-3cce-4aea-a212-a2be10fc5066", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 08:47:55.31	\N
1f3e7f52-0e84-4ef2-8e5c-8fded78ab0ba	\N	\N	SaasUser	ea646728-3cce-4aea-a212-a2be10fc5066	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265275102@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:47:55.257	\N
db8f8d6f-757b-4f91-a248-fa975c1ec9b5	\N	\N	SaasUser	31fb32b3-6a52-40c8-90bc-83ce92f09f63	SAAS_USER_REGISTERED	{"email": "saas_admin_1786265617282@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 08:53:37.661	\N
8da3a333-073a-45c9-b776-b275db998bed	\N	\N	License	57f36194-a8f1-4bc0-ad6b-3fa05c46765e	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "cd70d026-1331-4141-aec4-cd72c9a317f7", "licenseNumber": "SAG-2026-D4AEBE"}	2026-08-09 08:53:38.144	\N
b38ab800-2291-4a44-a6f6-8bf9eb4e60ab	\N	\N	SaaSPayment	143d1c99-9655-4249-aca2-a36130a4c938	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "cd70d026-1331-4141-aec4-cd72c9a317f7", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 08:53:38.191	\N
d9012e5b-e0ac-4ee5-aaf3-1686700bac37	\N	\N	SaasUser	cd70d026-1331-4141-aec4-cd72c9a317f7	SAAS_USER_REGISTERED	{"email": "saas_customer_1786265617930@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 08:53:38.112	\N
0e814496-ad3f-4a87-9081-5ae5731d4c7b	\N	\N	SaasUser	2c21781b-2075-44bb-9b30-3827be722f36	SAAS_USER_REGISTERED	{"email": "customer_b_1786266102846@example.com", "businessName": "Superstar Machinery Hub"}	2026-08-09 09:01:43.285	\N
a3117667-1a2b-431a-97db-1d5f979520ef	\N	\N	SaasUser	4a882dd5-b89f-4e5d-8cc9-2ea66d3d13f1	SAAS_USER_REGISTERED	{"email": "customer_a_1786266102846@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:01:43.182	\N
fb9a0ae2-c140-420f-81dd-554179549e31	\N	\N	SaaSPayment	5741c57d-fc82-434b-b836-9f65cd85f4f0	SAAS_PAYMENT_VERIFIED	{"paymentId": "5741c57d-fc82-434b-b836-9f65cd85f4f0", "totalAmount": 4999, "licenseNumber": "SAG-2026-745C42", "gatewayPaymentId": "pay_test_1786266102846"}	2026-08-09 09:01:43.476	\N
bddfb84d-888b-44d2-9387-76fe3174cc07	77e72b03-ff84-4721-bdbc-a79d00c301a6	\N	Company	77e72b03-ff84-4721-bdbc-a79d00c301a6	TENANT_PROVISIONED	{"slug": "greenfieldscustomhiring", "ownerEmail": "customer_a_1786266102846@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:01:43.543	\N
2af9cce0-948c-4d60-8119-1337b3e006c3	\N	\N	SaasUser	59a272be-daaa-4f15-9787-9280acc4da83	SAAS_USER_REGISTERED	{"email": "customer_b_1786266117437@example.com", "businessName": "Superstar Machinery Hub"}	2026-08-09 09:01:57.881	\N
11b2b884-538a-49e1-95be-ec7c8804b875	\N	\N	SaasUser	a971a789-fa8e-4f34-bf1c-a60cd6d8f644	SAAS_USER_REGISTERED	{"email": "customer_a_1786266117437@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:01:57.777	\N
6dc6bece-629b-4a5d-a998-630b42c042aa	\N	\N	SaaSPayment	936b3eeb-bc50-46a8-8e23-cc3432a52d16	SAAS_PAYMENT_VERIFIED	{"paymentId": "936b3eeb-bc50-46a8-8e23-cc3432a52d16", "totalAmount": 4999, "licenseNumber": "SAG-2026-6E65A4", "gatewayPaymentId": "pay_test_1786266117437"}	2026-08-09 09:01:58.036	\N
0f938897-13a6-4aa5-b508-ae74edfe478d	19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	\N	Company	19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	TENANT_PROVISIONED	{"slug": "greenfieldscustomhiring1", "ownerEmail": "customer_a_1786266117437@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:01:58.131	\N
949f002a-43d9-4742-97d6-b0f36e0d1ca8	\N	\N	License	9a4c5e5a-f5a0-4ecc-8dd2-77901bec975e	ADMIN_LICENSE_EXTENDED	{"reason": "Customer courtesy test extension", "newExpiry": "2026-09-08T09:01:58.281Z", "extensionDays": 30}	2026-08-09 09:01:58.287	\N
a9a51efe-8d51-404b-9ccc-82d8487093ac	\N	\N	SaasUser	4b78994f-9bab-4c2d-9c02-36456a4a8148	SAAS_USER_REGISTERED	{"email": "customer_b_1786266188564@example.com", "businessName": "Superstar Machinery Hub"}	2026-08-09 09:03:09.005	\N
784ac6be-1b6b-486c-a3f6-b2470e284617	\N	\N	SaasUser	22b3c1ee-7a13-431c-a864-f1c54c4f4a8c	SAAS_USER_REGISTERED	{"email": "customer_a_1786266188564@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:03:08.891	\N
8e433e1c-be0c-4963-b2bf-899d5d0717a1	\N	\N	SaaSPayment	d0b8ae85-8893-4835-a2f1-e0b35f13d68f	SAAS_PAYMENT_VERIFIED	{"paymentId": "d0b8ae85-8893-4835-a2f1-e0b35f13d68f", "totalAmount": 4999, "licenseNumber": "SAG-2026-36C94D", "gatewayPaymentId": "pay_test_1786266188564"}	2026-08-09 09:03:09.169	\N
39c361f6-6dfa-44de-b6a4-d83ca4023ca8	31fdb769-0873-405a-aed7-f54f5303d5c5	\N	Company	31fdb769-0873-405a-aed7-f54f5303d5c5	TENANT_PROVISIONED	{"slug": "greenfieldscustomhiring2", "ownerEmail": "customer_a_1786266188564@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:03:09.235	\N
cd8c6e69-ca69-472d-a69e-aca4ef41c6cd	\N	\N	License	8fd8037e-edc8-42a3-aad2-46b6bc3b6821	ADMIN_LICENSE_EXTENDED	{"reason": "Customer courtesy test extension", "newExpiry": "2026-09-08T09:03:09.407Z", "extensionDays": 30}	2026-08-09 09:03:09.413	\N
04816143-52ca-4b6b-9893-d41ff58bbfad	\N	\N	SaasUser	c144d6e8-9bbc-48cc-b536-c87b82b2a88d	SAAS_USER_REGISTERED	{"email": "saas_admin_1786266191020@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 09:03:11.44	c144d6e8-9bbc-48cc-b536-c87b82b2a88d
6affe742-06cf-4d56-b4fb-315ed962bd2f	\N	\N	SaasUser	3788bc3f-7d6f-4b2c-a823-226ca6160bcc	SAAS_USER_REGISTERED	{"email": "saas_customer_1786266191667@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 09:03:11.869	3788bc3f-7d6f-4b2c-a823-226ca6160bcc
712c6654-7dd4-42c1-8b38-a607ed2b4bab	\N	\N	License	7f90a53c-60a8-41e8-a3f3-bcfe76410064	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "3788bc3f-7d6f-4b2c-a823-226ca6160bcc", "licenseNumber": "SAG-2026-2AD992"}	2026-08-09 09:03:11.888	c144d6e8-9bbc-48cc-b536-c87b82b2a88d
c5b6bc54-8f4e-4a8b-9652-ebdf7b3ba477	\N	\N	SaaSPayment	0cd7edff-989b-454d-bf3e-d8954a8aa2a3	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "3788bc3f-7d6f-4b2c-a823-226ca6160bcc", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 09:03:11.924	c144d6e8-9bbc-48cc-b536-c87b82b2a88d
249b01c6-a1f8-42a6-8a9d-605f2c5d7fac	\N	\N	SaasUser	92ea21c1-448d-4f96-bcda-519f746bf7b6	SAAS_USER_REGISTERED	{"email": "customer_b_1786266199334@example.com", "businessName": "Superstar Machinery Hub"}	2026-08-09 09:03:19.782	\N
346633e6-773d-4956-9435-bdb94afb0052	\N	\N	SaasUser	fca70e8a-3df0-4da7-afe1-19e67f8e8023	SAAS_USER_REGISTERED	{"email": "customer_a_1786266199334@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:03:19.677	\N
0d94eba3-180b-4ce2-b070-04730db02abf	\N	\N	SaaSPayment	0d07d908-1247-4ca1-b2b0-883299790454	SAAS_PAYMENT_VERIFIED	{"paymentId": "0d07d908-1247-4ca1-b2b0-883299790454", "totalAmount": 4999, "licenseNumber": "SAG-2026-8764FD", "gatewayPaymentId": "pay_test_1786266199334"}	2026-08-09 09:03:19.92	\N
de42d858-0531-4797-8f34-aaa46e533fd2	1b7025b9-c122-4210-a967-97e8c1d180fd	\N	Company	1b7025b9-c122-4210-a967-97e8c1d180fd	TENANT_PROVISIONED	{"slug": "greenfieldscustomhiring3", "ownerEmail": "customer_a_1786266199334@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:03:20.019	\N
dbae8e03-961a-4f3d-8ff8-d38865629090	\N	\N	License	46f53e78-fdac-4f2d-9455-340c5af2a07c	ADMIN_LICENSE_EXTENDED	{"reason": "Customer courtesy test extension", "newExpiry": "2026-09-08T09:03:20.189Z", "extensionDays": 30}	2026-08-09 09:03:20.194	\N
800a09f7-b496-4bf2-bf2a-428c1e9fdb31	\N	\N	SaasUser	659f8ac9-b7ca-4e6f-83a7-7ae3f28ec1c3	SAAS_USER_REGISTERED	{"email": "saas_admin_1786266201671@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 09:03:22.104	\N
a7b779d1-b4cc-4746-935b-3e550d83a413	\N	\N	License	a0e4bf4e-3897-4775-b2b9-9454166463e7	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "6e59a51b-b2d4-4ae7-9732-b083c4c318a8", "licenseNumber": "SAG-2026-769859"}	2026-08-09 09:03:22.563	\N
c8f16d21-88ad-4fb3-b8da-1c58d06d5b68	\N	\N	SaaSPayment	acb0b8fc-dfbc-4dd6-8199-23d9db41d0d4	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "6e59a51b-b2d4-4ae7-9732-b083c4c318a8", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 09:03:22.597	\N
76938f82-ff61-477f-ab1a-cc122f65a855	\N	\N	SaasUser	6e59a51b-b2d4-4ae7-9732-b083c4c318a8	SAAS_USER_REGISTERED	{"email": "saas_customer_1786266202318@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 09:03:22.544	\N
95e6d1b7-5f97-4758-9214-f4e08065f2c6	\N	\N	SaasUser	696281cc-b7cc-440c-bce2-82e2c3519857	SAAS_USER_REGISTERED	{"email": "s4_user_a_1786266373161@example.com", "businessName": "Alpha Agri Services"}	2026-08-09 09:06:13.445	\N
e7738dff-7027-4b06-a5b2-05973a76f98c	\N	\N	SaaSPayment	c2f2d9b7-1e85-42bb-a290-d559d65f7680	SAAS_PAYMENT_VERIFIED	{"paymentId": "c2f2d9b7-1e85-42bb-a290-d559d65f7680", "totalAmount": 4999, "licenseNumber": "SAG-2026-D61408", "gatewayPaymentId": "pay_s4_1786266373161"}	2026-08-09 09:06:13.585	\N
6bba31f0-5d3b-4098-8365-234db902477b	9e4b2764-62cc-4933-9014-de6fc8b82d10	\N	Company	9e4b2764-62cc-4933-9014-de6fc8b82d10	TENANT_PROVISIONED	{"slug": "alphaagriservices", "ownerEmail": "s4_user_a_1786266373161@example.com", "businessName": "Alpha Agri Services"}	2026-08-09 09:06:13.685	\N
f68ca4e3-9333-4568-8dd9-ab320ef2de1c	\N	\N	SaasUser	7eecec31-2874-4ab9-8587-99e859c6b0f3	SAAS_USER_REGISTERED	{"email": "s4_user_b_1786266373161@example.com", "businessName": "Beta Harvest Fleet"}	2026-08-09 09:06:13.549	\N
27abd345-d8e9-43f6-a501-25ab7a79d523	\N	\N	SaasUser	6166f747-40f5-41bb-9ec5-a5910f4fb406	SAAS_USER_REGISTERED	{"email": "s4_user_a_1786266377512@example.com", "businessName": "Alpha Agri Services"}	2026-08-09 09:06:17.846	\N
ba173077-fba8-4d5a-8379-7f1d95f4ab94	\N	\N	SaaSPayment	1c2adf61-e88c-479c-8727-bc95100d32c3	SAAS_PAYMENT_VERIFIED	{"paymentId": "1c2adf61-e88c-479c-8727-bc95100d32c3", "totalAmount": 4999, "licenseNumber": "SAG-2026-5847A4", "gatewayPaymentId": "pay_s4_1786266377512"}	2026-08-09 09:06:17.992	\N
648be3b7-6349-4bb8-bbaa-ab585a5c9d44	d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	\N	Company	d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	TENANT_PROVISIONED	{"slug": "alphaagriservices1", "ownerEmail": "s4_user_a_1786266377512@example.com", "businessName": "Alpha Agri Services"}	2026-08-09 09:06:18.048	\N
04050bf9-560c-4380-895f-e907c5d71f40	\N	\N	SaasUser	fd7186b3-8037-4c77-addf-f97e74f5500b	SAAS_USER_REGISTERED	{"email": "s4_user_b_1786266377512@example.com", "businessName": "Beta Harvest Fleet"}	2026-08-09 09:06:17.954	\N
4b9d2e69-7393-4365-b114-938fc8fb51ca	\N	\N	SaasUser	19680c8b-2568-4129-adc7-3b177e6822ec	SAAS_USER_REGISTERED	{"email": "customer_b_1786266379295@example.com", "businessName": "Superstar Machinery Hub"}	2026-08-09 09:06:19.736	\N
bbc9c402-6637-4f31-8fab-3e9d2561fce9	\N	\N	SaasUser	3a26cc8f-b29b-48de-b19c-72afac508311	SAAS_USER_REGISTERED	{"email": "customer_a_1786266379295@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:06:19.576	\N
1a6709be-10ed-4dda-ad7b-1f01d44ac3ef	\N	\N	SaaSPayment	b2d476b0-f3e0-43b5-87d8-f8c6c19c882d	SAAS_PAYMENT_VERIFIED	{"paymentId": "b2d476b0-f3e0-43b5-87d8-f8c6c19c882d", "totalAmount": 4999, "licenseNumber": "SAG-2026-B8498D", "gatewayPaymentId": "pay_test_1786266379295"}	2026-08-09 09:06:19.879	\N
8c4d6e3e-29b0-4d7a-834e-7523bf6b7052	82d1d4f0-a664-4442-afb1-3c8e8deec8f8	\N	Company	82d1d4f0-a664-4442-afb1-3c8e8deec8f8	TENANT_PROVISIONED	{"slug": "greenfieldscustomhiring4", "ownerEmail": "customer_a_1786266379295@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:06:19.945	\N
8083c437-223c-49cd-a903-30ed760b63d0	\N	\N	License	dfe832c7-0258-4f72-ac54-08cf7b980165	ADMIN_LICENSE_EXTENDED	{"reason": "Customer courtesy test extension", "newExpiry": "2026-09-08T09:06:20.094Z", "extensionDays": 30}	2026-08-09 09:06:20.1	\N
faecc6f1-ba15-4b8f-8a44-acbd11e72099	\N	\N	SaasUser	e3148a3d-d910-4edb-aca8-f3419df412a5	SAAS_USER_REGISTERED	{"email": "saas_admin_1786266381588@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 09:06:21.981	\N
0a84acd6-2e77-45c1-b107-5fb7505739c9	\N	\N	License	bbbbd676-c629-4ded-9036-727b41e10647	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "594f1652-6647-47de-9903-ab69dda622b1", "licenseNumber": "SAG-2026-CDC297"}	2026-08-09 09:06:22.458	\N
abb80d5e-c556-4663-a7a7-455c9d62037f	\N	\N	SaaSPayment	8193c869-b54b-491d-ba41-213ae3995137	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "594f1652-6647-47de-9903-ab69dda622b1", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 09:06:22.495	\N
71376d61-897a-447a-9d6f-03431fad7f61	\N	\N	SaasUser	594f1652-6647-47de-9903-ab69dda622b1	SAAS_USER_REGISTERED	{"email": "saas_customer_1786266382233@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 09:06:22.442	\N
917d8970-1f53-4101-b602-b9fb665ea955	\N	\N	SaasUser	e6e19374-9af6-417e-aa21-da7763587b71	SAAS_USER_REGISTERED	{"email": "s4_user_a_1786266618997@example.com", "businessName": "Alpha Agri Services"}	2026-08-09 09:10:19.337	\N
88c7aa0d-6533-464b-bb01-b3766dfc6273	\N	\N	SaaSPayment	225126c1-4c73-4986-b876-5013dcf244ef	SAAS_PAYMENT_VERIFIED	{"paymentId": "225126c1-4c73-4986-b876-5013dcf244ef", "totalAmount": 4999, "licenseNumber": "SAG-2026-67B544", "gatewayPaymentId": "pay_s4_1786266618997"}	2026-08-09 09:10:19.486	\N
b1dedd6b-f441-4168-a29c-cba2c94c0f05	1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	\N	Company	1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	TENANT_PROVISIONED	{"slug": "alphaagriservices2", "ownerEmail": "s4_user_a_1786266618997@example.com", "businessName": "Alpha Agri Services"}	2026-08-09 09:10:19.572	\N
a4ce5699-6810-4f8b-8d95-3e31184e8531	\N	\N	SaasUser	418b900f-2755-4b05-82df-6a10759bbfc0	SAAS_USER_REGISTERED	{"email": "s4_user_b_1786266618997@example.com", "businessName": "Beta Harvest Fleet"}	2026-08-09 09:10:19.449	\N
2ccdbf19-74a5-4bbc-bd71-faab74d9f87f	\N	\N	SaasUser	e5f008f2-5467-42d8-9dcc-3aac7f8e6a53	SAAS_USER_REGISTERED	{"email": "customer_b_1786266620795@example.com", "businessName": "Superstar Machinery Hub"}	2026-08-09 09:10:21.264	\N
44b2e259-8332-4da4-bcf9-78c5b636694e	\N	\N	SaasUser	a05d168a-3ea0-4901-9bf4-f47a4df3999a	SAAS_USER_REGISTERED	{"email": "customer_a_1786266620795@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:10:21.16	\N
b2a22584-c85e-4383-af75-b52f92a76e93	\N	\N	SaaSPayment	bcd7f55c-ab2f-48c4-885c-d77734e07061	SAAS_PAYMENT_VERIFIED	{"paymentId": "bcd7f55c-ab2f-48c4-885c-d77734e07061", "totalAmount": 4999, "licenseNumber": "SAG-2026-EFD8B9", "gatewayPaymentId": "pay_test_1786266620795"}	2026-08-09 09:10:21.462	\N
3409d82f-988d-415d-a160-7fb21beb10c0	aeb2474e-c378-471b-ab64-81925a1bc912	\N	Company	aeb2474e-c378-471b-ab64-81925a1bc912	TENANT_PROVISIONED	{"slug": "greenfieldscustomhiring5", "ownerEmail": "customer_a_1786266620795@example.com", "businessName": "Greenfields Custom Hiring"}	2026-08-09 09:10:21.558	\N
6c4ef7ef-ce9f-4784-bea1-d97b42c279af	\N	\N	License	d1bd0d1a-ded6-4742-845b-32c258f278e5	ADMIN_LICENSE_EXTENDED	{"reason": "Customer courtesy test extension", "newExpiry": "2026-09-08T09:10:21.719Z", "extensionDays": 30}	2026-08-09 09:10:21.723	\N
bfb590a3-f858-4381-8005-c6ad980c7f04	\N	\N	SaasUser	2723a8bb-04ab-4b61-a4ac-f052e34abe23	SAAS_USER_REGISTERED	{"email": "saas_admin_1786266623253@shabooagri.com", "businessName": "ShabooAgri Platform Ops"}	2026-08-09 09:10:23.699	\N
74a8445c-4ed5-4e51-bb68-d1a54c1a2baa	\N	\N	License	8fb4437a-c256-4195-9c7b-9644987df708	LICENSE_ISSUED	{"status": "LICENSE_ACTIVE", "saasUserId": "eec58dec-835a-415b-a28c-0a2803bdeb31", "licenseNumber": "SAG-2026-D831A8"}	2026-08-09 09:10:24.136	\N
c3858ea2-8171-48a1-ab74-79e318f50c5c	\N	\N	SaaSPayment	307424de-4a7f-4235-8605-402c893ab4d4	SAAS_PAYMENT_RECORDED	{"status": "SUCCESS", "saasUserId": "eec58dec-835a-415b-a28c-0a2803bdeb31", "totalAmount": 4999, "paymentReference": "TXN-BANK-998877"}	2026-08-09 09:10:24.178	\N
7f319895-1f45-4b2f-92dc-33c922231840	\N	\N	SaasUser	eec58dec-835a-415b-a28c-0a2803bdeb31	SAAS_USER_REGISTERED	{"email": "saas_customer_1786266623919@example.com", "businessName": "Suresh Custom Hiring Center"}	2026-08-09 09:10:24.117	\N
\.


--
-- Data for Name: booking_attachments; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.booking_attachments (id, company_id, booking_id, file_url, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.bookings (id, company_id, booking_number, customer_id, village_id, location, machine_id, driver_id, manager_id, scheduled_date, scheduled_time, estimated_hours, estimated_acres, pricing_method_id, rate, status, notes, created_by, created_at, updated_at) FROM stdin;
d7346a22-1f51-4203-a659-122d84fcfe1a	40511429-f937-4f0f-8a0a-6869154b7144	BK-000001	4ec94854-4ffa-4395-b169-0b0df420f37c	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	\N	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	2.00	\N	0737046e-404b-409b-8282-79e96ad9a731	1500.00	PENDING	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:23:38.169	2026-08-09 05:23:38.169
b1665642-35e9-45ff-b2b3-2d8919e929b5	40511429-f937-4f0f-8a0a-6869154b7144	BK-000002	2d76dcde-243c-4522-9c9c-e684da325161	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	\N	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	2.00	\N	0737046e-404b-409b-8282-79e96ad9a731	1500.00	PENDING	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:23:50.905	2026-08-09 05:23:50.905
02f93844-2adb-41c2-9635-6084d2666f3d	3968e65b-4204-432c-ad93-26a831a79d3e	BK-000003	0c615840-e4fd-46c7-865c-0e0cd1715e7a	8b485ab8-fd4f-4c80-827f-fb7a1448386d	\N	a9754ce6-cf7e-4f94-bfde-c900853d603a	ca505264-dd8c-44de-a80b-604cb57fa768	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08	\N	\N	\N	54552b35-1113-48c9-8b26-7b7e502b3bae	500.00	COMPLETED	Yearly driver field work	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.717	2026-08-08 19:38:59.731
908f20a9-4e50-47fe-a84c-46aaa6fc110b	40511429-f937-4f0f-8a0a-6869154b7144	BK-000003	cec5b776-ff7b-4e24-9211-5241aeadd805	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	\N	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	2.00	\N	0737046e-404b-409b-8282-79e96ad9a731	1500.00	ACCEPTED	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:23:59.324	2026-08-09 05:23:59.36
7d4440e4-d8f2-41ee-a5bc-a7f634fef026	40511429-f937-4f0f-8a0a-6869154b7144	BK-000004	c57b3018-31e6-4764-9f82-f70ba695f5b7	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	\N	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	2.00	\N	0737046e-404b-409b-8282-79e96ad9a731	1500.00	ACCEPTED	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:16.64	2026-08-09 05:24:16.677
97b7f047-acd4-4ab7-a684-a58d2a64f4e0	40511429-f937-4f0f-8a0a-6869154b7144	BK-000005	358e743a-0c1e-4c66-995a-09ec05aaa38f	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	2.00	\N	0737046e-404b-409b-8282-79e96ad9a731	1500.00	ON_THE_WAY	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:28.009	2026-08-09 05:24:28.143
c79049d8-ef5b-47ef-803b-c22bcc545285	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	BK-000001	5c528eb2-01c6-4daa-8152-ddd52473eebc	278e7946-06ca-4111-81af-3852352dd65d	\N	e3cd9c96-272a-4b49-80cc-878dd0d59317	4f23afea-dad1-43f4-b35d-290f442df31a	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08	\N	\N	\N	995f2e6d-2dfc-49c5-b0c2-7873f8d2fcce	500.00	COMPLETED	\N	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.074	2026-08-08 19:41:58.29
f7f78fe2-fbd2-4cc4-bb8d-da62ed5ea659	a6565866-d95e-4c4c-a2eb-76f3171c2907	BK-000001	d579b239-5b05-4d3e-b3d5-50e53adacfe6	8383bb42-c809-45fc-8a7c-48783821f67c	\N	8bc65fdb-4ab3-4edf-ada9-0601c295727f	affa378c-57a7-429d-8d2b-a68cdcf354ce	756343b9-5737-4fe3-8505-0a294e322cd8	2026-08-10	\N	4.00	\N	0e3d37af-600e-46d8-b9d8-9cc8898b8b37	500.00	ON_THE_WAY	\N	756343b9-5737-4fe3-8505-0a294e322cd8	2026-08-08 18:05:17.53	2026-08-08 18:05:17.555
e2f59f8e-7a23-4143-8688-e0c39138f6b1	40511429-f937-4f0f-8a0a-6869154b7144	BK-000006	fae25e27-94cb-4539-a75e-e4bbd03ecc9d	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	2.00	\N	0737046e-404b-409b-8282-79e96ad9a731	1500.00	COMPLETED	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:37.31	2026-08-09 05:24:37.535
46f42d68-b2bc-4c52-aabb-f069c55992f8	ecbba26c-b8ee-4455-a09e-86fab13778df	BK-000003	76435d2e-2dee-4c15-839f-812a8175f71a	5d1e6b71-e380-4ffc-9171-dbec16359e6c	\N	b61808f9-6b2e-4f80-8dd3-11909e2c884d	048dd78c-ced5-4f25-bfca-2aac3bfa190f	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08	\N	\N	\N	ee7706ee-25d0-4661-a2d2-725908ca6f28	500.00	COMPLETED	Yearly driver field work	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.358	2026-08-08 20:04:26.366
526dc4ea-5d37-47d9-8678-e8825f1e6ce7	2fc53fa9-07fd-4172-af37-6a1034df9ecb	BK-000001	f569aece-5806-4415-8705-f46013b37a0f	98793a83-0a3b-4b0e-a702-18b016b066cc	\N	b992842f-5fa7-41a0-9a1c-5d933d0c6b8a	026b9227-d949-411b-b645-470004e4ffbf	7483a070-5bda-427f-aca4-841789bdd852	2026-08-10	\N	4.00	\N	6912c958-19fa-4474-9872-9cc6c375e26a	500.00	COMPLETED	\N	7483a070-5bda-427f-aca4-841789bdd852	2026-08-08 18:05:31.626	2026-08-08 18:05:31.731
efac0575-b89e-47fa-ae52-aa2e6b0c54fa	023866d9-236a-41cc-a36f-b9e516720f54	BK-000001	56627245-a7e8-4ebd-a25d-ed0a041a9a77	3b6d3980-f22c-4054-a419-0aac2d98146a	\N	dfabea01-ad4b-48f9-8916-f19cbd6c5176	9713d310-89ea-4939-b59d-0c8418ab1f50	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08	\N	\N	\N	adea2e4d-c414-4489-8246-78ee12d9ae15	500.00	COMPLETED	\N	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:42.986	2026-08-08 18:15:43.201
9d1bc692-b543-444b-9a49-1eb5e225fcb1	023866d9-236a-41cc-a36f-b9e516720f54	BK-000002	56627245-a7e8-4ebd-a25d-ed0a041a9a77	3b6d3980-f22c-4054-a419-0aac2d98146a	\N	dfabea01-ad4b-48f9-8916-f19cbd6c5176	f362162c-0ef7-4562-9bfa-db40c75f9038	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08	\N	\N	\N	adea2e4d-c414-4489-8246-78ee12d9ae15	600.00	COMPLETED	Late night after-work manual entry	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:43.273	2026-08-08 18:15:43.29
f2822944-a077-49aa-8467-8165c80b177b	40511429-f937-4f0f-8a0a-6869154b7144	BK-000007	db50fa12-67e6-4104-bbf6-6133fde71d55	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	5.00	\N	0737046e-404b-409b-8282-79e96ad9a731	2000.00	COMPLETED	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:37.621	2026-08-09 05:24:37.776
6c881d9d-dfa5-4c18-83d9-97aaa39af635	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254005165-404	ca6d3911-a5f5-4bb1-823d-7ca0e757346e	e32fdea7-8bfe-4de6-91c9-a990fb5aeb6d	\N	a7948034-0b85-47e6-aa4c-e91964c62457	8f9d1423-400f-4b71-8227-33e4731ca81a	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	WORKING	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:05.166	2026-08-09 05:40:05.166
00f1cddc-14d8-4db0-a01d-f65478d0a43a	024b72fd-44b2-4f38-96c1-78b156fa58c2	BK-000001	03584dfd-64c9-4296-a39f-23d2d5095195	0b671c70-3cb9-4f0a-8f96-1e1900f9b5d0	\N	b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	d411498c-9edc-42c2-99b8-c994d4bca031	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08	\N	\N	\N	c09ad282-3763-4ecc-92b4-db6e9b5af8fa	500.00	COMPLETED	\N	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.508	2026-08-08 18:22:33.722
e25e74f0-3354-4150-b33a-0d6462b76df8	024b72fd-44b2-4f38-96c1-78b156fa58c2	BK-000002	03584dfd-64c9-4296-a39f-23d2d5095195	0b671c70-3cb9-4f0a-8f96-1e1900f9b5d0	\N	b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	05970484-ef07-48f0-af0e-697d36491891	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08	\N	\N	\N	c09ad282-3763-4ecc-92b4-db6e9b5af8fa	600.00	COMPLETED	Late night after-work manual entry	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.787	2026-08-08 18:22:33.8
3e0cd0a4-5889-49a7-8d50-13850f0f2ebd	024b72fd-44b2-4f38-96c1-78b156fa58c2	BK-000003	03584dfd-64c9-4296-a39f-23d2d5095195	0b671c70-3cb9-4f0a-8f96-1e1900f9b5d0	\N	b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	e460d3e1-6e27-4ee6-877c-d4e664a62bcd	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08	\N	\N	\N	c09ad282-3763-4ecc-92b4-db6e9b5af8fa	500.00	COMPLETED	Yearly driver field work	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.857	2026-08-08 18:22:33.869
d7a5fa51-d422-49d6-a62d-22fac5d25cb6	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	BK-000001	6186f7cd-d9d3-498b-a085-65571b3acb00	4c5c7805-d59e-4619-bb06-6894e92a6200	\N	142de1ae-b2d7-4726-a644-5f49d04e69c4	fae5c1d8-f25d-474b-b3e2-cd7d613d01f3	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08	\N	\N	\N	63725161-7dae-4578-923c-f93a3cd09943	500.00	COMPLETED	\N	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.469	2026-08-08 20:53:03.588
49f5ad86-5cc6-4c3e-a994-51b73911ae3c	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	BK-000003	6186f7cd-d9d3-498b-a085-65571b3acb00	4c5c7805-d59e-4619-bb06-6894e92a6200	\N	142de1ae-b2d7-4726-a644-5f49d04e69c4	9d3b15a8-ff37-42d9-8704-b5cca82eccf0	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08	\N	\N	\N	63725161-7dae-4578-923c-f93a3cd09943	500.00	COMPLETED	Yearly driver field work	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.715	2026-08-08 20:53:03.722
e14e5384-4ca3-4bf0-8e20-81c0c6b29acc	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	BK-000001	c288353a-509b-4c79-885e-ef46672d3da2	1d59fcd1-d99e-44ce-8daa-216c6e2fe4a8	\N	7cffb5ba-c738-4d32-8afc-dde5c24eac52	cfaf9d00-8728-49d1-a0b7-53a886d37887	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08	\N	\N	\N	087e5c7f-120b-48f6-a0b3-3b519b5f8eea	500.00	COMPLETED	\N	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.282	2026-08-08 18:48:19.494
8403f49c-b44c-4219-8285-a0a15dc21cfc	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	BK-000002	c288353a-509b-4c79-885e-ef46672d3da2	1d59fcd1-d99e-44ce-8daa-216c6e2fe4a8	\N	7cffb5ba-c738-4d32-8afc-dde5c24eac52	ea648492-50f2-41b7-a4a8-4619492d59dc	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08	\N	\N	\N	087e5c7f-120b-48f6-a0b3-3b519b5f8eea	600.00	COMPLETED	Late night after-work manual entry	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.566	2026-08-08 18:48:19.583
77ac56e7-f19f-4ee4-a6e5-4da2790e64b3	a7ed8578-e3b6-4aec-91b1-214d09748c0e	BK-000001	c6695052-1efa-42c5-8ab1-ccd4af7f7e63	701c97fe-64af-4f1e-8ab5-258d9b55a779	\N	6484d177-f18c-4e23-9f01-06985cda7644	b2573d6c-b26c-48ac-9981-ae2b22fff55a	43848b32-25a4-4d4f-81b6-2a0d65d35521	2026-08-08	\N	\N	\N	8344143e-08f9-4d04-907e-72c4ca67884b	500.00	PENDING	\N	43848b32-25a4-4d4f-81b6-2a0d65d35521	2026-08-08 18:14:58.692	2026-08-08 18:14:58.692
2593a997-ca97-42c4-abf4-d97b453b38a7	b51f455a-feb6-445f-8b08-8624162dc98b	BK-000001	4f564a37-9124-49c9-9c78-4f4b3816e536	b8f7f8d7-b477-4160-b80e-f9294813fdb0	\N	2318341c-bfbf-4505-84b8-e2cf08f239b2	e79b6786-17e5-4712-8049-3400fb02775c	fea848ba-1aa2-419d-891f-c8e4aa8d5ce6	2026-08-08	\N	\N	\N	fbb7dff9-c489-4bdc-8a78-95f954fefcb6	500.00	PENDING	\N	fea848ba-1aa2-419d-891f-c8e4aa8d5ce6	2026-08-08 18:15:07.603	2026-08-08 18:15:07.603
e4e7a9a6-e2fd-439b-ae8e-6201da3da0d8	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	BK-000003	c288353a-509b-4c79-885e-ef46672d3da2	1d59fcd1-d99e-44ce-8daa-216c6e2fe4a8	\N	7cffb5ba-c738-4d32-8afc-dde5c24eac52	5792391b-6d3a-4bde-b612-53825149abd1	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08	\N	\N	\N	087e5c7f-120b-48f6-a0b3-3b519b5f8eea	500.00	COMPLETED	Yearly driver field work	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.669	2026-08-08 18:48:19.682
ae07c13a-9cd2-43bc-90d9-dc11e197b634	3b4fa961-b987-4207-bade-425969e8e1a5	BK-000001	b53d4f04-bfe3-43af-84b8-f96f4bc99a2b	c98af7ca-0414-4c84-af7c-0297151be246	\N	47b77082-85f7-4076-a807-e46743b14d1a	829e71a7-31b1-4d8c-83ce-bb780d6c4260	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08	\N	\N	\N	dafacdd2-05f1-4125-8b1c-322fbfb08bb4	500.00	COMPLETED	\N	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.684	2026-08-08 18:15:15.875
fd6afc36-10b6-4b6e-a9f4-7407301f046b	3b4fa961-b987-4207-bade-425969e8e1a5	BK-000002	b53d4f04-bfe3-43af-84b8-f96f4bc99a2b	c98af7ca-0414-4c84-af7c-0297151be246	\N	47b77082-85f7-4076-a807-e46743b14d1a	ac32e94c-6afb-4ef4-ae91-0973fea37c05	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08	\N	\N	\N	dafacdd2-05f1-4125-8b1c-322fbfb08bb4	600.00	COMPLETED	Late night after-work manual entry	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.938	2026-08-08 18:15:15.954
67f4684e-4faf-452b-9443-2d1de7ebde7a	f33c8ba7-f382-4217-90cf-d9d133632537	BK-000001	e869070e-56da-4620-806b-9ceedd76a087	51ac0f4f-78b2-4bbb-8a96-0d1334f44760	\N	4d3bd6ff-d190-40c2-a439-0173ba1db673	719059e1-3eae-4f21-9e1b-e6c8baea80ab	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08	\N	\N	\N	e3f4f513-c321-4651-931c-70f743d22fa5	500.00	COMPLETED	\N	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:51.837	2026-08-08 18:23:52.036
d42141db-c50d-412b-8131-57e5235f2fe3	f33c8ba7-f382-4217-90cf-d9d133632537	BK-000002	e869070e-56da-4620-806b-9ceedd76a087	51ac0f4f-78b2-4bbb-8a96-0d1334f44760	\N	4d3bd6ff-d190-40c2-a439-0173ba1db673	a99d6cd7-f926-49c8-afc3-f66c71ec5243	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08	\N	\N	\N	e3f4f513-c321-4651-931c-70f743d22fa5	600.00	COMPLETED	Late night after-work manual entry	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:52.097	2026-08-08 18:23:52.114
09f89b5b-3629-4b30-a6ad-73ee0d897096	f33c8ba7-f382-4217-90cf-d9d133632537	BK-000003	e869070e-56da-4620-806b-9ceedd76a087	51ac0f4f-78b2-4bbb-8a96-0d1334f44760	\N	4d3bd6ff-d190-40c2-a439-0173ba1db673	69d0fa38-9408-427a-894b-8e37009f4451	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08	\N	\N	\N	e3f4f513-c321-4651-931c-70f743d22fa5	500.00	COMPLETED	Yearly driver field work	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:52.185	2026-08-08 18:23:52.199
c59c93d5-aeff-4a8d-83fd-ee77f7038507	c329669f-35fe-4787-84c9-902251b14695	BK-000001	89c71ed3-8045-407a-8608-336092830682	59a5ac9d-590a-48f7-a96f-c9ac07b1d62d	\N	b28aa61a-9544-4f6d-b733-7bd450ab0e53	74d9608a-08fd-4e3f-9ab2-03bf4ec6de0b	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08	\N	\N	\N	5330424f-4e69-4bdf-8336-f1ea1ae0f72e	500.00	COMPLETED	\N	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.021	2026-08-08 18:33:49.233
d69e534b-0172-4693-928a-b97e29deac70	c329669f-35fe-4787-84c9-902251b14695	BK-000002	89c71ed3-8045-407a-8608-336092830682	59a5ac9d-590a-48f7-a96f-c9ac07b1d62d	\N	b28aa61a-9544-4f6d-b733-7bd450ab0e53	d91c3a85-5b3c-4581-9499-44a70f7c24fd	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08	\N	\N	\N	5330424f-4e69-4bdf-8336-f1ea1ae0f72e	600.00	COMPLETED	Late night after-work manual entry	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.292	2026-08-08 18:33:49.305
26962e8e-bb8f-4f78-b23b-0f52c1549a24	c329669f-35fe-4787-84c9-902251b14695	BK-000003	89c71ed3-8045-407a-8608-336092830682	59a5ac9d-590a-48f7-a96f-c9ac07b1d62d	\N	b28aa61a-9544-4f6d-b733-7bd450ab0e53	1cfd404c-a11c-4bdc-a319-6ea54d6b1714	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08	\N	\N	\N	5330424f-4e69-4bdf-8336-f1ea1ae0f72e	500.00	COMPLETED	Yearly driver field work	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.368	2026-08-08 18:33:49.379
4946acf4-a12e-4c3b-b209-b7e36c649947	d8d7190c-b0f9-42e6-a510-8a401b035039	BK-000001	e432ac1c-cd6a-44d9-8177-4b9b6c5348ee	14cdcf24-a596-4b26-89b0-76b76a77f8e4	Plot 42, Sakhigopal West	e6449a5d-c8d3-45a3-8b69-5b58a620f766	2db11df0-7514-4376-bc72-9b76a2b32bce	5f50d0cf-c313-4543-aeeb-4fb8a3737b2e	2026-08-09	\N	4.00	\N	fc349e50-fdc6-4ce6-8494-6ff33d920813	800.00	PENDING	\N	5f50d0cf-c313-4543-aeeb-4fb8a3737b2e	2026-08-09 06:00:22.472	2026-08-09 06:00:22.472
4f087fdf-7751-4208-b0e9-13e99e34cbc5	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	BK-000001	5bba967b-3011-46ff-89f8-3187d4540212	427966af-2fd9-4754-ab40-80aab7b15d93	\N	fc9d0cf9-747b-4b68-87fc-8e2fc4972645	f8404ad6-a495-46da-9822-5ee75f15e530	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09	\N	\N	\N	9668fc58-b8cd-4357-baaa-8baf76a9e2fe	500.00	COMPLETED	\N	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.255	2026-08-09 05:57:15.527
5481bb47-a79e-45aa-bab2-f7cc6d9d1b5b	7a92e240-df0b-4c44-8bba-bd7574ae788b	BK-000001	de767cc0-4d15-4b4f-b447-45e2b78b582b	935d7918-51f5-4e1e-8f02-a332962f56da	Plot 42, Sakhigopal West	244e2f3a-d41d-476b-97be-5f507048c9c3	533ebebc-3805-4cca-bbe4-514d18f289b3	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09	\N	4.00	\N	21054393-d07e-4f60-84be-75cc324cba5b	800.00	COMPLETED	\N	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09 06:00:44.994	2026-08-09 06:00:45.344
0273c3f6-77d3-46e8-970c-2552c957745b	40511429-f937-4f0f-8a0a-6869154b7144	BK-000008	7d51cdc5-1713-4059-b4f3-05c7015b9fb7	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	2.00	\N	0737046e-404b-409b-8282-79e96ad9a731	1500.00	COMPLETED	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:48.035	2026-08-09 05:24:48.316
e4231c07-5b61-4f16-9b9c-7b040ca31424	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254015410-633	a2574cb7-a9e4-4fa7-932f-b8bcbeccfcaf	b2242270-ae26-4990-9a70-90a088825e77	\N	b94759ac-c1b4-4846-82ac-9ad0611f51ef	561a89dd-5391-4c0f-9a8d-4de9b1dd4331	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:15.413	2026-08-09 05:40:15.504
8336145c-8b29-4e78-a4d5-deb7814eb321	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	BK-000002	5c528eb2-01c6-4daa-8152-ddd52473eebc	278e7946-06ca-4111-81af-3852352dd65d	\N	e3cd9c96-272a-4b49-80cc-878dd0d59317	f7311eeb-777c-47bb-b230-665bc00fc539	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08	\N	\N	\N	995f2e6d-2dfc-49c5-b0c2-7873f8d2fcce	600.00	COMPLETED	Late night after-work manual entry	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.361	2026-08-08 19:41:58.376
917b5051-a895-49b9-806b-0af8b07cc757	d563fb11-8e19-4079-a843-4d579ba681ee	BK-000001	1c8d9ded-b57a-410c-9586-27799c17a308	3406cd08-5ee9-420e-a59b-d3e786e71e4c	Plot 42, Sakhigopal West	ece6db08-b21e-4738-bc77-9800dd0c5c5d	75a463db-95e9-413c-8976-8a23150e00b7	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09	\N	4.00	\N	90081924-fe98-4d79-a4a7-e332913137e0	800.00	COMPLETED	\N	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:10.641	2026-08-09 06:01:10.985
94e4917e-c897-4a20-a5fe-975d8334cab2	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	BK-000003	5c528eb2-01c6-4daa-8152-ddd52473eebc	278e7946-06ca-4111-81af-3852352dd65d	\N	e3cd9c96-272a-4b49-80cc-878dd0d59317	7596db33-02b4-4f19-b4b6-72dda4a42715	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08	\N	\N	\N	995f2e6d-2dfc-49c5-b0c2-7873f8d2fcce	500.00	COMPLETED	Yearly driver field work	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.442	2026-08-08 19:41:58.456
7f804728-32e9-4341-b000-092e6b695706	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254015552-856	a2574cb7-a9e4-4fa7-932f-b8bcbeccfcaf	b2242270-ae26-4990-9a70-90a088825e77	\N	b94759ac-c1b4-4846-82ac-9ad0611f51ef	561a89dd-5391-4c0f-9a8d-4de9b1dd4331	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:15.553	2026-08-09 05:40:15.602
c5d9e4d7-912b-4500-b739-0a12a76baa68	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254046715-721	20a7398b-5e98-4086-9c5e-7bbd07cdecd8	e23254ae-bb35-42b2-a708-ab1416f29dbb	\N	b3b1a599-c7e3-4795-ac3b-9b0ec89478af	006019a5-f6bc-4529-bdcb-5ae9b0bb365b	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:46.716	2026-08-09 05:40:46.831
1edf1f0b-6c98-431e-9257-a8a1a1afffa2	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254046892-308	20a7398b-5e98-4086-9c5e-7bbd07cdecd8	e23254ae-bb35-42b2-a708-ab1416f29dbb	\N	b3b1a599-c7e3-4795-ac3b-9b0ec89478af	006019a5-f6bc-4529-bdcb-5ae9b0bb365b	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:46.893	2026-08-09 05:40:46.96
ec1bfe4a-2a53-40b2-ba85-3bc5dc2e67be	d563fb11-8e19-4079-a843-4d579ba681ee	BK-000002	def7445f-91d4-4805-bfe7-50f6314ab0fd	3406cd08-5ee9-420e-a59b-d3e786e71e4c	Plot 108, Kalinga Agro Farm	ece6db08-b21e-4738-bc77-9800dd0c5c5d	75a463db-95e9-413c-8976-8a23150e00b7	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09	\N	10.00	\N	90081924-fe98-4d79-a4a7-e332913137e0	1000.00	COMPLETED	\N	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.127	2026-08-09 06:01:11.254
19961e12-5184-41ed-b724-ca75774410ab	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254061217-877	f3ce6283-a79c-4456-b7b5-31596b775f0b	2ebca4ce-328f-4921-b644-d74b8e7dd8a7	\N	df9d9af3-48bd-4dcb-a4c7-ad0ae5996a14	ba502108-1332-4e02-9f07-1bfdaba21ff1	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:01.218	2026-08-09 05:41:01.286
47e46ee5-2384-4f52-989c-5d217d489c36	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254061394-963	f3ce6283-a79c-4456-b7b5-31596b775f0b	2ebca4ce-328f-4921-b644-d74b8e7dd8a7	\N	df9d9af3-48bd-4dcb-a4c7-ad0ae5996a14	ba502108-1332-4e02-9f07-1bfdaba21ff1	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	WORKING	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:01.395	2026-08-09 05:41:01.395
68a87cc5-73a1-49e6-a1e9-4086fbf50f2d	6571c3c9-9c94-4b02-ac20-829a9af731b6	BK-000002	3ebee665-ab5a-40ac-b854-c0709e41d1a1	442ddcd9-735f-4e9d-8c65-ef55f4303931	\N	438e3ded-9440-4f7d-b87e-e5c7ce0b939a	dd35887e-0923-46ce-9fcc-a25f7adbeec0	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09	\N	\N	\N	a38697f1-2254-44b5-adf5-4a63ed21c97d	600.00	COMPLETED	Late night after-work manual entry	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.778	2026-08-09 08:45:02.802
516f1700-a528-4e2c-98ab-126e0bbc2eeb	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254084454-903	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	e2f0366d-60b5-44fc-90f6-5d2551a8b38a	\N	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.455	2026-08-09 05:41:24.513
f64b1aa0-d902-4ca7-acc8-29674de02fa6	b3bd9148-5bcf-46c7-aae9-d07d688834ca	BK-000003	b4c95be1-9ae6-4f25-854a-a999e6cd0cb9	64873d6e-d33c-407e-8a77-9da3526a0e22	\N	f5024078-737d-4a6e-90e7-2b28964d9722	c66895e0-8aaf-44e8-9e14-e87453cd2d5c	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09	\N	\N	\N	a8065539-a74d-4f4d-9d77-43b8f5e2d331	500.00	COMPLETED	Yearly driver field work	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.38	2026-08-09 09:03:26.389
591549bd-61a5-43fc-984c-4d8c650cdc2a	ecbba26c-b8ee-4455-a09e-86fab13778df	BK-000001	76435d2e-2dee-4c15-839f-812a8175f71a	5d1e6b71-e380-4ffc-9171-dbec16359e6c	\N	b61808f9-6b2e-4f80-8dd3-11909e2c884d	c8f29e7d-953e-4ff9-9da8-97ea57037c75	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08	\N	\N	\N	ee7706ee-25d0-4661-a2d2-725908ca6f28	500.00	COMPLETED	\N	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.128	2026-08-08 20:04:26.262
1263ff0a-a99c-4def-95bd-f7c8e3d6c4ff	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254084560-188	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	e2f0366d-60b5-44fc-90f6-5d2551a8b38a	\N	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.561	2026-08-09 05:41:24.74
de6c32ea-506a-4185-a152-4d2e7ded6f61	d563fb11-8e19-4079-a843-4d579ba681ee	BK-000003	1c8d9ded-b57a-410c-9586-27799c17a308	3406cd08-5ee9-420e-a59b-d3e786e71e4c	\N	ece6db08-b21e-4738-bc77-9800dd0c5c5d	75a463db-95e9-413c-8976-8a23150e00b7	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09	\N	\N	\N	90081924-fe98-4d79-a4a7-e332913137e0	500.00	COMPLETED	\N	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.304	2026-08-09 06:01:11.44
50c904e1-9d72-49fb-92a8-a9509a8f2145	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254085023-651	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	e2f0366d-60b5-44fc-90f6-5d2551a8b38a	\N	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:25.024	2026-08-09 05:41:25.147
8c35380a-34bd-46a8-8f51-a8a5e7cedb56	6571c3c9-9c94-4b02-ac20-829a9af731b6	BK-000003	3ebee665-ab5a-40ac-b854-c0709e41d1a1	442ddcd9-735f-4e9d-8c65-ef55f4303931	\N	438e3ded-9440-4f7d-b87e-e5c7ce0b939a	f2f5613d-b786-4575-bfd8-8610f00ec2ca	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09	\N	\N	\N	a38697f1-2254-44b5-adf5-4a63ed21c97d	500.00	COMPLETED	Yearly driver field work	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.885	2026-08-09 08:45:02.893
a0e3df07-7077-4922-a959-4a97e3bfa8ef	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	BK-000002	6186f7cd-d9d3-498b-a085-65571b3acb00	4c5c7805-d59e-4619-bb06-6894e92a6200	\N	142de1ae-b2d7-4726-a644-5f49d04e69c4	2ce7d6e0-6c2a-4a93-b1ca-f2fe3945373a	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08	\N	\N	\N	63725161-7dae-4578-923c-f93a3cd09943	600.00	COMPLETED	Late night after-work manual entry	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.628	2026-08-08 20:53:03.638
b3b48f13-43c0-4c04-ab1f-f0275909481c	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	BK-000002	cc80f7ff-acd4-4f2e-be1b-fc04c9c92b6b	1ff9a0ce-ea77-4f87-ac75-76b9cbb68836	\N	27540f0a-20ac-4e1b-bd37-c1583db03028	368ab7ff-3124-4d4e-ba94-5d7aaa262e72	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09	\N	\N	\N	1c4683a1-eee1-4dc4-af9b-9dbaed558f27	600.00	COMPLETED	Late night after-work manual entry	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.511	2026-08-09 06:01:25.523
f87d2540-dbc3-43b2-b964-72fef6fd2c2f	4613e40d-bba4-424a-970e-ffc7836a19e2	BK-000001	fdc73b9b-b552-41bb-81cc-9f39cf4a8de6	2eb23ed9-6350-4df3-8c3a-88ded33f116f	\N	5765c74a-7d2f-4443-8abe-2487b4bd6b56	d5de70d4-0b48-48f1-89fa-614e368b86c7	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09	\N	\N	\N	3586c754-2e84-4638-87f7-2c72c44d4087	500.00	COMPLETED	\N	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:58.808	2026-08-09 08:47:59.034
aa1d2888-7967-4130-b6e8-e115c50f0d2f	0757faaa-e55d-4863-9e88-c738651afa4c	BK-000001	216f19f8-cb48-4add-a5dd-78a461c7213b	66cfcc20-703f-4d71-98da-651d29c33d2c	\N	65aa4462-0a46-4bc5-aa07-bf538b853620	8eaeaffa-8cf5-4159-91de-7d3f574c1dbc	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09	\N	\N	\N	93e560ce-2ba8-48c5-869b-04bc0a349da8	500.00	COMPLETED	\N	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.003	2026-08-09 09:06:26.23
12f3aaec-3711-4de6-8996-99146a70fcfe	0757faaa-e55d-4863-9e88-c738651afa4c	BK-000002	216f19f8-cb48-4add-a5dd-78a461c7213b	66cfcc20-703f-4d71-98da-651d29c33d2c	\N	65aa4462-0a46-4bc5-aa07-bf538b853620	fd34d234-59ed-41cb-b051-4df09bac405a	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09	\N	\N	\N	93e560ce-2ba8-48c5-869b-04bc0a349da8	600.00	COMPLETED	Late night after-work manual entry	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.322	2026-08-09 09:06:26.335
53afb2d2-30ce-4277-ad17-2eaae6c8661b	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	BK-000002	3adc64f9-1328-4b58-a1d6-218054706405	72706676-33f5-48f6-875e-0e712950ce32	\N	c790842b-760d-4cad-b053-8cc6091bb4e9	1a1c7b26-79a8-4f53-9c59-d6931e847e51	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09	\N	\N	\N	bac3fb00-317e-4c7e-9641-1ea1bc33fea7	600.00	COMPLETED	Late night after-work manual entry	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.929	2026-08-09 08:53:41.95
efbb5ceb-77b8-472c-a19e-61b5170479e0	0757faaa-e55d-4863-9e88-c738651afa4c	BK-000003	216f19f8-cb48-4add-a5dd-78a461c7213b	66cfcc20-703f-4d71-98da-651d29c33d2c	\N	65aa4462-0a46-4bc5-aa07-bf538b853620	b50a96dd-1b7b-40de-a33b-4e2789e2d9ed	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09	\N	\N	\N	93e560ce-2ba8-48c5-869b-04bc0a349da8	500.00	COMPLETED	Yearly driver field work	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.391	2026-08-09 09:06:26.404
b4f93cab-a074-48b3-8319-76d72a5db136	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	BK-000001	e2134df3-7602-46b1-80bf-2b53b8eb4606	2d549ea5-d153-4d08-b460-465a6631e540	Plot 42, Sakhigopal West	a23d99b5-8b66-40fc-bf2c-ba585333b551	d51f987d-b94e-4656-a338-b7f4d8194e8e	1d1b9bf2-0cec-4b11-bb43-b5e827458a37	2026-08-09	\N	4.00	\N	e449b153-a6de-49bd-b64a-227a6f5e2011	800.00	PENDING	\N	1d1b9bf2-0cec-4b11-bb43-b5e827458a37	2026-08-09 06:00:29.789	2026-08-09 06:00:29.789
72863e74-c2f4-4664-8bd2-361afb260c1c	8951aa6b-476b-46b7-b12b-de1998c8bbf7	BK-000001	3a135d6b-b340-4bb5-9517-6e393f4ecd37	50e72c1f-2888-407c-89e5-43e5b7d58a7e	Plot 42, Sakhigopal West	c5cb5d71-cb32-42b5-a2ac-c48b8c845f7e	60e3d45f-1001-4e82-b97b-9d038d9e2a11	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09	\N	4.00	\N	b8d135df-f817-45d2-8543-fa2e325e48e6	800.00	COMPLETED	\N	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.375	2026-08-09 06:00:59.713
6825ca41-65ad-44d1-ac51-26c5e51a4aff	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	BK-000001	454328e9-c6c5-4ba1-af6c-e50c7d4ea209	a202a13a-2f16-42e8-b3dd-8b5bfd5854da	\N	b4634256-8789-4db0-88c3-0042c94986f7	ff140ae3-cd9e-4b86-a578-763adfdbef5e	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08	\N	\N	\N	906ed506-633e-4255-bb6d-056076177176	500.00	COMPLETED	\N	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:43.903	2026-08-08 19:32:44.134
085e1d1b-bd10-4bf6-8a5f-527645ef2fd2	40511429-f937-4f0f-8a0a-6869154b7144	BK-000009	5856fbf4-6104-43d0-8dea-19e0949ce0e5	5e5f9626-de91-44e6-aceb-f4b99963e0b0	\N	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09	\N	5.00	\N	0737046e-404b-409b-8282-79e96ad9a731	2000.00	COMPLETED	\N	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:48.406	2026-08-09 05:24:48.541
dc7511b9-6fcf-4730-b8b6-4e20a011aa26	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	BK-000002	454328e9-c6c5-4ba1-af6c-e50c7d4ea209	a202a13a-2f16-42e8-b3dd-8b5bfd5854da	\N	b4634256-8789-4db0-88c3-0042c94986f7	f0cab277-4386-4ba5-8f60-d63259da2085	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08	\N	\N	\N	906ed506-633e-4255-bb6d-056076177176	600.00	COMPLETED	Late night after-work manual entry	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.213	2026-08-08 19:32:44.224
488eed82-af85-4e0a-b913-aeed929249ae	8951aa6b-476b-46b7-b12b-de1998c8bbf7	BK-000002	947d7aa7-52e3-4bc9-bc6c-8c60dfc6a6e4	50e72c1f-2888-407c-89e5-43e5b7d58a7e	Plot 108, Kalinga Agro Farm	c5cb5d71-cb32-42b5-a2ac-c48b8c845f7e	60e3d45f-1001-4e82-b97b-9d038d9e2a11	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09	\N	10.00	\N	b8d135df-f817-45d2-8543-fa2e325e48e6	1000.00	COMPLETED	\N	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.817	2026-08-09 06:00:59.945
6ab3429f-2383-4980-99c5-7244afc0d29b	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	BK-000003	454328e9-c6c5-4ba1-af6c-e50c7d4ea209	a202a13a-2f16-42e8-b3dd-8b5bfd5854da	\N	b4634256-8789-4db0-88c3-0042c94986f7	5289cbb6-f1f1-4335-b5e8-5cd0a6d630f4	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08	\N	\N	\N	906ed506-633e-4255-bb6d-056076177176	500.00	COMPLETED	Yearly driver field work	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.272	2026-08-08 19:32:44.284
08f5a7af-450a-4374-a1ab-4f46cc668a5d	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254034440-258	3f591984-0ea4-41be-ba78-8c19c90edd1e	73656ab2-2173-46da-8944-532d5415fda6	\N	41629117-a351-4d4d-a340-e67c4ef2995e	00baee60-ee3c-4c8d-99aa-363aa3f1d932	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:34.441	2026-08-09 05:40:34.514
a8a397a8-71ec-497d-9745-3be4f431ca54	3968e65b-4204-432c-ad93-26a831a79d3e	BK-000001	0c615840-e4fd-46c7-865c-0e0cd1715e7a	8b485ab8-fd4f-4c80-827f-fb7a1448386d	\N	a9754ce6-cf7e-4f94-bfde-c900853d603a	9c115879-2053-4235-b1cc-f74836007f4f	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08	\N	\N	\N	54552b35-1113-48c9-8b26-7b7e502b3bae	500.00	COMPLETED	\N	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.331	2026-08-08 19:38:59.572
bc1515e9-ef2c-44ee-8246-c30b6563948c	6571c3c9-9c94-4b02-ac20-829a9af731b6	BK-000001	3ebee665-ab5a-40ac-b854-c0709e41d1a1	442ddcd9-735f-4e9d-8c65-ef55f4303931	\N	438e3ded-9440-4f7d-b87e-e5c7ce0b939a	2d7190cc-31fe-4df8-b118-327a8fe6b4b9	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09	\N	\N	\N	a38697f1-2254-44b5-adf5-4a63ed21c97d	500.00	COMPLETED	\N	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.46	2026-08-09 08:45:02.694
31e7bed5-07ee-4a70-a026-8fd6b9154931	3968e65b-4204-432c-ad93-26a831a79d3e	BK-000002	0c615840-e4fd-46c7-865c-0e0cd1715e7a	8b485ab8-fd4f-4c80-827f-fb7a1448386d	\N	a9754ce6-cf7e-4f94-bfde-c900853d603a	016521df-2c84-4b1b-b206-8ef6b9e5f4cf	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08	\N	\N	\N	54552b35-1113-48c9-8b26-7b7e502b3bae	600.00	COMPLETED	Late night after-work manual entry	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.626	2026-08-08 19:38:59.64
276ebe92-db5b-402f-bdb0-3141ccf61217	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254034553-315	3f591984-0ea4-41be-ba78-8c19c90edd1e	73656ab2-2173-46da-8944-532d5415fda6	\N	41629117-a351-4d4d-a340-e67c4ef2995e	00baee60-ee3c-4c8d-99aa-363aa3f1d932	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:34.555	2026-08-09 05:40:34.62
a210207d-d1e0-49a5-82d1-6b3a2cc7dc15	b3bd9148-5bcf-46c7-aae9-d07d688834ca	BK-000001	b4c95be1-9ae6-4f25-854a-a999e6cd0cb9	64873d6e-d33c-407e-8a77-9da3526a0e22	\N	f5024078-737d-4a6e-90e7-2b28964d9722	9969fef3-e797-4c1b-877a-578c17bc93b3	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09	\N	\N	\N	a8065539-a74d-4f4d-9d77-43b8f5e2d331	500.00	COMPLETED	\N	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.015	2026-08-09 09:03:26.211
add4274d-67e8-45b6-bc1e-5eb3aed23bae	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254053282-202	598215b8-aa2e-4db8-911e-f6f60b5e413f	aa9bbd64-00c1-4d3b-8983-2e5df9912d77	\N	ddf24861-df1a-40ce-8cbd-f8971788235e	86cf90cf-a146-4940-81a5-d36b0efee024	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:53.286	2026-08-09 05:40:53.354
31e8f624-09ce-4ba2-91d2-a2021f772560	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254053406-374	598215b8-aa2e-4db8-911e-f6f60b5e413f	aa9bbd64-00c1-4d3b-8983-2e5df9912d77	\N	ddf24861-df1a-40ce-8cbd-f8971788235e	86cf90cf-a146-4940-81a5-d36b0efee024	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	WORKING	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:53.408	2026-08-09 05:40:53.408
af28f33f-1a63-4b61-81a4-b0502a0afdfe	ecbba26c-b8ee-4455-a09e-86fab13778df	BK-000002	76435d2e-2dee-4c15-839f-812a8175f71a	5d1e6b71-e380-4ffc-9171-dbec16359e6c	\N	b61808f9-6b2e-4f80-8dd3-11909e2c884d	1eb6f6b0-2ad1-4c1c-96cc-76fcae41a0e7	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08	\N	\N	\N	ee7706ee-25d0-4661-a2d2-725908ca6f28	600.00	COMPLETED	Late night after-work manual entry	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.302	2026-08-08 20:04:26.312
c3b67438-2f2c-40c5-bcea-d9d6a2b42692	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254075468-651	b311deb8-bf37-4e1a-af29-5668c8d969a7	b2704e0f-319e-4ed7-9586-786d9069a0fb	\N	aeed00f6-2da0-4e2d-a7ec-7abd7d5e9df2	b56ded97-d5d9-4f05-afc2-ccfc280d096d	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:15.469	2026-08-09 05:41:15.525
94cea4e8-e52a-4e70-a006-e3021a017ce6	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254075567-302	b311deb8-bf37-4e1a-af29-5668c8d969a7	b2704e0f-319e-4ed7-9586-786d9069a0fb	\N	aeed00f6-2da0-4e2d-a7ec-7abd7d5e9df2	b56ded97-d5d9-4f05-afc2-ccfc280d096d	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	WORKING	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:15.571	2026-08-09 05:41:15.571
fba0e72f-d1d1-4938-8ca0-bb2603ea8434	b3bd9148-5bcf-46c7-aae9-d07d688834ca	BK-000002	b4c95be1-9ae6-4f25-854a-a999e6cd0cb9	64873d6e-d33c-407e-8a77-9da3526a0e22	\N	f5024078-737d-4a6e-90e7-2b28964d9722	12c7cdc4-3d41-44c5-a3d1-2a79734298fd	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09	\N	\N	\N	a8065539-a74d-4f4d-9d77-43b8f5e2d331	600.00	COMPLETED	Late night after-work manual entry	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.304	2026-08-09 09:03:26.318
3b7a32fe-dc91-4dc7-96de-4854ee7d0b4f	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254084778-418	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	e2f0366d-60b5-44fc-90f6-5d2551a8b38a	\N	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.78	2026-08-09 05:41:24.826
20fae768-75f8-49e0-ba9b-c8e084a6fda7	c331e53c-fe17-49c2-97f1-9466a87bbe42	B-1786254084859-216	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	e2f0366d-60b5-44fc-90f6-5d2551a8b38a	\N	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09	\N	\N	\N	2682eabd-fa60-4914-9b85-668ce62a338e	1000.00	COMPLETED	\N	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.863	2026-08-09 05:41:24.968
718780b5-7d7f-499a-93d9-c0346b046891	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	BK-000002	5bba967b-3011-46ff-89f8-3187d4540212	427966af-2fd9-4754-ab40-80aab7b15d93	\N	fc9d0cf9-747b-4b68-87fc-8e2fc4972645	901fa541-1770-4922-83b9-f49114e44896	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09	\N	\N	\N	9668fc58-b8cd-4357-baaa-8baf76a9e2fe	600.00	COMPLETED	Late night after-work manual entry	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.609	2026-08-09 05:57:15.628
723e1ea3-53ce-42a4-bef6-324ee38f62f8	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	BK-000003	5bba967b-3011-46ff-89f8-3187d4540212	427966af-2fd9-4754-ab40-80aab7b15d93	\N	fc9d0cf9-747b-4b68-87fc-8e2fc4972645	4ec7738f-5693-45b7-9e82-b5663066ad4d	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09	\N	\N	\N	9668fc58-b8cd-4357-baaa-8baf76a9e2fe	500.00	COMPLETED	Yearly driver field work	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.748	2026-08-09 05:57:15.778
f3694c61-ded1-4396-a40c-d3ab227dcc87	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	BK-000001	cc80f7ff-acd4-4f2e-be1b-fc04c9c92b6b	1ff9a0ce-ea77-4f87-ac75-76b9cbb68836	\N	27540f0a-20ac-4e1b-bd37-c1583db03028	3c57013a-0fb7-42c7-82fd-596f96e68001	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09	\N	\N	\N	1c4683a1-eee1-4dc4-af9b-9dbaed558f27	500.00	COMPLETED	\N	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.211	2026-08-09 06:01:25.431
f342d045-8f17-42f6-987b-9ffd307b9dc6	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	BK-000003	cc80f7ff-acd4-4f2e-be1b-fc04c9c92b6b	1ff9a0ce-ea77-4f87-ac75-76b9cbb68836	\N	27540f0a-20ac-4e1b-bd37-c1583db03028	1b6c0f78-b773-45c1-a7a1-5e78de790c94	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09	\N	\N	\N	1c4683a1-eee1-4dc4-af9b-9dbaed558f27	500.00	COMPLETED	Yearly driver field work	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.595	2026-08-09 06:01:25.614
2a2aaf0a-4340-4b6b-9c57-4fb57f943b97	4613e40d-bba4-424a-970e-ffc7836a19e2	BK-000002	fdc73b9b-b552-41bb-81cc-9f39cf4a8de6	2eb23ed9-6350-4df3-8c3a-88ded33f116f	\N	5765c74a-7d2f-4443-8abe-2487b4bd6b56	7d192e61-4c2c-4c3f-9637-5036343b6007	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09	\N	\N	\N	3586c754-2e84-4638-87f7-2c72c44d4087	600.00	COMPLETED	Late night after-work manual entry	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:59.116	2026-08-09 08:47:59.134
3f1b22d5-d787-43ef-86d6-96b54e8957af	4613e40d-bba4-424a-970e-ffc7836a19e2	BK-000003	fdc73b9b-b552-41bb-81cc-9f39cf4a8de6	2eb23ed9-6350-4df3-8c3a-88ded33f116f	\N	5765c74a-7d2f-4443-8abe-2487b4bd6b56	42ab42fb-00b5-42ee-8b7a-0a6db3e6a9c4	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09	\N	\N	\N	3586c754-2e84-4638-87f7-2c72c44d4087	500.00	COMPLETED	Yearly driver field work	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:59.205	2026-08-09 08:47:59.223
8097a678-4eaf-4e98-a5dc-43512752e0d4	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	BK-000001	3adc64f9-1328-4b58-a1d6-218054706405	72706676-33f5-48f6-875e-0e712950ce32	\N	c790842b-760d-4cad-b053-8cc6091bb4e9	88e5c90e-5fa1-48c3-8511-68744fffd513	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09	\N	\N	\N	bac3fb00-317e-4c7e-9641-1ea1bc33fea7	500.00	COMPLETED	\N	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.62	2026-08-09 08:53:41.85
ca2fa862-a997-4ca5-91a2-2fcb1eb1d6b7	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	BK-000003	3adc64f9-1328-4b58-a1d6-218054706405	72706676-33f5-48f6-875e-0e712950ce32	\N	c790842b-760d-4cad-b053-8cc6091bb4e9	cc727664-a212-485a-82a1-d0013c0ad9ed	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09	\N	\N	\N	bac3fb00-317e-4c7e-9641-1ea1bc33fea7	500.00	COMPLETED	Yearly driver field work	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:42.023	2026-08-09 08:53:42.035
1aca63a7-1b55-43f6-a212-067b4a8d998f	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	BK-000001	adbc29b9-d832-489a-ac6b-9fe8b37ee047	6cf34412-8c6a-4c94-8830-f20679e57499	\N	ad9d7815-3d41-44cc-847f-3b2a7628b50b	7986cfdb-6f4e-4dbb-a571-53556a4015e0	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09	\N	\N	\N	7abba147-b4bd-4a6e-a42e-449ee496b74b	500.00	COMPLETED	\N	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:27.672	2026-08-09 09:10:27.876
09e674a1-3b3c-4b77-b2ea-9a20be04a7d4	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	BK-000002	adbc29b9-d832-489a-ac6b-9fe8b37ee047	6cf34412-8c6a-4c94-8830-f20679e57499	\N	ad9d7815-3d41-44cc-847f-3b2a7628b50b	5965448a-26f4-4c56-8b8b-1c4bc14ccc5e	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09	\N	\N	\N	7abba147-b4bd-4a6e-a42e-449ee496b74b	600.00	COMPLETED	Late night after-work manual entry	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:27.988	2026-08-09 09:10:28.005
83ab09e2-4e35-4c61-ab59-4996abccf515	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	BK-000003	adbc29b9-d832-489a-ac6b-9fe8b37ee047	6cf34412-8c6a-4c94-8830-f20679e57499	\N	ad9d7815-3d41-44cc-847f-3b2a7628b50b	ca17848c-c61f-459f-80e3-4a34ef0cffbc	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09	\N	\N	\N	7abba147-b4bd-4a6e-a42e-449ee496b74b	500.00	COMPLETED	Yearly driver field work	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:28.092	2026-08-09 09:10:28.113
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.companies (id, name, slug, logo_url, theme_color, accent_color, currency, timezone, language, invoice_prefix, print_layout, is_active, created_at, updated_at, next_booking_number, next_invoice_number, address, city, district, state, pincode, country, phone, email, is_gst_registered, gstin, pan, bank_name, account_number, ifsc_code, upi_id, default_tax_rate, tax_inclusive, insurance_alert_days, license_alert_days, require_job_fuel_log, require_job_photo, service_alert_hours) FROM stdin;
c331e53c-fe17-49c2-97f1-9466a87bbe42	Phase 3A Agri Services	p3a-1786212891738	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:14:51.882	2026-08-09 05:41:25.162	2	15	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	t	t	50
a7ed8578-e3b6-4aec-91b1-214d09748c0e	Phase 3A Agri Services	p3a-1786212898344	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:14:58.547	2026-08-08 18:14:58.688	2	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
322804b0-59f9-4d1e-ba32-fab65bf9d7df	Alpha Farms 1786212258561	alpha-1786212258561	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	ALPHA-	\N	t	2026-08-08 18:04:18.74	2026-08-08 18:04:18.74	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
a35b378d-3749-4dfc-ba01-074902ef38f6	Beta Agri 1786212258561	beta-1786212258561	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	BETA-	\N	t	2026-08-08 18:04:18.745	2026-08-08 18:04:18.745	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
8fbaf386-5fd4-44cb-9119-9108a7c653c2	Beta Agri 1786212275037	beta-1786212275037	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	BETA-	\N	t	2026-08-08 18:04:35.383	2026-08-08 18:04:35.383	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
99690b52-8af1-4813-b8a1-4af071a81549	Alpha Farms 1786212285428	alpha-1786212285428	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	ALPHA-	\N	t	2026-08-08 18:04:45.642	2026-08-08 18:04:45.642	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
1a1ead59-2b11-4f2a-85e5-71c30252fbab	Beta Agri 1786212285428	beta-1786212285428	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	BETA-	\N	t	2026-08-08 18:04:45.774	2026-08-08 18:04:45.774	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
98052597-43cc-4b9a-a12b-72260f7e39ff	Alpha Farms 1786212295780	alpha-1786212295780	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	ALPHA-	\N	t	2026-08-08 18:04:56.004	2026-08-08 18:04:56.004	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
c40dd20c-a216-4766-8dd3-db89037b4bc4	Beta Agri 1786212295780	beta-1786212295780	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	BETA-	\N	t	2026-08-08 18:04:56.152	2026-08-08 18:04:56.152	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
c1abe6e7-ea71-4ee9-895f-43ce1f22863a	Alpha Farms 1786212306832	alpha-1786212306832	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	ALPHA-	\N	t	2026-08-08 18:05:07.055	2026-08-08 18:05:07.055	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	Beta Agri 1786212306832	beta-1786212306832	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	BETA-	\N	t	2026-08-08 18:05:07.203	2026-08-08 18:05:07.356	2	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
3e8490bb-07a1-497f-8b5b-8f2e470cf284	Alpha Farms 1786212317057	alpha-1786212317057	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	ALPHA-	\N	t	2026-08-08 18:05:17.286	2026-08-08 18:05:17.286	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
a6565866-d95e-4c4c-a2eb-76f3171c2907	Beta Agri 1786212317057	beta-1786212317057	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	BETA-	\N	t	2026-08-08 18:05:17.386	2026-08-08 18:05:17.526	2	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
b51f455a-feb6-445f-8b08-8624162dc98b	Phase 3A Agri Services	p3a-1786212907276	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:15:07.453	2026-08-08 18:15:07.599	2	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
74dcfe64-85b0-4051-9c2c-8292caf839ea	Alpha Custom Branding	alpha-1786212331132	\N	#1B7A3E	#2ECC71	INR	Asia/Kolkata	en	ALPHA-CUSTOM-	\N	t	2026-08-08 18:05:31.351	2026-08-08 18:05:31.906	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
2fc53fa9-07fd-4172-af37-6a1034df9ecb	Beta Custom Branding	beta-1786212331132	\N	#0000FF	#FFFF00	INR	Asia/Kolkata	en	BETA-CUSTOM-	\N	t	2026-08-08 18:05:31.464	2026-08-08 18:05:31.921	2	2	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
40511429-f937-4f0f-8a0a-6869154b7144	Alpha Farms 1786212275037	alpha-1786212275037	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	ALPHA-	\N	t	2026-08-08 18:04:35.285	2026-08-09 05:24:48.713	10	5	123 Farm Road, Sector 4	Bhubaneswar	Khordha	Odisha	751001	India	+91 9876543210	contact@shabooagri.com	t	21ABCDE1234F1Z5	ABCDE1234F	State Bank of India	300123456789	SBIN0001234	shabooagri@sbi	18.00	f	30	30	f	f	50
24791540-1249-4d93-8042-14df218f75e8	Tenant B	tenantb-1786255035872	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 05:57:15.874	2026-08-09 05:57:15.874	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
3b4fa961-b987-4207-bade-425969e8e1a5	Phase 3A Agri Services	p3a-1786212915358	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:15:15.554	2026-08-08 18:15:15.988	3	3	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
792a8883-c7de-45c3-bfbd-bfb499155e88	Tenant B	tenantb-1786212916026	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:15:16.027	2026-08-08 18:15:16.027	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
e9c09207-6fea-46d5-8f07-7464472a519a	Second Company 1786214883825	second-1786214883825	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:48:04.589	2026-08-08 18:48:04.589	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
c329669f-35fe-4787-84c9-902251b14695	Phase 3A Agri Services	p3a-1786214028682	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:33:48.878	2026-08-08 18:33:49.405	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
060fe600-4861-417a-9ad6-bcc56f645f04	Tenant B	tenantb-1786214029450	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:33:49.45	2026-08-08 18:33:49.45	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
023866d9-236a-41cc-a36f-b9e516720f54	Phase 3A Agri Services	p3a-1786212942650	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:15:42.843	2026-08-08 18:15:43.331	3	3	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
dc58310c-56f5-4321-b610-3c4f2cacf923	Tenant B	tenantb-1786212943368	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:15:43.371	2026-08-08 18:15:43.371	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
32c8de26-7af9-42c6-ad11-7c29676eedef	Company Beta 1786218114338	beta-1786218114338	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 19:41:54.339	2026-08-08 19:41:54.339	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	Phase 3A Agri Services	p3a-1786214898927	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:48:19.129	2026-08-08 18:48:19.715	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
024b72fd-44b2-4f38-96c1-78b156fa58c2	Phase 3A Agri Services	p3a-1786213353179	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:22:33.363	2026-08-08 18:22:33.894	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
034a1616-5b33-415e-a959-951733994b3d	Tenant B	tenantb-1786213353927	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:22:33.928	2026-08-08 18:22:33.928	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
3c8281f4-7608-4423-88c3-f548b432b843	Tenant B	tenantb-1786214899756	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:48:19.757	2026-08-08 18:48:19.757	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
c8db4f1b-5092-4569-bea4-eaf2910c6faa	Company Beta 1786214902868	beta-1786214902868	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:48:22.869	2026-08-08 18:48:22.869	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
f33c8ba7-f382-4217-90cf-d9d133632537	Phase 3A Agri Services	p3a-1786213431473	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 18:23:51.628	2026-08-08 18:23:52.228	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
897db3ad-f2d1-4cac-ac62-0fd98ec742b8	Tenant B	tenantb-1786213432267	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:23:52.268	2026-08-08 18:23:52.268	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	Phase 3A Agri Services	p3a-1786217563593	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 19:32:43.749	2026-08-08 19:32:44.31	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
c5979b6c-6e43-44a6-b61c-5d422764f9fd	Tenant B	tenantb-1786217564348	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 19:32:44.349	2026-08-08 19:32:44.349	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
3decee45-30cb-44d3-aa82-9c76aaaf17f9	Company Beta 1786214823848	beta-1786214823848	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:47:03.849	2026-08-08 18:47:03.849	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
655207e4-3278-43ad-862c-ded9ebab17ad	Company Beta 1786217560165	beta-1786217560165	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 19:32:40.166	2026-08-08 19:32:40.166	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
0d649779-853e-4a6a-8293-0065b1d3244b	Company Beta 1786214834397	beta-1786214834397	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:47:14.398	2026-08-08 18:47:14.398	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
1f766620-668a-48de-8607-7683021a0a54	Company Beta 1786214839734	beta-1786214839734	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:47:19.735	2026-08-08 18:47:19.735	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
91a9917a-f0fd-4190-9e08-bdffb119b6a2	Company Beta 1786214848188	beta-1786214848188	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:47:28.189	2026-08-08 18:47:28.189	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
ecc55e3b-6b1a-438b-8ca4-e87e85c5ad18	Company Beta 1786214855482	beta-1786214855482	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:47:35.483	2026-08-08 18:47:35.483	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
bf778816-9b29-4799-8e98-12ad5e14f1cc	Company Beta 1786214863010	beta-1786214863010	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:47:43.011	2026-08-08 18:47:43.011	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
a131ac13-2fcf-4978-b15d-625caa686889	Company Beta 1786217935613	beta-1786217935613	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 19:38:55.614	2026-08-08 19:38:55.614	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
8216654d-92e2-4c32-a802-59e105e5e231	Company Beta 1786214868737	beta-1786214868737	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 18:47:48.738	2026-08-08 18:47:48.738	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
3968e65b-4204-432c-ad93-26a831a79d3e	Phase 3A Agri Services	p3a-1786217938981	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 19:38:59.149	2026-08-08 19:38:59.76	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
091016e0-feb3-4416-a201-7594854530bd	Tenant B	tenantb-1786217939793	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 19:38:59.794	2026-08-08 19:38:59.794	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
f7b1fc0b-e754-404c-80be-734387e48bd6	Tenant B	tenantb-1786218118528	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 19:41:58.529	2026-08-08 19:41:58.529	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
fbf2c4d6-447e-428e-af3b-6ac4c76204c1	Phase 3A Agri Services	p3a-1786218117739	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 19:41:57.921	2026-08-08 19:41:58.484	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
f45447c4-0020-483d-b359-07f94c2c5f63	Company Beta 1786219462382	beta-1786219462382	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 20:04:22.383	2026-08-08 20:04:22.383	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
8951aa6b-476b-46b7-b12b-de1998c8bbf7	ShabooAgri Phase D Test CHC	phase-d-1786255259111	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 06:00:59.321	2026-08-09 06:00:59.962	1	3	At/PO - Nimapada, Puri	\N	Puri	Odisha	752106	India	+91-9876543210	chc@shabooagri.com	t	21AAACD1234E1ZB	AAACD1234E	State Bank of India	30987654321	SBIN0000123	chc@sbi	18.00	f	30	30	t	t	50
28214d5f-4055-4094-b5d0-b70ec7b5ae9a	Tenant B	tenantb-1786265102948	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 08:45:02.949	2026-08-09 08:45:02.949	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
42adcdf6-7d43-4c6d-b2d8-23f43ae27208	Phase 3A Agri Services	p3a-1786255034820	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 05:57:15.024	2026-08-09 05:57:15.802	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
ecbba26c-b8ee-4455-a09e-86fab13778df	Phase 3A Agri Services	p3a-1786219465844	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 20:04:25.991	2026-08-08 20:04:26.384	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
6f25dda4-1aea-411a-a006-967a8ae2d091	Tenant B	tenantb-1786219466408	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 20:04:26.409	2026-08-08 20:04:26.409	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
bf2044b6-c144-49f8-99ad-4c8b553c7bab	Company Beta 1786222379208	beta-1786222379208	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 20:52:59.21	2026-08-08 20:52:59.21	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
d563fb11-8e19-4079-a843-4d579ba681ee	ShabooAgri Phase D Test CHC	phase-d-1786255270322	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 06:01:10.586	2026-08-09 06:01:11.455	1	4	At/PO - Nimapada, Puri	\N	Puri	Odisha	752106	India	+91-9876543210	chc@shabooagri.com	t	21AAACD1234E1ZB	AAACD1234E	State Bank of India	30987654321	SBIN0000123	chc@sbi	18.00	f	30	30	t	t	50
9e6118fb-f9a3-4475-bc22-65171cb0b8a9	Company Beta 1786265105884	beta-1786265105884	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 08:45:05.886	2026-08-09 08:45:05.886	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
81a49a66-8a66-412a-baa0-0e6c9dbe9ee4	Company Beta 1786255047288	beta-1786255047288	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 05:57:27.29	2026-08-09 05:57:27.29	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
d8d7190c-b0f9-42e6-a510-8a401b035039	ShabooAgri Phase D Test CHC	phase-d-1786255222169	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 06:00:22.414	2026-08-09 06:00:22.414	1	1	At/PO - Nimapada, Puri	\N	Puri	Odisha	752106	India	+91-9876543210	chc@shabooagri.com	t	21AAACD1234E1ZB	AAACD1234E	State Bank of India	30987654321	SBIN0000123	chc@sbi	18.00	f	30	30	t	t	50
36bfd1b2-0ab4-4f49-a541-20c9e2c31271	ShabooAgri Phase D Test CHC	phase-d-1786255229493	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 06:00:29.677	2026-08-09 06:00:29.677	1	1	At/PO - Nimapada, Puri	\N	Puri	Odisha	752106	India	+91-9876543210	chc@shabooagri.com	t	21AAACD1234E1ZB	AAACD1234E	State Bank of India	30987654321	SBIN0000123	chc@sbi	18.00	f	30	30	t	t	50
7a92e240-df0b-4c44-8bba-bd7574ae788b	ShabooAgri Phase D Test CHC	phase-d-1786255244732	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 06:00:44.939	2026-08-09 06:00:45.36	1	2	At/PO - Nimapada, Puri	\N	Puri	Odisha	752106	India	+91-9876543210	chc@shabooagri.com	t	21AAACD1234E1ZB	AAACD1234E	State Bank of India	30987654321	SBIN0000123	chc@sbi	18.00	f	30	30	t	t	50
af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	Phase 3A Agri Services	p3a-1786222383212	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-08 20:53:03.334	2026-08-08 20:53:03.737	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
db589875-5456-447b-9b8e-dfcd6d46ab59	Tenant B	tenantb-1786222383762	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-08 20:53:03.763	2026-08-08 20:53:03.763	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
4f6de13b-a39b-41e2-a146-d0708f7f7d0e	Phase 3A Agri Services	p3a-1786255284752	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 06:01:24.956	2026-08-09 06:01:25.65	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
4c153bb2-2d2d-4d2e-bb1b-ae9af91f7817	Tenant B	tenantb-1786255285707	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 06:01:25.708	2026-08-09 06:01:25.708	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
00a648e6-059a-4f7c-8a0a-db23f4b72728	Company Beta 1786255296835	beta-1786255296835	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 06:01:36.837	2026-08-09 06:01:36.837	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
4613e40d-bba4-424a-970e-ffc7836a19e2	Phase 3A Agri Services	p3a-1786265278446	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 08:47:58.645	2026-08-09 08:47:59.253	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
48e08503-48e1-405c-a703-528f4218c4ae	Tenant B	tenantb-1786265279300	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 08:47:59.301	2026-08-09 08:47:59.301	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
6a965ec6-8bec-4b37-abe7-fcc032b63905	Company Beta 1786265281066	beta-1786265281066	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 08:48:01.144	2026-08-09 08:48:01.144	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
6571c3c9-9c94-4b02-ac20-829a9af731b6	Phase 3A Agri Services	p3a-1786265101879	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 08:45:02.195	2026-08-09 08:45:02.91	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
d6a5d93d-71b9-44f7-b69a-c04f12a160a5	Phase 3A Agri Services	p3a-1786265621316	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 08:53:41.451	2026-08-09 08:53:42.069	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
1c8a51f3-3862-47d8-b437-0a6d823683a2	Tenant B	tenantb-1786265622123	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 08:53:42.125	2026-08-09 08:53:42.125	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
23d1d972-91e4-4bb1-a69d-fd78bc56e666	Company Beta 1786265623397	beta-1786265623397	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 08:53:43.398	2026-08-09 08:53:43.398	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
b3bd9148-5bcf-46c7-aae9-d07d688834ca	Phase 3A Agri Services	p3a-1786266205652	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 09:03:25.863	2026-08-09 09:03:26.41	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
5c448b5c-d0a2-4d18-b6aa-cb94cda6c83e	Tenant B	tenantb-1786266206450	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:03:26.452	2026-08-09 09:03:26.452	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
83a7bea6-85d2-46e7-a1e1-b6be122ead57	Company Beta 1786266207750	beta-1786266207750	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:03:27.751	2026-08-09 09:03:27.751	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	Alpha Agri Services	alphaagriservices2	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:10:19.505	2026-08-09 09:10:19.505	1	1	\N	Jalandhar	\N	Punjab	\N	India	9166618997	s4_user_a_1786266618997@example.com	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
77e72b03-ff84-4721-bdbc-a79d00c301a6	Greenfields Custom Hiring	greenfieldscustomhiring	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:01:43.492	2026-08-09 09:01:43.492	1	1	123 Farm Road	Ludhiana	\N	Punjab	141001	India	9866102846	customer_a_1786266102846@example.com	t	03AAAAA0000A1Z5	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	Greenfields Custom Hiring	greenfieldscustomhiring1	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:01:58.059	2026-08-09 09:01:58.059	1	1	123 Farm Road	Ludhiana	\N	Punjab	141001	India	9866117437	customer_a_1786266117437@example.com	t	03AAAAA0000A1Z5	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
31fdb769-0873-405a-aed7-f54f5303d5c5	Greenfields Custom Hiring	greenfieldscustomhiring2	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:03:09.19	2026-08-09 09:03:09.19	1	1	123 Farm Road	Ludhiana	\N	Punjab	141001	India	9866188564	customer_a_1786266188564@example.com	t	03AAAAA0000A1Z5	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
1b7025b9-c122-4210-a967-97e8c1d180fd	Greenfields Custom Hiring	greenfieldscustomhiring3	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:03:19.953	2026-08-09 09:03:19.953	1	1	123 Farm Road	Ludhiana	\N	Punjab	141001	India	9866199334	customer_a_1786266199334@example.com	t	03AAAAA0000A1Z5	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
aeb2474e-c378-471b-ab64-81925a1bc912	Greenfields Custom Hiring	greenfieldscustomhiring5	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:10:21.496	2026-08-09 09:10:21.496	1	1	123 Farm Road	Ludhiana	\N	Punjab	141001	India	9866620795	customer_a_1786266620795@example.com	t	03AAAAA0000A1Z5	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
9e4b2764-62cc-4933-9014-de6fc8b82d10	Alpha Agri Services	alphaagriservices	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:06:13.608	2026-08-09 09:06:13.608	1	1	\N	Jalandhar	\N	Punjab	\N	India	9166373161	s4_user_a_1786266373161@example.com	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	Alpha Agri Services	alphaagriservices1	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:06:18.008	2026-08-09 09:06:18.008	1	1	\N	Jalandhar	\N	Punjab	\N	India	9166377512	s4_user_a_1786266377512@example.com	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
82d1d4f0-a664-4442-afb1-3c8e8deec8f8	Greenfields Custom Hiring	greenfieldscustomhiring4	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:06:19.9	2026-08-09 09:06:19.9	1	1	123 Farm Road	Ludhiana	\N	Punjab	141001	India	9866379295	customer_a_1786266379295@example.com	t	03AAAAA0000A1Z5	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
0757faaa-e55d-4863-9e88-c738651afa4c	Phase 3A Agri Services	p3a-1786266385663	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 09:06:25.806	2026-08-09 09:06:26.423	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
556f431c-794f-4777-9b7a-b87553646f0e	Tenant B	tenantb-1786266386468	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:06:26.469	2026-08-09 09:06:26.469	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
f029f473-5cf7-4e43-a467-53bf749c007f	Company Beta 1786266387848	beta-1786266387848	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:06:27.85	2026-08-09 09:06:27.85	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
1b7b1871-7a21-4e8c-9861-e5dd11985e8f	Phase 3A Agri Services	p3a-1786266627301	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	P3A	\N	t	2026-08-09 09:10:27.51	2026-08-09 09:10:28.141	4	4	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
6873fb22-34ba-46e5-8d0a-98a66f78d9c4	Tenant B	tenantb-1786266628180	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:10:28.181	2026-08-09 09:10:28.181	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
e0d94522-f11b-4854-bc46-fbea888f97fe	Company Beta 1786266629477	beta-1786266629477	\N	#1B7A3E	\N	INR	Asia/Kolkata	en	INV	\N	t	2026-08-09 09:10:29.479	2026-08-09 09:10:29.479	1	1	\N	\N	\N	\N	\N	India	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	f	30	30	f	f	50
29c82d91-d80e-4358-a180-dd5df8cae889	ShabooAgri Pilot Company	pilot	https://shabooagri.com/favicon.svg	#1B7A3E	#27AE60	INR	Asia/Kolkata	en	INV	\N	t	2026-08-07 18:54:04.643	2026-08-09 09:10:33.986	72	247	Plot 102, Farm Equipment Zone	Sambalpur	Sambalpur	Odisha	768001	India	+919876543210	contact@shabooagri.com	t	21AAAAA0000A1Z5	ABCDE1234F	State Bank of India	38492019482	SBIN0001234	shabooagri@sbi	18.00	f	30	30	f	f	50
\.


--
-- Data for Name: contact_enquiries; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.contact_enquiries (id, name, business_name, phone, email, subject, message, status, response_notes, assigned_admin_id, created_at, updated_at) FROM stdin;
316845f7-041c-45d1-bc60-c7d045396ae7	Anita Sharma	\N	9988776655	anita@example.com	Custom Enterprise Plan Enquiry	Looking for 50+ machine tracking & driver management custom enterprise quote.	UNREAD	\N	\N	2026-08-09 08:46:35.556	2026-08-09 08:46:35.556
9750393b-eb35-4fd4-8095-d005a43fcf71	Anita Sharma	\N	9988776655	anita@example.com	Custom Enterprise Plan Enquiry	Looking for 50+ machine tracking & driver management custom enterprise quote.	UNREAD	\N	\N	2026-08-09 09:03:11.938	2026-08-09 09:03:11.938
\.


--
-- Data for Name: customer_feedbacks; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.customer_feedbacks (id, saas_user_id, company_id, category, rating, comment, status, admin_notes, created_at, updated_at) FROM stdin;
d92484e4-6e60-4d3f-9f67-2b7297d06e50	b2044d11-22a7-4df3-b2fe-5513b1011e2f	\N	FEATURE_REQUEST	5	Would love automated WhatsApp PDF invoices for farmers.	SUBMITTED	\N	2026-08-09 08:46:35.569	2026-08-09 08:46:35.569
dba92ef5-1de9-4a58-858b-737f90af3d68	3788bc3f-7d6f-4b2c-a823-226ca6160bcc	\N	FEATURE_REQUEST	5	Would love automated WhatsApp PDF invoices for farmers.	SUBMITTED	\N	2026-08-09 09:03:11.952	2026-08-09 09:03:11.952
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.customers (id, company_id, user_id, name, village_id, phone, address, notes, created_at, updated_at, is_gst_applicable, gstin) FROM stdin;
c288353a-509b-4c79-885e-ef46672d3da2	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	7aa92c4e-6d79-4b2d-b121-d6f2fb93ceb6	Farmer Ramesh	1d59fcd1-d99e-44ce-8daa-216c6e2fe4a8	\N	\N	\N	2026-08-08 18:48:19.182	2026-08-08 18:48:19.182	f	\N
3a70ff38-b008-425c-92b7-33e5dbea63e2	29c82d91-d80e-4358-a180-dd5df8cae889	\N	Pricing Farmer 1786266633631	0f9d8622-4e77-4c92-bbdb-4ab467522734	\N	\N	\N	2026-08-09 09:10:33.636	2026-08-09 09:10:33.636	f	\N
454328e9-c6c5-4ba1-af6c-e50c7d4ea209	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	ce6db18a-741e-45f5-8acd-898fccf61844	Farmer Ramesh	a202a13a-2f16-42e8-b3dd-8b5bfd5854da	\N	\N	\N	2026-08-08 19:32:43.818	2026-08-08 19:32:43.818	f	\N
c58ddc73-72fc-4930-8d3e-2e878dbe04f4	c40dd20c-a216-4766-8dd3-db89037b4bc4	\N	Customer Beta	01dd9cc2-cf05-4d0f-b9ab-04bbcbb22f33	9912295780	\N	\N	2026-08-08 18:04:56.253	2026-08-08 18:04:56.253	f	\N
a6c7e3fa-3b43-49fe-b35b-74a1ec06f2ba	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	\N	Customer Beta	ce2a7e08-e1c3-418e-8059-72b172600737	9912306832	\N	\N	2026-08-08 18:05:07.31	2026-08-08 18:05:07.31	f	\N
d579b239-5b05-4d3e-b3d5-50e53adacfe6	a6565866-d95e-4c4c-a2eb-76f3171c2907	\N	Customer Beta	8383bb42-c809-45fc-8a7c-48783821f67c	9912317057	\N	\N	2026-08-08 18:05:17.486	2026-08-08 18:05:17.486	f	\N
f569aece-5806-4415-8705-f46013b37a0f	2fc53fa9-07fd-4172-af37-6a1034df9ecb	\N	Customer Beta	98793a83-0a3b-4b0e-a702-18b016b066cc	9912331132	\N	\N	2026-08-08 18:05:31.571	2026-08-08 18:05:31.571	f	\N
0c615840-e4fd-46c7-865c-0e0cd1715e7a	3968e65b-4204-432c-ad93-26a831a79d3e	15e9d8c0-3e2e-44f5-b379-dd22e9b654ca	Farmer Ramesh	8b485ab8-fd4f-4c80-827f-fb7a1448386d	\N	\N	\N	2026-08-08 19:38:59.201	2026-08-08 19:38:59.201	f	\N
0bc96c93-ac6f-42a0-a37d-7f699fff0515	c331e53c-fe17-49c2-97f1-9466a87bbe42	3e6b46be-0246-4335-ae72-a7995674e8b5	Farmer Ramesh	2f81339e-5dab-4d9e-8812-b5eaefb06cdb	\N	\N	\N	2026-08-08 18:14:51.933	2026-08-08 18:14:51.933	f	\N
c6695052-1efa-42c5-8ab1-ccd4af7f7e63	a7ed8578-e3b6-4aec-91b1-214d09748c0e	6f67e85e-d36b-49ef-be76-fad2ae9dfe2f	Farmer Ramesh	701c97fe-64af-4f1e-8ab5-258d9b55a779	\N	\N	\N	2026-08-08 18:14:58.597	2026-08-08 18:14:58.597	f	\N
4f564a37-9124-49c9-9c78-4f4b3816e536	b51f455a-feb6-445f-8b08-8624162dc98b	c1f7954a-4ecc-41f5-a77c-2954ca9ea5f1	Farmer Ramesh	b8f7f8d7-b477-4160-b80e-f9294813fdb0	\N	\N	\N	2026-08-08 18:15:07.505	2026-08-08 18:15:07.505	f	\N
b53d4f04-bfe3-43af-84b8-f96f4bc99a2b	3b4fa961-b987-4207-bade-425969e8e1a5	8535a885-c574-417f-b3c4-c8c3c3d32eea	Farmer Ramesh	c98af7ca-0414-4c84-af7c-0297151be246	\N	\N	\N	2026-08-08 18:15:15.602	2026-08-08 18:15:15.602	f	\N
5c528eb2-01c6-4daa-8152-ddd52473eebc	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	950a0247-8d2c-4c94-9b3d-b1fa7ed5a270	Farmer Ramesh	278e7946-06ca-4111-81af-3852352dd65d	\N	\N	\N	2026-08-08 19:41:57.966	2026-08-08 19:41:57.966	f	\N
76435d2e-2dee-4c15-839f-812a8175f71a	ecbba26c-b8ee-4455-a09e-86fab13778df	fda5639a-b94f-429d-af17-46825997029d	Farmer Ramesh	5d1e6b71-e380-4ffc-9171-dbec16359e6c	\N	\N	\N	2026-08-08 20:04:26.049	2026-08-08 20:04:26.049	f	\N
56627245-a7e8-4ebd-a25d-ed0a041a9a77	023866d9-236a-41cc-a36f-b9e516720f54	317c474a-ce1f-4313-8dff-0d42ad233b92	Farmer Ramesh	3b6d3980-f22c-4054-a419-0aac2d98146a	\N	\N	\N	2026-08-08 18:15:42.889	2026-08-08 18:15:42.889	f	\N
03584dfd-64c9-4296-a39f-23d2d5095195	024b72fd-44b2-4f38-96c1-78b156fa58c2	88fa7f2f-6dd4-4fda-becd-197706096891	Farmer Ramesh	0b671c70-3cb9-4f0a-8f96-1e1900f9b5d0	\N	\N	\N	2026-08-08 18:22:33.414	2026-08-08 18:22:33.414	f	\N
6186f7cd-d9d3-498b-a085-65571b3acb00	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	dfa5837a-d057-4cf3-9ac3-ccc1d888634f	Farmer Ramesh	4c5c7805-d59e-4619-bb06-6894e92a6200	\N	\N	\N	2026-08-08 20:53:03.386	2026-08-08 20:53:03.386	f	\N
e869070e-56da-4620-806b-9ceedd76a087	f33c8ba7-f382-4217-90cf-d9d133632537	9cf88260-88ea-460b-a41a-f0b4e4337f74	Farmer Ramesh	51ac0f4f-78b2-4bbb-8a96-0d1334f44760	\N	\N	\N	2026-08-08 18:23:51.68	2026-08-08 18:23:51.68	f	\N
bceeae77-91a3-438e-bd7b-ef1c2ac6fd08	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:23:27.17	2026-08-09 05:23:27.17	f	\N
4ec94854-4ffa-4395-b169-0b0df420f37c	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:23:38.062	2026-08-09 05:23:38.062	f	\N
2d76dcde-243c-4522-9c9c-e684da325161	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:23:50.856	2026-08-09 05:23:50.856	f	\N
cec5b776-ff7b-4e24-9211-5241aeadd805	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:23:59.288	2026-08-09 05:23:59.288	f	\N
c57b3018-31e6-4764-9f82-f70ba695f5b7	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:24:16.592	2026-08-09 05:24:16.592	f	\N
358e743a-0c1e-4c66-995a-09ec05aaa38f	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:24:27.967	2026-08-09 05:24:27.967	f	\N
fae25e27-94cb-4539-a75e-e4bbd03ecc9d	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:24:37.268	2026-08-09 05:24:37.268	f	\N
db50fa12-67e6-4104-bbf6-6133fde71d55	40511429-f937-4f0f-8a0a-6869154b7144	\N	GST Registered Farm Ltd	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500002	\N	\N	2026-08-09 05:24:37.578	2026-08-09 05:24:37.578	t	21AAAAA0000A1Z5
89c71ed3-8045-407a-8608-336092830682	c329669f-35fe-4787-84c9-902251b14695	e98db2bb-ca64-4d8c-ab56-a171976b2ebc	Farmer Ramesh	59a5ac9d-590a-48f7-a96f-c9ac07b1d62d	\N	\N	\N	2026-08-08 18:33:48.927	2026-08-08 18:33:48.927	f	\N
7d51cdc5-1713-4059-b4f3-05c7015b9fb7	40511429-f937-4f0f-8a0a-6869154b7144	\N	Normal Farmer Audit	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500001	\N	\N	2026-08-09 05:24:47.998	2026-08-09 05:24:47.998	f	\N
5856fbf4-6104-43d0-8dea-19e0949ce0e5	40511429-f937-4f0f-8a0a-6869154b7144	\N	GST Registered Farm Ltd	5e5f9626-de91-44e6-aceb-f4b99963e0b0	9876500002	\N	\N	2026-08-09 05:24:48.363	2026-08-09 05:24:48.363	t	21AAAAA0000A1Z5
5738ee0b-f845-4705-8a45-5b49f11f6bcf	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786253991208	96a02a8f-73c3-4d04-83d4-866c3c257409	9876591208	\N	\N	2026-08-09 05:39:51.209	2026-08-09 05:39:51.209	f	\N
3ded8507-636d-4d61-be0c-8987a4346733	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786253997152	57843258-bc6b-4965-9e26-9d7e813481a8	9876597152	\N	\N	2026-08-09 05:39:57.152	2026-08-09 05:39:57.152	f	\N
ca6d3911-a5f5-4bb1-823d-7ca0e757346e	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254005130	e32fdea7-8bfe-4de6-91c9-a990fb5aeb6d	9876505130	\N	\N	2026-08-09 05:40:05.131	2026-08-09 05:40:05.131	f	\N
a2574cb7-a9e4-4fa7-932f-b8bcbeccfcaf	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254015387	b2242270-ae26-4990-9a70-90a088825e77	9876515387	\N	\N	2026-08-09 05:40:15.388	2026-08-09 05:40:15.388	f	\N
3f591984-0ea4-41be-ba78-8c19c90edd1e	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254034409	73656ab2-2173-46da-8944-532d5415fda6	9876534409	\N	\N	2026-08-09 05:40:34.41	2026-08-09 05:40:34.41	f	\N
20a7398b-5e98-4086-9c5e-7bbd07cdecd8	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254046689	e23254ae-bb35-42b2-a708-ab1416f29dbb	9876546689	\N	\N	2026-08-09 05:40:46.69	2026-08-09 05:40:46.69	f	\N
598215b8-aa2e-4db8-911e-f6f60b5e413f	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254053243	aa9bbd64-00c1-4d3b-8983-2e5df9912d77	9876553243	\N	\N	2026-08-09 05:40:53.244	2026-08-09 05:40:53.244	f	\N
f3ce6283-a79c-4456-b7b5-31596b775f0b	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254061186	2ebca4ce-328f-4921-b644-d74b8e7dd8a7	9876561186	\N	\N	2026-08-09 05:41:01.188	2026-08-09 05:41:01.188	f	\N
b311deb8-bf37-4e1a-af29-5668c8d969a7	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254075432	b2704e0f-319e-4ed7-9586-786d9069a0fb	9876575432	\N	\N	2026-08-09 05:41:15.433	2026-08-09 05:41:15.433	f	\N
0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Test Farmer 1786254084420	e2f0366d-60b5-44fc-90f6-5d2551a8b38a	9876584420	\N	\N	2026-08-09 05:41:24.421	2026-08-09 05:41:24.421	f	\N
5bba967b-3011-46ff-89f8-3187d4540212	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	e8ba27e3-6834-4dec-9318-5acc6d073df3	Farmer Ramesh	427966af-2fd9-4754-ab40-80aab7b15d93	\N	\N	\N	2026-08-09 05:57:15.119	2026-08-09 05:57:15.119	f	\N
e432ac1c-cd6a-44d9-8177-4b9b6c5348ee	d8d7190c-b0f9-42e6-a510-8a401b035039	2b6d8bc7-7c6c-4a77-ba3b-91535ac06f83	Bhabani Sankar Farmer	14cdcf24-a596-4b26-89b0-76b76a77f8e4	93255222451	\N	\N	2026-08-09 06:00:22.455	2026-08-09 06:00:22.455	f	\N
deb5a332-5f57-469d-8502-fc176e2f077b	d8d7190c-b0f9-42e6-a510-8a401b035039	acc88958-188e-4a76-b23b-14847cb66a95	Kalinga Agro Pvt Ltd	14cdcf24-a596-4b26-89b0-76b76a77f8e4	94255222457	\N	\N	2026-08-09 06:00:22.46	2026-08-09 06:00:22.46	t	21BBBKP5678F1ZC
e2134df3-7602-46b1-80bf-2b53b8eb4606	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	6b159e7f-7c9c-4ee1-914d-7d85ad552be8	Bhabani Sankar Farmer	2d549ea5-d153-4d08-b460-465a6631e540	93255229719	\N	\N	2026-08-09 06:00:29.723	2026-08-09 06:00:29.723	f	\N
bd363206-4083-4780-8f6c-93b7364ca869	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	9bff56ae-01ca-462f-b13f-79a44df6ce06	Kalinga Agro Pvt Ltd	2d549ea5-d153-4d08-b460-465a6631e540	94255229726	\N	\N	2026-08-09 06:00:29.774	2026-08-09 06:00:29.774	t	21BBBKP5678F1ZC
de767cc0-4d15-4b4f-b447-45e2b78b582b	7a92e240-df0b-4c44-8bba-bd7574ae788b	f8eb821b-c1de-454b-9444-c18f0bb2ae74	Bhabani Sankar Farmer	935d7918-51f5-4e1e-8f02-a332962f56da	93255244974	\N	\N	2026-08-09 06:00:44.978	2026-08-09 06:00:44.978	f	\N
9adb8dc5-c9dc-4ca3-babd-c0288a54c034	7a92e240-df0b-4c44-8bba-bd7574ae788b	524858ec-9ccb-47e7-a3bb-251785b01dfc	Kalinga Agro Pvt Ltd	935d7918-51f5-4e1e-8f02-a332962f56da	94255244980	\N	\N	2026-08-09 06:00:44.983	2026-08-09 06:00:44.983	t	21BBBKP5678F1ZC
3a135d6b-b340-4bb5-9517-6e393f4ecd37	8951aa6b-476b-46b7-b12b-de1998c8bbf7	c678bb88-aabe-4504-bce3-5e9e5b372cfd	Bhabani Sankar Farmer	50e72c1f-2888-407c-89e5-43e5b7d58a7e	93255259352	\N	\N	2026-08-09 06:00:59.356	2026-08-09 06:00:59.356	f	\N
947d7aa7-52e3-4bc9-bc6c-8c60dfc6a6e4	8951aa6b-476b-46b7-b12b-de1998c8bbf7	69732086-76d1-4923-858d-1aa0a8fcf27e	Kalinga Agro Pvt Ltd	50e72c1f-2888-407c-89e5-43e5b7d58a7e	94255259360	\N	\N	2026-08-09 06:00:59.363	2026-08-09 06:00:59.363	t	21BBBKP5678F1ZC
1c8d9ded-b57a-410c-9586-27799c17a308	d563fb11-8e19-4079-a843-4d579ba681ee	4ad43eba-4797-42e3-8438-a4e4fb29bdc1	Bhabani Sankar Farmer	3406cd08-5ee9-420e-a59b-d3e786e71e4c	93255270619	\N	\N	2026-08-09 06:01:10.623	2026-08-09 06:01:10.623	f	\N
def7445f-91d4-4805-bfe7-50f6314ab0fd	d563fb11-8e19-4079-a843-4d579ba681ee	50e72b9c-e0e5-40f6-bc12-13210d1d43c9	Kalinga Agro Pvt Ltd	3406cd08-5ee9-420e-a59b-d3e786e71e4c	94255270625	\N	\N	2026-08-09 06:01:10.629	2026-08-09 06:01:10.629	t	21BBBKP5678F1ZC
cc80f7ff-acd4-4f2e-be1b-fc04c9c92b6b	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	40602102-1df0-492b-b35c-2080f2ef83a6	Farmer Ramesh	1ff9a0ce-ea77-4f87-ac75-76b9cbb68836	\N	\N	\N	2026-08-09 06:01:25.011	2026-08-09 06:01:25.011	f	\N
fdc73b9b-b552-41bb-81cc-9f39cf4a8de6	4613e40d-bba4-424a-970e-ffc7836a19e2	d52439eb-75bb-400a-8355-d2f9aebd9bbe	Farmer Ramesh	2eb23ed9-6350-4df3-8c3a-88ded33f116f	\N	\N	\N	2026-08-09 08:47:58.695	2026-08-09 08:47:58.695	f	\N
3adc64f9-1328-4b58-a1d6-218054706405	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	e1704839-2e87-41bc-adad-a95d3fcf81e5	Farmer Ramesh	72706676-33f5-48f6-875e-0e712950ce32	\N	\N	\N	2026-08-09 08:53:41.526	2026-08-09 08:53:41.526	f	\N
3ebee665-ab5a-40ac-b854-c0709e41d1a1	6571c3c9-9c94-4b02-ac20-829a9af731b6	7ac23420-347a-4e44-b10d-3812d333cfa0	Farmer Ramesh	442ddcd9-735f-4e9d-8c65-ef55f4303931	\N	\N	\N	2026-08-09 08:45:02.295	2026-08-09 08:45:02.295	f	\N
b4c95be1-9ae6-4f25-854a-a999e6cd0cb9	b3bd9148-5bcf-46c7-aae9-d07d688834ca	9679fc51-b546-447c-a1f6-715fb9d8538f	Farmer Ramesh	64873d6e-d33c-407e-8a77-9da3526a0e22	\N	\N	\N	2026-08-09 09:03:25.913	2026-08-09 09:03:25.913	f	\N
216f19f8-cb48-4add-a5dd-78a461c7213b	0757faaa-e55d-4863-9e88-c738651afa4c	ca19496d-cd8e-413d-86e4-2250ca84daa7	Farmer Ramesh	66cfcc20-703f-4d71-98da-651d29c33d2c	\N	\N	\N	2026-08-09 09:06:25.868	2026-08-09 09:06:25.868	f	\N
adbc29b9-d832-489a-ac6b-9fe8b37ee047	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	4edfbe22-8080-4b10-96db-caa3a17bb7ee	Farmer Ramesh	6cf34412-8c6a-4c94-8830-f20679e57499	\N	\N	\N	2026-08-09 09:10:27.567	2026-08-09 09:10:27.567	f	\N
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.drivers (id, company_id, employee_id, license_number, license_expiry_date, availability_status, created_at, updated_at) FROM stdin;
2d7190cc-31fe-4df8-b118-327a8fe6b4b9	6571c3c9-9c94-4b02-ac20-829a9af731b6	d5f30d75-0f39-4a72-b01b-ecd3ef90760f	\N	\N	AVAILABLE	2026-08-09 08:45:02.329	2026-08-09 08:45:02.329
2f55981e-cc66-41ed-ba86-57d45899988b	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	b1df4c23-20da-4e5e-9a85-5eea05201b42	LIC-BETA-123	\N	AVAILABLE	2026-08-08 18:05:07.317	2026-08-08 18:05:07.317
affa378c-57a7-429d-8d2b-a68cdcf354ce	a6565866-d95e-4c4c-a2eb-76f3171c2907	8e63554f-9e64-443a-821c-22e741dcdc89	LIC-BETA-123	\N	AVAILABLE	2026-08-08 18:05:17.492	2026-08-08 18:05:17.492
026b9227-d949-411b-b645-470004e4ffbf	2fc53fa9-07fd-4172-af37-6a1034df9ecb	5a509499-7744-4c12-928f-52b2d5671ae5	LIC-BETA-123	\N	AVAILABLE	2026-08-08 18:05:31.578	2026-08-08 18:05:31.578
db8d90cf-ce57-484d-a095-710c946c0811	c331e53c-fe17-49c2-97f1-9466a87bbe42	410fb180-04c8-438e-8131-ff84a5e7f9e7	\N	\N	AVAILABLE	2026-08-08 18:14:51.949	2026-08-08 18:14:51.949
1c819b53-583d-4740-9336-daf0faf8c9ee	c331e53c-fe17-49c2-97f1-9466a87bbe42	ae09e024-97b0-42ed-ae7b-492f8e180247	\N	\N	AVAILABLE	2026-08-08 18:14:51.956	2026-08-08 18:14:51.956
b2573d6c-b26c-48ac-9981-ae2b22fff55a	a7ed8578-e3b6-4aec-91b1-214d09748c0e	c9e15fdb-1bb9-4621-8fd7-ad0fa9d6a574	\N	\N	AVAILABLE	2026-08-08 18:14:58.612	2026-08-08 18:14:58.612
80e366c1-3dad-47f5-9e9b-ff9812543f63	a7ed8578-e3b6-4aec-91b1-214d09748c0e	f5286641-2830-4b86-bf7b-7a93506aa928	\N	\N	AVAILABLE	2026-08-08 18:14:58.619	2026-08-08 18:14:58.619
e79b6786-17e5-4712-8049-3400fb02775c	b51f455a-feb6-445f-8b08-8624162dc98b	9e4baebe-ca36-4657-af23-7f56c1c187e5	\N	\N	AVAILABLE	2026-08-08 18:15:07.52	2026-08-08 18:15:07.52
2b9ecb26-df53-4de0-8350-a311a70646e5	b51f455a-feb6-445f-8b08-8624162dc98b	d702f1dc-cc34-47c9-b0bd-6fb8265b65a0	\N	\N	AVAILABLE	2026-08-08 18:15:07.528	2026-08-08 18:15:07.528
829e71a7-31b1-4d8c-83ce-bb780d6c4260	3b4fa961-b987-4207-bade-425969e8e1a5	6faa8ab4-dcf6-4213-bd7c-09b4f4ad0634	\N	\N	AVAILABLE	2026-08-08 18:15:15.616	2026-08-08 18:15:15.616
ac32e94c-6afb-4ef4-ae91-0973fea37c05	3b4fa961-b987-4207-bade-425969e8e1a5	5cddae3f-2afb-4d7f-b778-77dfaf4ad557	\N	\N	AVAILABLE	2026-08-08 18:15:15.623	2026-08-08 18:15:15.623
9713d310-89ea-4939-b59d-0c8418ab1f50	023866d9-236a-41cc-a36f-b9e516720f54	db329779-a618-43f9-a6ef-386a6ae5861f	\N	\N	AVAILABLE	2026-08-08 18:15:42.907	2026-08-08 18:15:42.907
f362162c-0ef7-4562-9bfa-db40c75f9038	023866d9-236a-41cc-a36f-b9e516720f54	60a50668-260e-4073-bf09-166709798127	\N	\N	AVAILABLE	2026-08-08 18:15:42.914	2026-08-08 18:15:42.914
d411498c-9edc-42c2-99b8-c994d4bca031	024b72fd-44b2-4f38-96c1-78b156fa58c2	6805956e-8983-47d0-883a-9cd60aa3b187	\N	\N	AVAILABLE	2026-08-08 18:22:33.429	2026-08-08 18:22:33.429
05970484-ef07-48f0-af0e-697d36491891	024b72fd-44b2-4f38-96c1-78b156fa58c2	39da712c-aba3-4acb-9eba-156bb75502e5	\N	\N	AVAILABLE	2026-08-08 18:22:33.436	2026-08-08 18:22:33.436
e460d3e1-6e27-4ee6-877c-d4e664a62bcd	024b72fd-44b2-4f38-96c1-78b156fa58c2	34f77871-f203-460c-9f90-66a5a4dfce4f	\N	\N	AVAILABLE	2026-08-08 18:22:33.443	2026-08-08 18:22:33.443
719059e1-3eae-4f21-9e1b-e6c8baea80ab	f33c8ba7-f382-4217-90cf-d9d133632537	0d590824-7b29-4538-a6fa-21e82a84c5b0	\N	\N	AVAILABLE	2026-08-08 18:23:51.694	2026-08-08 18:23:51.694
a99d6cd7-f926-49c8-afc3-f66c71ec5243	f33c8ba7-f382-4217-90cf-d9d133632537	bd7d493e-ef63-40c9-82d0-123f56398a81	\N	\N	AVAILABLE	2026-08-08 18:23:51.701	2026-08-08 18:23:51.701
69d0fa38-9408-427a-894b-8e37009f4451	f33c8ba7-f382-4217-90cf-d9d133632537	fc26acf9-74c6-4ba8-87db-10c0b62370a6	\N	\N	AVAILABLE	2026-08-08 18:23:51.707	2026-08-08 18:23:51.707
74d9608a-08fd-4e3f-9ab2-03bf4ec6de0b	c329669f-35fe-4787-84c9-902251b14695	8848998f-7b8c-41dd-a9a9-ec690b0efa94	\N	\N	AVAILABLE	2026-08-08 18:33:48.942	2026-08-08 18:33:48.942
d91c3a85-5b3c-4581-9499-44a70f7c24fd	c329669f-35fe-4787-84c9-902251b14695	02c6f1b8-dc06-4f99-8b4c-26c927412d3d	\N	\N	AVAILABLE	2026-08-08 18:33:48.95	2026-08-08 18:33:48.95
1cfd404c-a11c-4bdc-a319-6ea54d6b1714	c329669f-35fe-4787-84c9-902251b14695	09ce53b9-e3bb-435a-82fd-eceda8613b53	\N	\N	AVAILABLE	2026-08-08 18:33:48.956	2026-08-08 18:33:48.956
cfaf9d00-8728-49d1-a0b7-53a886d37887	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	1bf009ec-e788-48ad-bae9-669717542773	\N	\N	AVAILABLE	2026-08-08 18:48:19.197	2026-08-08 18:48:19.197
ea648492-50f2-41b7-a4a8-4619492d59dc	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	a1461ebc-cedf-4609-8bbc-1eaf92956749	\N	\N	AVAILABLE	2026-08-08 18:48:19.204	2026-08-08 18:48:19.204
5792391b-6d3a-4bde-b612-53825149abd1	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	74648e18-7d24-4f0f-aeb6-09ba9ca256f0	\N	\N	AVAILABLE	2026-08-08 18:48:19.211	2026-08-08 18:48:19.211
ff140ae3-cd9e-4b86-a578-763adfdbef5e	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	7637cb9a-fc47-4b98-a707-f2edb4d74300	\N	\N	AVAILABLE	2026-08-08 19:32:43.832	2026-08-08 19:32:43.832
f0cab277-4386-4ba5-8f60-d63259da2085	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	9075dd2a-852b-498b-b0d8-dd98436ca4df	\N	\N	AVAILABLE	2026-08-08 19:32:43.839	2026-08-08 19:32:43.839
5289cbb6-f1f1-4335-b5e8-5cd0a6d630f4	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	89e16bef-3f60-4449-8954-ee49d66fd594	\N	\N	AVAILABLE	2026-08-08 19:32:43.846	2026-08-08 19:32:43.846
9c115879-2053-4235-b1cc-f74836007f4f	3968e65b-4204-432c-ad93-26a831a79d3e	88c1d142-049a-4681-833b-e5667ea08c17	\N	\N	AVAILABLE	2026-08-08 19:38:59.216	2026-08-08 19:38:59.216
016521df-2c84-4b1b-b206-8ef6b9e5f4cf	3968e65b-4204-432c-ad93-26a831a79d3e	c2670c5c-b009-4964-aa5e-75ab5fb3f03b	\N	\N	AVAILABLE	2026-08-08 19:38:59.223	2026-08-08 19:38:59.223
ca505264-dd8c-44de-a80b-604cb57fa768	3968e65b-4204-432c-ad93-26a831a79d3e	24000975-06d5-451c-8df2-b73c5d5846f0	\N	\N	AVAILABLE	2026-08-08 19:38:59.229	2026-08-08 19:38:59.229
4f23afea-dad1-43f4-b35d-290f442df31a	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	84bfe0a5-76da-4446-8bc3-857364fcedbf	\N	\N	AVAILABLE	2026-08-08 19:41:57.98	2026-08-08 19:41:57.98
f7311eeb-777c-47bb-b230-665bc00fc539	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	27309414-63f8-4152-bd1e-8fa18f531bb6	\N	\N	AVAILABLE	2026-08-08 19:41:57.987	2026-08-08 19:41:57.987
7596db33-02b4-4f19-b4b6-72dda4a42715	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	a96a7f8a-9cf5-43cd-8318-0dbaebb7d7de	\N	\N	AVAILABLE	2026-08-08 19:41:57.994	2026-08-08 19:41:57.994
c8f29e7d-953e-4ff9-9da8-97ea57037c75	ecbba26c-b8ee-4455-a09e-86fab13778df	86af009e-719e-4cce-a4c3-b3207c6e4f6b	\N	\N	AVAILABLE	2026-08-08 20:04:26.064	2026-08-08 20:04:26.064
1eb6f6b0-2ad1-4c1c-96cc-76fcae41a0e7	ecbba26c-b8ee-4455-a09e-86fab13778df	b2bdd3d2-e836-49cf-a625-88ac020ee40e	\N	\N	AVAILABLE	2026-08-08 20:04:26.071	2026-08-08 20:04:26.071
048dd78c-ced5-4f25-bfca-2aac3bfa190f	ecbba26c-b8ee-4455-a09e-86fab13778df	a07a1a5c-1034-461a-98ab-5520d9f0646b	\N	\N	AVAILABLE	2026-08-08 20:04:26.077	2026-08-08 20:04:26.077
fae5c1d8-f25d-474b-b3e2-cd7d613d01f3	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	89b5e269-0e01-4014-abcd-aefc86350d78	\N	\N	AVAILABLE	2026-08-08 20:53:03.402	2026-08-08 20:53:03.402
2ce7d6e0-6c2a-4a93-b1ca-f2fe3945373a	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	53681f7e-818a-4796-b685-7ca8ac8ac61c	\N	\N	AVAILABLE	2026-08-08 20:53:03.41	2026-08-08 20:53:03.41
9d3b15a8-ff37-42d9-8704-b5cca82eccf0	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	d8c3a598-b099-4183-958d-9de07486d230	\N	\N	AVAILABLE	2026-08-08 20:53:03.417	2026-08-08 20:53:03.417
bc3c685d-5076-4ad2-b3f0-921daee0523e	40511429-f937-4f0f-8a0a-6869154b7144	8038345e-aa91-4164-ba76-191efba3fc50	OD02123456	\N	AVAILABLE	2026-08-09 05:24:16.515	2026-08-09 05:24:16.515
827d35a1-e37d-4da9-8af8-4df12d35ff3a	c331e53c-fe17-49c2-97f1-9466a87bbe42	45c24ea0-d064-4d58-bcec-86ff8c91c3dd	LIC-1786253972458-N	2026-09-18	AVAILABLE	2026-08-09 05:39:32.459	2026-08-09 05:39:32.459
9b041107-0e8c-4f3c-b701-528b9bb9791a	c331e53c-fe17-49c2-97f1-9466a87bbe42	12b5c7c6-3c08-427a-84d8-cf09c0718605	LIC-1786253972462-A	2026-08-24	AVAILABLE	2026-08-09 05:39:32.464	2026-08-09 05:39:32.464
5c8b6235-493e-45a5-b06f-48797251d68e	c331e53c-fe17-49c2-97f1-9466a87bbe42	8f2b6d0c-f4c9-4061-a6ea-f1cfb54741a7	LIC-1786253985052-N	2026-09-18	AVAILABLE	2026-08-09 05:39:45.053	2026-08-09 05:39:45.053
d2c44b67-8842-4f7a-8515-64a7b8f6f01b	c331e53c-fe17-49c2-97f1-9466a87bbe42	b4f65c61-9919-45eb-9dee-1c60a11e540c	LIC-1786253985064-A	2026-08-24	AVAILABLE	2026-08-09 05:39:45.065	2026-08-09 05:39:45.065
b586e5ef-4e06-428d-a127-319e50fd8808	c331e53c-fe17-49c2-97f1-9466a87bbe42	4f4a4508-3f23-4444-99e4-888da24e833e	LIC-1786253991182-N	2026-09-18	AVAILABLE	2026-08-09 05:39:51.183	2026-08-09 05:39:51.183
eaec5af9-4ab1-4486-ac5b-312fe2541802	c331e53c-fe17-49c2-97f1-9466a87bbe42	53c2d5ec-093a-4c1d-88a2-342b85955fed	LIC-1786253991191-A	2026-08-24	AVAILABLE	2026-08-09 05:39:51.193	2026-08-09 05:39:51.193
970f544a-e25a-4c59-a8a7-541651f2ebac	c331e53c-fe17-49c2-97f1-9466a87bbe42	607f5048-f0fe-4bd8-bce8-3a12ccf103d2	LIC-1786253997127-N	2026-09-18	AVAILABLE	2026-08-09 05:39:57.128	2026-08-09 05:39:57.128
eb61b8e7-c100-4822-af5f-ab07f5531fb1	c331e53c-fe17-49c2-97f1-9466a87bbe42	022bf4ea-d398-4d15-a233-e36e48012f7a	LIC-1786253997137-A	2026-08-24	AVAILABLE	2026-08-09 05:39:57.139	2026-08-09 05:39:57.139
8f9d1423-400f-4b71-8227-33e4731ca81a	c331e53c-fe17-49c2-97f1-9466a87bbe42	b63ba894-ef40-449f-a736-97e63aac83bd	LIC-1786254005084-N	2026-09-18	AVAILABLE	2026-08-09 05:40:05.086	2026-08-09 05:40:05.086
1ba2a929-dbd8-4a01-b715-04f0e64b9414	c331e53c-fe17-49c2-97f1-9466a87bbe42	b45f5393-1f8f-4db5-9495-dd6ead488af3	LIC-1786254005101-A	2026-08-24	AVAILABLE	2026-08-09 05:40:05.103	2026-08-09 05:40:05.103
561a89dd-5391-4c0f-9a8d-4de9b1dd4331	c331e53c-fe17-49c2-97f1-9466a87bbe42	819ab5b4-47a1-47c9-91c3-130e3d019af7	LIC-1786254015359-N	2026-09-18	AVAILABLE	2026-08-09 05:40:15.361	2026-08-09 05:40:15.361
31fa3a3f-03b3-47e0-8983-20a5c5d6365b	c331e53c-fe17-49c2-97f1-9466a87bbe42	c423459f-7cbf-46b8-b31d-c284c3277263	LIC-1786254015370-A	2026-08-24	AVAILABLE	2026-08-09 05:40:15.372	2026-08-09 05:40:15.372
00baee60-ee3c-4c8d-99aa-363aa3f1d932	c331e53c-fe17-49c2-97f1-9466a87bbe42	02a0bf47-1444-4319-86f8-7d1206cbef9e	LIC-1786254034389-N	2026-09-18	AVAILABLE	2026-08-09 05:40:34.391	2026-08-09 05:40:34.391
8e1e2f84-dd01-4d37-b633-d3e9a9e9ad3a	c331e53c-fe17-49c2-97f1-9466a87bbe42	534f5994-d22e-45b7-b413-66065145b80f	LIC-1786254034397-A	2026-08-24	AVAILABLE	2026-08-09 05:40:34.398	2026-08-09 05:40:34.398
006019a5-f6bc-4529-bdcb-5ae9b0bb365b	c331e53c-fe17-49c2-97f1-9466a87bbe42	5c08e604-ebdf-49e1-8193-5528e8cb8103	LIC-1786254046649-N	2026-09-18	AVAILABLE	2026-08-09 05:40:46.651	2026-08-09 05:40:46.651
728b6813-ed75-408a-9bc6-169cfde83471	c331e53c-fe17-49c2-97f1-9466a87bbe42	956f75a4-4008-4376-be10-00ac639e5fb2	LIC-1786254046660-A	2026-08-24	AVAILABLE	2026-08-09 05:40:46.661	2026-08-09 05:40:46.661
86cf90cf-a146-4940-81a5-d36b0efee024	c331e53c-fe17-49c2-97f1-9466a87bbe42	89a1730f-fa76-45e9-8caf-992d193ef423	LIC-1786254053220-N	2026-09-18	AVAILABLE	2026-08-09 05:40:53.221	2026-08-09 05:40:53.221
d51bf91d-8c0d-4f4e-8a01-41ef888ffb69	c331e53c-fe17-49c2-97f1-9466a87bbe42	37a5a139-03a1-4ae6-8d27-8739cbfefde2	LIC-1786254053228-A	2026-08-24	AVAILABLE	2026-08-09 05:40:53.229	2026-08-09 05:40:53.229
ba502108-1332-4e02-9f07-1bfdaba21ff1	c331e53c-fe17-49c2-97f1-9466a87bbe42	01462e18-9cb7-4289-8b00-c2c485068a6a	LIC-1786254061163-N	2026-09-18	AVAILABLE	2026-08-09 05:41:01.164	2026-08-09 05:41:01.164
8a593890-be80-4b83-852c-5ed677969768	c331e53c-fe17-49c2-97f1-9466a87bbe42	1b072e4b-ae32-4576-b880-038b751a9625	LIC-1786254061171-A	2026-08-24	AVAILABLE	2026-08-09 05:41:01.172	2026-08-09 05:41:01.172
b56ded97-d5d9-4f05-afc2-ccfc280d096d	c331e53c-fe17-49c2-97f1-9466a87bbe42	1c674512-9f03-4623-bd8a-8c3f2a9edb16	LIC-1786254075299-N	2026-09-18	AVAILABLE	2026-08-09 05:41:15.3	2026-08-09 05:41:15.3
ff568a0f-7243-4830-8a8c-df0a8cde43a5	c331e53c-fe17-49c2-97f1-9466a87bbe42	aeb7ead6-8dc6-481d-9e3d-99e71aba1598	LIC-1786254075305-A	2026-08-24	AVAILABLE	2026-08-09 05:41:15.306	2026-08-09 05:41:15.306
07514d29-246d-40f0-a1f6-83e1154dbb97	c331e53c-fe17-49c2-97f1-9466a87bbe42	a31799f7-85f3-4e25-a260-810070967f70	LIC-1786254084398-N	2026-09-18	AVAILABLE	2026-08-09 05:41:24.399	2026-08-09 05:41:24.399
4952a672-cad0-44ca-969b-8a38c45027c7	c331e53c-fe17-49c2-97f1-9466a87bbe42	e46525c7-55b7-404a-b256-dce44c1326f8	LIC-1786254084408-A	2026-08-24	AVAILABLE	2026-08-09 05:41:24.409	2026-08-09 05:41:24.409
f8404ad6-a495-46da-9822-5ee75f15e530	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	cd4de908-2cb4-4c65-bbc5-232979ee289c	\N	\N	AVAILABLE	2026-08-09 05:57:15.136	2026-08-09 05:57:15.136
901fa541-1770-4922-83b9-f49114e44896	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	a207ca5f-97dd-4446-9002-b3622b2aaad5	\N	\N	AVAILABLE	2026-08-09 05:57:15.144	2026-08-09 05:57:15.144
4ec7738f-5693-45b7-9e82-b5663066ad4d	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	d7293edf-a372-4856-bbee-757bfa5950c4	\N	\N	AVAILABLE	2026-08-09 05:57:15.151	2026-08-09 05:57:15.151
2db11df0-7514-4376-bc72-9b76a2b32bce	d8d7190c-b0f9-42e6-a510-8a401b035039	e1e146a8-0b29-4e73-aabb-daba7502c05c	OD-02-2021-0098765	2026-08-24	AVAILABLE	2026-08-09 06:00:22.446	2026-08-09 06:00:22.446
d51f987d-b94e-4656-a338-b7f4d8194e8e	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	49b30366-216e-445d-b806-3b3c37cf5f4c	OD-02-2021-0098765	2026-08-24	AVAILABLE	2026-08-09 06:00:29.712	2026-08-09 06:00:29.712
533ebebc-3805-4cca-bbe4-514d18f289b3	7a92e240-df0b-4c44-8bba-bd7574ae788b	33563712-f211-43a9-8446-f92575495237	OD-02-2021-0098765	2026-08-24	AVAILABLE	2026-08-09 06:00:44.967	2026-08-09 06:00:44.967
60e3d45f-1001-4e82-b97b-9d038d9e2a11	8951aa6b-476b-46b7-b12b-de1998c8bbf7	1278f175-65c8-4220-a23a-39b85dfad898	OD-02-2021-0098765	2026-08-24	AVAILABLE	2026-08-09 06:00:59.346	2026-08-09 06:00:59.346
75a463db-95e9-413c-8976-8a23150e00b7	d563fb11-8e19-4079-a843-4d579ba681ee	99ae4173-dd17-4d33-a0fd-d92e993ccb61	OD-02-2021-0098765	2026-08-24	AVAILABLE	2026-08-09 06:01:10.614	2026-08-09 06:01:10.614
3c57013a-0fb7-42c7-82fd-596f96e68001	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	0857d647-dfbc-4ef1-ab07-2d35c6e3a2ed	\N	\N	AVAILABLE	2026-08-09 06:01:25.032	2026-08-09 06:01:25.032
368ab7ff-3124-4d4e-ba94-5d7aaa262e72	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	7ebe164e-0779-4235-a398-eb2e70d900b4	\N	\N	AVAILABLE	2026-08-09 06:01:25.041	2026-08-09 06:01:25.041
1b6c0f78-b773-45c1-a7a1-5e78de790c94	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	a29a8b7a-2abd-496e-91fd-9e4f0521a5f9	\N	\N	AVAILABLE	2026-08-09 06:01:25.048	2026-08-09 06:01:25.048
dd35887e-0923-46ce-9fcc-a25f7adbeec0	6571c3c9-9c94-4b02-ac20-829a9af731b6	858d0bed-639e-463f-99a6-0a5d8fa412a3	\N	\N	AVAILABLE	2026-08-09 08:45:02.347	2026-08-09 08:45:02.347
f2f5613d-b786-4575-bfd8-8610f00ec2ca	6571c3c9-9c94-4b02-ac20-829a9af731b6	c34e2389-8a40-401e-b556-52b86253d8d5	\N	\N	AVAILABLE	2026-08-09 08:45:02.36	2026-08-09 08:45:02.36
d5de70d4-0b48-48f1-89fa-614e368b86c7	4613e40d-bba4-424a-970e-ffc7836a19e2	71e8eb1e-b37c-4a83-b989-dcd527d39fa8	\N	\N	AVAILABLE	2026-08-09 08:47:58.709	2026-08-09 08:47:58.709
7d192e61-4c2c-4c3f-9637-5036343b6007	4613e40d-bba4-424a-970e-ffc7836a19e2	b87f5320-2447-4941-a00f-a900469bb244	\N	\N	AVAILABLE	2026-08-09 08:47:58.717	2026-08-09 08:47:58.717
42ab42fb-00b5-42ee-8b7a-0a6db3e6a9c4	4613e40d-bba4-424a-970e-ffc7836a19e2	8d93fd6e-331f-4b00-b68d-58dd21b04c99	\N	\N	AVAILABLE	2026-08-09 08:47:58.728	2026-08-09 08:47:58.728
88e5c90e-5fa1-48c3-8511-68744fffd513	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	1070e758-bec1-4960-b859-3b080bbafbc3	\N	\N	AVAILABLE	2026-08-09 08:53:41.541	2026-08-09 08:53:41.541
1a1c7b26-79a8-4f53-9c59-d6931e847e51	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	d3273cc1-daff-4341-ae53-101c9d1c40bf	\N	\N	AVAILABLE	2026-08-09 08:53:41.548	2026-08-09 08:53:41.548
cc727664-a212-485a-82a1-d0013c0ad9ed	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	886cab1f-e859-45b3-8a2c-114bedbdbabe	\N	\N	AVAILABLE	2026-08-09 08:53:41.555	2026-08-09 08:53:41.555
9969fef3-e797-4c1b-877a-578c17bc93b3	b3bd9148-5bcf-46c7-aae9-d07d688834ca	adcc0854-70dc-4760-a7dc-92e6d372acfc	\N	\N	AVAILABLE	2026-08-09 09:03:25.932	2026-08-09 09:03:25.932
12c7cdc4-3d41-44c5-a3d1-2a79734298fd	b3bd9148-5bcf-46c7-aae9-d07d688834ca	0c8f3401-251d-40c6-a1f8-6d65412e1f25	\N	\N	AVAILABLE	2026-08-09 09:03:25.939	2026-08-09 09:03:25.939
c66895e0-8aaf-44e8-9e14-e87453cd2d5c	b3bd9148-5bcf-46c7-aae9-d07d688834ca	0bfe7f8b-019c-487a-9466-315366a52f7e	\N	\N	AVAILABLE	2026-08-09 09:03:25.947	2026-08-09 09:03:25.947
8eaeaffa-8cf5-4159-91de-7d3f574c1dbc	0757faaa-e55d-4863-9e88-c738651afa4c	460cd5f6-8c52-4fb7-a467-72789bf34396	\N	\N	AVAILABLE	2026-08-09 09:06:25.897	2026-08-09 09:06:25.897
fd34d234-59ed-41cb-b051-4df09bac405a	0757faaa-e55d-4863-9e88-c738651afa4c	5cbdd8a5-7448-4b3c-bf8e-5cb690659af3	\N	\N	AVAILABLE	2026-08-09 09:06:25.909	2026-08-09 09:06:25.909
b50a96dd-1b7b-40de-a33b-4e2789e2d9ed	0757faaa-e55d-4863-9e88-c738651afa4c	da1e4ed5-776c-444f-a44a-e2b2ae1c085c	\N	\N	AVAILABLE	2026-08-09 09:06:25.921	2026-08-09 09:06:25.921
7986cfdb-6f4e-4dbb-a571-53556a4015e0	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	aa7f92d9-93c4-4770-a2a8-6873d94d4244	\N	\N	AVAILABLE	2026-08-09 09:10:27.582	2026-08-09 09:10:27.582
5965448a-26f4-4c56-8b8b-1c4bc14ccc5e	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	020b3577-f98b-40fa-9830-c3768a518a10	\N	\N	AVAILABLE	2026-08-09 09:10:27.589	2026-08-09 09:10:27.589
ca17848c-c61f-459f-80e3-4a34ef0cffbc	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	54584364-9b7f-4855-b8f4-ad2970cfa50d	\N	\N	AVAILABLE	2026-08-09 09:10:27.619	2026-08-09 09:10:27.619
85ad6580-37b6-4d3d-ae57-9981ca4307f2	29c82d91-d80e-4358-a180-dd5df8cae889	47bd0b8b-7f73-4653-91ed-5a212d0e1a25	\N	\N	AVAILABLE	2026-08-09 09:10:33.651	2026-08-09 09:10:33.651
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.employees (id, company_id, user_id, name, phone, role_title, employment_status, joined_date, created_at, updated_at, compensation_type, hourly_rate, monthly_salary, yearly_salary) FROM stdin;
86af009e-719e-4cce-a4c3-b3207c6e4f6b	ecbba26c-b8ee-4455-a09e-86fab13778df	5538f754-b4cc-4c03-b2bd-1ba39594a3ff	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.06	2026-08-08 20:04:26.06	HOURLY	300.00	\N	\N
b2bdd3d2-e836-49cf-a625-88ac020ee40e	ecbba26c-b8ee-4455-a09e-86fab13778df	18709e85-b4f1-49c6-8f5b-ce940e921fe2	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.067	2026-08-08 20:04:26.067	MONTHLY	\N	25000.00	\N
a07a1a5c-1034-461a-98ab-5520d9f0646b	ecbba26c-b8ee-4455-a09e-86fab13778df	e80ca75e-3155-4101-a708-7bc06d07402f	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.074	2026-08-08 20:04:26.074	YEARLY	\N	\N	360000.00
89b5e269-0e01-4014-abcd-aefc86350d78	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	73fcb91f-a715-4fd7-bd41-7f991e236593	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.398	2026-08-08 20:53:03.398	HOURLY	300.00	\N	\N
53681f7e-818a-4796-b685-7ca8ac8ac61c	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	3333f0a3-1a9b-4474-a710-4edad92b0682	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.406	2026-08-08 20:53:03.406	MONTHLY	\N	25000.00	\N
d8c3a598-b099-4183-958d-9de07486d230	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	2b8b8378-69f4-4df5-9105-e9d357716393	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.413	2026-08-08 20:53:03.413	YEARLY	\N	\N	360000.00
8038345e-aa91-4164-ba76-191efba3fc50	40511429-f937-4f0f-8a0a-6869154b7144	\N	Driver Audit Employee	\N	Driver	ACTIVE	\N	2026-08-09 05:24:16.512	2026-08-09 05:24:16.512	HOURLY	\N	\N	\N
45c24ea0-d064-4d58-bcec-86ff8c91c3dd	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786253972449	\N	\N	ACTIVE	\N	2026-08-09 05:39:32.451	2026-08-09 05:39:32.451	HOURLY	\N	\N	\N
12b5c7c6-3c08-427a-84d8-cf09c0718605	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786253972455	\N	\N	ACTIVE	\N	2026-08-09 05:39:32.456	2026-08-09 05:39:32.456	HOURLY	\N	\N	\N
8f2b6d0c-f4c9-4061-a6ea-f1cfb54741a7	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786253985035	\N	\N	ACTIVE	\N	2026-08-09 05:39:45.037	2026-08-09 05:39:45.037	HOURLY	\N	\N	\N
b4f65c61-9919-45eb-9dee-1c60a11e540c	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786253985044	\N	\N	ACTIVE	\N	2026-08-09 05:39:45.047	2026-08-09 05:39:45.047	HOURLY	\N	\N	\N
4f4a4508-3f23-4444-99e4-888da24e833e	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786253991159	\N	\N	ACTIVE	\N	2026-08-09 05:39:51.164	2026-08-09 05:39:51.164	HOURLY	\N	\N	\N
53c2d5ec-093a-4c1d-88a2-342b85955fed	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786253991173	\N	\N	ACTIVE	\N	2026-08-09 05:39:51.175	2026-08-09 05:39:51.175	HOURLY	\N	\N	\N
607f5048-f0fe-4bd8-bce8-3a12ccf103d2	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786253997099	\N	\N	ACTIVE	\N	2026-08-09 05:39:57.1	2026-08-09 05:39:57.1	HOURLY	\N	\N	\N
022bf4ea-d398-4d15-a233-e36e48012f7a	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786253997119	\N	\N	ACTIVE	\N	2026-08-09 05:39:57.122	2026-08-09 05:39:57.122	HOURLY	\N	\N	\N
b63ba894-ef40-449f-a736-97e63aac83bd	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254005050	\N	\N	ACTIVE	\N	2026-08-09 05:40:05.056	2026-08-09 05:40:05.056	HOURLY	\N	\N	\N
b45f5393-1f8f-4db5-9495-dd6ead488af3	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254005067	\N	\N	ACTIVE	\N	2026-08-09 05:40:05.077	2026-08-09 05:40:05.077	HOURLY	\N	\N	\N
819ab5b4-47a1-47c9-91c3-130e3d019af7	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254015338	\N	\N	ACTIVE	\N	2026-08-09 05:40:15.339	2026-08-09 05:40:15.339	HOURLY	\N	\N	\N
b1df4c23-20da-4e5e-9a85-5eea05201b42	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	\N	Beta Employee	9812306832	\N	ACTIVE	\N	2026-08-08 18:05:07.313	2026-08-08 18:05:07.313	HOURLY	\N	\N	\N
8e63554f-9e64-443a-821c-22e741dcdc89	a6565866-d95e-4c4c-a2eb-76f3171c2907	\N	Beta Employee	9812317057	\N	ACTIVE	\N	2026-08-08 18:05:17.488	2026-08-08 18:05:17.488	HOURLY	\N	\N	\N
5a509499-7744-4c12-928f-52b2d5671ae5	2fc53fa9-07fd-4172-af37-6a1034df9ecb	\N	Beta Employee	9812331132	\N	ACTIVE	\N	2026-08-08 18:05:31.574	2026-08-08 18:05:31.574	HOURLY	\N	\N	\N
c423459f-7cbf-46b8-b31d-c284c3277263	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254015351	\N	\N	ACTIVE	\N	2026-08-09 05:40:15.354	2026-08-09 05:40:15.354	HOURLY	\N	\N	\N
02a0bf47-1444-4319-86f8-7d1206cbef9e	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254034373	\N	\N	ACTIVE	\N	2026-08-09 05:40:34.375	2026-08-09 05:40:34.375	HOURLY	\N	\N	\N
534f5994-d22e-45b7-b413-66065145b80f	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254034381	\N	\N	ACTIVE	\N	2026-08-09 05:40:34.384	2026-08-09 05:40:34.384	HOURLY	\N	\N	\N
410fb180-04c8-438e-8131-ff84a5e7f9e7	c331e53c-fe17-49c2-97f1-9466a87bbe42	1d2923b0-675e-4401-81eb-22aad4b75fed	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:14:51.945	2026-08-08 18:14:51.945	HOURLY	300.00	\N	\N
ae09e024-97b0-42ed-ae7b-492f8e180247	c331e53c-fe17-49c2-97f1-9466a87bbe42	54068309-1670-4f8b-a2eb-7996f355de0b	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:14:51.953	2026-08-08 18:14:51.953	MONTHLY	\N	25000.00	\N
c9e15fdb-1bb9-4621-8fd7-ad0fa9d6a574	a7ed8578-e3b6-4aec-91b1-214d09748c0e	9cac4fe6-b878-4f35-b049-e136dedd6ef4	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:14:58.608	2026-08-08 18:14:58.608	HOURLY	300.00	\N	\N
f5286641-2830-4b86-bf7b-7a93506aa928	a7ed8578-e3b6-4aec-91b1-214d09748c0e	90390d0c-1c5e-4109-89e2-83ac41372ce6	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:14:58.616	2026-08-08 18:14:58.616	MONTHLY	\N	25000.00	\N
9e4baebe-ca36-4657-af23-7f56c1c187e5	b51f455a-feb6-445f-8b08-8624162dc98b	ba687c38-786a-44a9-9e55-33eafbe517a2	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:15:07.516	2026-08-08 18:15:07.516	HOURLY	300.00	\N	\N
d702f1dc-cc34-47c9-b0bd-6fb8265b65a0	b51f455a-feb6-445f-8b08-8624162dc98b	457304db-d5ee-4177-a472-0d10bfb78c85	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:15:07.525	2026-08-08 18:15:07.525	MONTHLY	\N	25000.00	\N
6faa8ab4-dcf6-4213-bd7c-09b4f4ad0634	3b4fa961-b987-4207-bade-425969e8e1a5	dd786252-09eb-4204-9bf1-e6a4c7b6edb1	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:15:15.612	2026-08-08 18:15:15.612	HOURLY	300.00	\N	\N
5cddae3f-2afb-4d7f-b778-77dfaf4ad557	3b4fa961-b987-4207-bade-425969e8e1a5	f725d362-797b-4e7c-99df-1ece13e5449b	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:15:15.62	2026-08-08 18:15:15.62	MONTHLY	\N	25000.00	\N
db329779-a618-43f9-a6ef-386a6ae5861f	023866d9-236a-41cc-a36f-b9e516720f54	55559d6e-72ff-4b5b-8316-3e85da1c918a	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:15:42.902	2026-08-08 18:15:42.902	HOURLY	300.00	\N	\N
60a50668-260e-4073-bf09-166709798127	023866d9-236a-41cc-a36f-b9e516720f54	41456b6b-ad9c-4ffc-8450-e92064c099e4	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:15:42.911	2026-08-08 18:15:42.911	MONTHLY	\N	25000.00	\N
6805956e-8983-47d0-883a-9cd60aa3b187	024b72fd-44b2-4f38-96c1-78b156fa58c2	8adb2011-ff63-42b6-ae52-4f4c93b9cc57	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.425	2026-08-08 18:22:33.425	HOURLY	300.00	\N	\N
39da712c-aba3-4acb-9eba-156bb75502e5	024b72fd-44b2-4f38-96c1-78b156fa58c2	864750ba-da80-415a-982e-ffe3ef62b1eb	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.433	2026-08-08 18:22:33.433	MONTHLY	\N	25000.00	\N
34f77871-f203-460c-9f90-66a5a4dfce4f	024b72fd-44b2-4f38-96c1-78b156fa58c2	4b32f683-4aa3-4e25-ac68-f6304277e701	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.44	2026-08-08 18:22:33.44	YEARLY	\N	\N	360000.00
0d590824-7b29-4538-a6fa-21e82a84c5b0	f33c8ba7-f382-4217-90cf-d9d133632537	12089328-66bc-4f40-86d7-90509e6a3d4b	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.69	2026-08-08 18:23:51.69	HOURLY	300.00	\N	\N
bd7d493e-ef63-40c9-82d0-123f56398a81	f33c8ba7-f382-4217-90cf-d9d133632537	fb92713a-712d-44e2-9731-faed364966c0	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.698	2026-08-08 18:23:51.698	MONTHLY	\N	25000.00	\N
fc26acf9-74c6-4ba8-87db-10c0b62370a6	f33c8ba7-f382-4217-90cf-d9d133632537	56da3671-5108-42a2-8609-de67319ad7b7	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.704	2026-08-08 18:23:51.704	YEARLY	\N	\N	360000.00
8848998f-7b8c-41dd-a9a9-ec690b0efa94	c329669f-35fe-4787-84c9-902251b14695	41f89ed3-dbbb-4f06-964e-c68d7c7cd33e	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.938	2026-08-08 18:33:48.938	HOURLY	300.00	\N	\N
02c6f1b8-dc06-4f99-8b4c-26c927412d3d	c329669f-35fe-4787-84c9-902251b14695	d4a99da4-8433-45c1-8db9-df1b4538fa80	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.946	2026-08-08 18:33:48.946	MONTHLY	\N	25000.00	\N
09ce53b9-e3bb-435a-82fd-eceda8613b53	c329669f-35fe-4787-84c9-902251b14695	58f52a84-76ad-4bfa-b4af-74886ff6c929	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.953	2026-08-08 18:33:48.953	YEARLY	\N	\N	360000.00
1bf009ec-e788-48ad-bae9-669717542773	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	490667a1-bfe4-4410-ab78-266e227edeca	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.193	2026-08-08 18:48:19.193	HOURLY	300.00	\N	\N
a1461ebc-cedf-4609-8bbc-1eaf92956749	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	7bc6ebaa-1cef-4f10-9c31-e84dca1d14d8	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.201	2026-08-08 18:48:19.201	MONTHLY	\N	25000.00	\N
74648e18-7d24-4f0f-aeb6-09ba9ca256f0	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	2aad45f6-d4b6-4dec-a5c8-9ed4bd3de805	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.207	2026-08-08 18:48:19.207	YEARLY	\N	\N	360000.00
7637cb9a-fc47-4b98-a707-f2edb4d74300	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	7dcc8104-ad91-4d26-9013-dfd2e3198c94	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.828	2026-08-08 19:32:43.828	HOURLY	300.00	\N	\N
9075dd2a-852b-498b-b0d8-dd98436ca4df	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	42f2b8ca-0f35-47e3-92d7-4675030938ad	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.836	2026-08-08 19:32:43.836	MONTHLY	\N	25000.00	\N
89e16bef-3f60-4449-8954-ee49d66fd594	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	e147436e-fe0c-4b63-a309-5635c65cf72a	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.842	2026-08-08 19:32:43.842	YEARLY	\N	\N	360000.00
88c1d142-049a-4681-833b-e5667ea08c17	3968e65b-4204-432c-ad93-26a831a79d3e	df4f5305-606d-4b4f-b7ce-f8bc44195415	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.212	2026-08-08 19:38:59.212	HOURLY	300.00	\N	\N
c2670c5c-b009-4964-aa5e-75ab5fb3f03b	3968e65b-4204-432c-ad93-26a831a79d3e	012367d9-5050-4d91-b603-baa9d02de1c3	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.22	2026-08-08 19:38:59.22	MONTHLY	\N	25000.00	\N
24000975-06d5-451c-8df2-b73c5d5846f0	3968e65b-4204-432c-ad93-26a831a79d3e	cb4ca09e-c02c-4b8d-9666-eb4265ada630	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.226	2026-08-08 19:38:59.226	YEARLY	\N	\N	360000.00
84bfe0a5-76da-4446-8bc3-857364fcedbf	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	dc2de281-6ad0-4c27-9d2d-39cbd0d6bcb8	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.976	2026-08-08 19:41:57.976	HOURLY	300.00	\N	\N
27309414-63f8-4152-bd1e-8fa18f531bb6	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	9bc79574-7999-4025-803b-fd40af6bf187	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.984	2026-08-08 19:41:57.984	MONTHLY	\N	25000.00	\N
a96a7f8a-9cf5-43cd-8318-0dbaebb7d7de	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	842b57fe-01a5-4da4-8a7a-0260a27386af	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.991	2026-08-08 19:41:57.991	YEARLY	\N	\N	360000.00
5c08e604-ebdf-49e1-8193-5528e8cb8103	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254046631	\N	\N	ACTIVE	\N	2026-08-09 05:40:46.632	2026-08-09 05:40:46.632	HOURLY	\N	\N	\N
956f75a4-4008-4376-be10-00ac639e5fb2	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254046642	\N	\N	ACTIVE	\N	2026-08-09 05:40:46.643	2026-08-09 05:40:46.643	HOURLY	\N	\N	\N
89a1730f-fa76-45e9-8caf-992d193ef423	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254053203	\N	\N	ACTIVE	\N	2026-08-09 05:40:53.207	2026-08-09 05:40:53.207	HOURLY	\N	\N	\N
37a5a139-03a1-4ae6-8d27-8739cbfefde2	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254053213	\N	\N	ACTIVE	\N	2026-08-09 05:40:53.214	2026-08-09 05:40:53.214	HOURLY	\N	\N	\N
01462e18-9cb7-4289-8b00-c2c485068a6a	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254061142	\N	\N	ACTIVE	\N	2026-08-09 05:41:01.143	2026-08-09 05:41:01.143	HOURLY	\N	\N	\N
1b072e4b-ae32-4576-b880-038b751a9625	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254061156	\N	\N	ACTIVE	\N	2026-08-09 05:41:01.157	2026-08-09 05:41:01.157	HOURLY	\N	\N	\N
1c674512-9f03-4623-bd8a-8c3f2a9edb16	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254075284	\N	\N	ACTIVE	\N	2026-08-09 05:41:15.287	2026-08-09 05:41:15.287	HOURLY	\N	\N	\N
aeb7ead6-8dc6-481d-9e3d-99e71aba1598	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254075294	\N	\N	ACTIVE	\N	2026-08-09 05:41:15.296	2026-08-09 05:41:15.296	HOURLY	\N	\N	\N
a31799f7-85f3-4e25-a260-810070967f70	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Normal 1786254084382	\N	\N	ACTIVE	\N	2026-08-09 05:41:24.386	2026-08-09 05:41:24.386	HOURLY	\N	\N	\N
e46525c7-55b7-404a-b256-dce44c1326f8	c331e53c-fe17-49c2-97f1-9466a87bbe42	\N	Driver Alert 1786254084391	\N	\N	ACTIVE	\N	2026-08-09 05:41:24.392	2026-08-09 05:41:24.392	HOURLY	\N	\N	\N
cd4de908-2cb4-4c65-bbc5-232979ee289c	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	c9ee60f9-f6a5-4255-96be-db06e220dc3e	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.131	2026-08-09 05:57:15.131	HOURLY	300.00	\N	\N
a207ca5f-97dd-4446-9002-b3622b2aaad5	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	08d7dfb3-6328-4aab-8a2d-a7aa3aec8df3	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.14	2026-08-09 05:57:15.14	MONTHLY	\N	25000.00	\N
d7293edf-a372-4856-bbee-757bfa5950c4	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	c36b48fb-00a0-46df-9e04-18f98f0b59fd	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.147	2026-08-09 05:57:15.147	YEARLY	\N	\N	360000.00
e1e146a8-0b29-4e73-aabb-daba7502c05c	d8d7190c-b0f9-42e6-a510-8a401b035039	1d03f950-4037-4957-9885-db13b9443b23	Suresh Driver	92255222438	Tractor Operator	ACTIVE	\N	2026-08-09 06:00:22.442	2026-08-09 06:00:22.442	HOURLY	200.00	\N	\N
49b30366-216e-445d-b806-3b3c37cf5f4c	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	1fbd1ff0-9a6f-4e6f-af26-11540a7ddcf2	Suresh Driver	92255229702	Tractor Operator	ACTIVE	\N	2026-08-09 06:00:29.707	2026-08-09 06:00:29.707	HOURLY	200.00	\N	\N
33563712-f211-43a9-8446-f92575495237	7a92e240-df0b-4c44-8bba-bd7574ae788b	f1b9be23-e341-4245-a1b1-0f0a169ca82d	Suresh Driver	92255244959	Tractor Operator	ACTIVE	\N	2026-08-09 06:00:44.963	2026-08-09 06:00:44.963	HOURLY	200.00	\N	\N
1278f175-65c8-4220-a23a-39b85dfad898	8951aa6b-476b-46b7-b12b-de1998c8bbf7	50107b72-b633-4592-a949-d53c0fd323cf	Suresh Driver	92255259339	Tractor Operator	ACTIVE	\N	2026-08-09 06:00:59.343	2026-08-09 06:00:59.343	HOURLY	200.00	\N	\N
99ae4173-dd17-4d33-a0fd-d92e993ccb61	d563fb11-8e19-4079-a843-4d579ba681ee	245f9e57-ddd8-4d1b-a0c1-658443c3af82	Suresh Driver	92255270603	Tractor Operator	ACTIVE	\N	2026-08-09 06:01:10.609	2026-08-09 06:01:10.609	HOURLY	200.00	\N	\N
0857d647-dfbc-4ef1-ab07-2d35c6e3a2ed	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	6065b7a6-480a-49b8-8c31-6fd4be470fc9	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 06:01:25.025	2026-08-09 06:01:25.025	HOURLY	300.00	\N	\N
7ebe164e-0779-4235-a398-eb2e70d900b4	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	9026f75f-32e7-44e8-88b0-afa9a9429f18	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 06:01:25.037	2026-08-09 06:01:25.037	MONTHLY	\N	25000.00	\N
a29a8b7a-2abd-496e-91fd-9e4f0521a5f9	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	06e6b2dd-3d99-43be-87a0-31e2df212a94	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 06:01:25.044	2026-08-09 06:01:25.044	YEARLY	\N	\N	360000.00
d5f30d75-0f39-4a72-b01b-ecd3ef90760f	6571c3c9-9c94-4b02-ac20-829a9af731b6	ec7b3349-dd3b-4742-8462-becffe34e1f5	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.319	2026-08-09 08:45:02.319	HOURLY	300.00	\N	\N
858d0bed-639e-463f-99a6-0a5d8fa412a3	6571c3c9-9c94-4b02-ac20-829a9af731b6	996abd4c-2156-42f1-8ea5-ee0cdb307289	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.342	2026-08-09 08:45:02.342	MONTHLY	\N	25000.00	\N
c34e2389-8a40-401e-b556-52b86253d8d5	6571c3c9-9c94-4b02-ac20-829a9af731b6	ac8a591d-165b-402f-b7e9-ccaafebd4054	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.352	2026-08-09 08:45:02.352	YEARLY	\N	\N	360000.00
71e8eb1e-b37c-4a83-b989-dcd527d39fa8	4613e40d-bba4-424a-970e-ffc7836a19e2	55c8f0bb-3bea-4765-98e9-3679ecd656f7	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.705	2026-08-09 08:47:58.705	HOURLY	300.00	\N	\N
b87f5320-2447-4941-a00f-a900469bb244	4613e40d-bba4-424a-970e-ffc7836a19e2	9a78beb7-3f4e-4332-9fff-30d286259eaf	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.713	2026-08-09 08:47:58.713	MONTHLY	\N	25000.00	\N
8d93fd6e-331f-4b00-b68d-58dd21b04c99	4613e40d-bba4-424a-970e-ffc7836a19e2	4a29d44d-7090-441a-81e1-c15b532fee2a	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.723	2026-08-09 08:47:58.723	YEARLY	\N	\N	360000.00
1070e758-bec1-4960-b859-3b080bbafbc3	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	a9e18075-e691-4161-b6dc-5db06dc2e6d8	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.537	2026-08-09 08:53:41.537	HOURLY	300.00	\N	\N
d3273cc1-daff-4341-ae53-101c9d1c40bf	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	e51d60c4-274b-4c41-babd-e05208b5c7b4	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.545	2026-08-09 08:53:41.545	MONTHLY	\N	25000.00	\N
886cab1f-e859-45b3-8a2c-114bedbdbabe	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	189dcabb-4a1b-45f6-a95f-20cc44b3fff1	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.552	2026-08-09 08:53:41.552	YEARLY	\N	\N	360000.00
adcc0854-70dc-4760-a7dc-92e6d372acfc	b3bd9148-5bcf-46c7-aae9-d07d688834ca	48f8866c-c5d5-48b2-9568-c4e675e0ea9c	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.927	2026-08-09 09:03:25.927	HOURLY	300.00	\N	\N
0c8f3401-251d-40c6-a1f8-6d65412e1f25	b3bd9148-5bcf-46c7-aae9-d07d688834ca	11d4f63d-9c03-42f4-9c8e-b00f02b44466	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.936	2026-08-09 09:03:25.936	MONTHLY	\N	25000.00	\N
0bfe7f8b-019c-487a-9466-315366a52f7e	b3bd9148-5bcf-46c7-aae9-d07d688834ca	9e4dea60-f36e-400e-a12d-829e8bb6c084	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.943	2026-08-09 09:03:25.943	YEARLY	\N	\N	360000.00
460cd5f6-8c52-4fb7-a467-72789bf34396	0757faaa-e55d-4863-9e88-c738651afa4c	871b4c6b-fc8c-4eb6-98cc-806d58383705	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.889	2026-08-09 09:06:25.889	HOURLY	300.00	\N	\N
5cbdd8a5-7448-4b3c-bf8e-5cb690659af3	0757faaa-e55d-4863-9e88-c738651afa4c	c81e19bb-e3ec-4b60-bbf4-9c2b2c7029ad	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.904	2026-08-09 09:06:25.904	MONTHLY	\N	25000.00	\N
da1e4ed5-776c-444f-a44a-e2b2ae1c085c	0757faaa-e55d-4863-9e88-c738651afa4c	2940ccdb-8b42-4bb1-87eb-4efa17615db2	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.915	2026-08-09 09:06:25.915	YEARLY	\N	\N	360000.00
aa7f92d9-93c4-4770-a2a8-6873d94d4244	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	8b024334-4a27-4d38-b587-d7e1afa3643d	Hourly Driver Vikas	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.577	2026-08-09 09:10:27.577	HOURLY	300.00	\N	\N
020b3577-f98b-40fa-9830-c3768a518a10	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	1ca775b5-3d6d-4ec9-88d5-2f22f4e963c8	Monthly Driver Sunil	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.585	2026-08-09 09:10:27.585	MONTHLY	\N	25000.00	\N
54584364-9b7f-4855-b8f4-ad2970cfa50d	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	e8253196-3d1a-4b26-8b9c-2b82084a65f1	Yearly Driver Amit	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.613	2026-08-09 09:10:27.613	YEARLY	\N	\N	360000.00
47bd0b8b-7f73-4653-91ed-5a212d0e1a25	29c82d91-d80e-4358-a180-dd5df8cae889	\N	Pricing Driver	\N	\N	ACTIVE	\N	2026-08-09 09:10:33.646	2026-08-09 09:10:33.646	HOURLY	250.00	\N	\N
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.expense_categories (id, company_id, name) FROM stdin;
bcf27a47-2fb5-48bb-99be-1613e24debb8	29c82d91-d80e-4358-a180-dd5df8cae889	Fuel & Oil
0655bd99-6baf-4c49-a482-f786b19d3ebf	29c82d91-d80e-4358-a180-dd5df8cae889	Spare Parts & Repairs
22ae5643-a8e7-41f3-9804-2b2a83cb632c	29c82d91-d80e-4358-a180-dd5df8cae889	Driver & Operator Allowance
8fc9c946-8cbd-4077-ab8a-8a7f75a08818	29c82d91-d80e-4358-a180-dd5df8cae889	Tooling & Maintenance
af2d2da9-0c69-46a9-aef6-47bcf731961a	29c82d91-d80e-4358-a180-dd5df8cae889	Office & Administrative
a7690678-ff86-483a-aa8a-0e50d9d09cb4	29c82d91-d80e-4358-a180-dd5df8cae889	Miscellaneous
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.expenses (id, company_id, category_id, machine_id, amount, description, incurred_by, expense_date, created_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.invoices (id, company_id, invoice_number, booking_id, customer_id, total_amount, paid_amount, balance_amount, status, invoice_date, due_date, print_layout_snapshot, created_at, updated_at, is_gst_applicable, subtotal_amount, tax_rate, tax_amount, cgst_amount, sgst_amount, igst_amount) FROM stdin;
0b7ee7a2-9aca-43ab-8573-43b66e7cddca	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	P3A-000001	c79049d8-ef5b-47ef-803b-c22bcc545285	5c528eb2-01c6-4daa-8152-ddd52473eebc	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:41:58.315	2026-08-08 19:41:58.315	f	\N	0.00	0.00	0.00	0.00	0.00
a74191d7-3e19-4a09-b6cf-7aaa817d539d	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	P3A-000002	8336145c-8b29-4e78-a4d5-deb7814eb321	5c528eb2-01c6-4daa-8152-ddd52473eebc	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:41:58.412	2026-08-08 19:41:58.412	f	\N	0.00	0.00	0.00	0.00	0.00
62db887d-1db4-467a-867b-cfaed179e826	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	P3A-000003	94e4917e-c897-4a20-a5fe-975d8334cab2	5c528eb2-01c6-4daa-8152-ddd52473eebc	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:41:58.487	2026-08-08 19:41:58.487	f	\N	0.00	0.00	0.00	0.00	0.00
9385ab5a-0278-4f76-8fda-919b3d5da478	3b4fa961-b987-4207-bade-425969e8e1a5	P3A-000001	ae07c13a-9cd2-43bc-90d9-dc11e197b634	b53d4f04-bfe3-43af-84b8-f96f4bc99a2b	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:15:15.897	2026-08-08 18:15:15.897	f	\N	0.00	0.00	0.00	0.00	0.00
7b034929-3bb1-4a32-add3-cf78848cbbb9	3b4fa961-b987-4207-bade-425969e8e1a5	P3A-000002	fd6afc36-10b6-4b6e-a9f4-7407301f046b	b53d4f04-bfe3-43af-84b8-f96f4bc99a2b	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:15:15.992	2026-08-08 18:15:15.992	f	\N	0.00	0.00	0.00	0.00	0.00
95819eed-68f9-4292-bff8-007609f82385	c329669f-35fe-4787-84c9-902251b14695	P3A-000001	c59c93d5-aeff-4a8d-83fd-ee77f7038507	89c71ed3-8045-407a-8608-336092830682	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:33:49.253	2026-08-08 18:33:49.253	f	\N	0.00	0.00	0.00	0.00	0.00
453aec0f-d859-4eae-bf03-5f25621eaf77	c329669f-35fe-4787-84c9-902251b14695	P3A-000002	d69e534b-0172-4693-928a-b97e29deac70	89c71ed3-8045-407a-8608-336092830682	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:33:49.343	2026-08-08 18:33:49.343	f	\N	0.00	0.00	0.00	0.00	0.00
6ecf30ad-c34d-4d60-8797-a022979ec711	c329669f-35fe-4787-84c9-902251b14695	P3A-000003	26962e8e-bb8f-4f78-b23b-0f52c1549a24	89c71ed3-8045-407a-8608-336092830682	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:33:49.408	2026-08-08 18:33:49.408	f	\N	0.00	0.00	0.00	0.00	0.00
4dc5072d-4817-4e9c-b7f9-2a98d1842b40	ecbba26c-b8ee-4455-a09e-86fab13778df	P3A-000001	591549bd-61a5-43fc-984c-4d8c650cdc2a	76435d2e-2dee-4c15-839f-812a8175f71a	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 20:04:26.276	2026-08-08 20:04:26.276	f	\N	0.00	0.00	0.00	0.00	0.00
dda40ef8-c8eb-439c-bf70-7b199ed41098	ecbba26c-b8ee-4455-a09e-86fab13778df	P3A-000002	af28f33f-1a63-4b61-81a4-b0502a0afdfe	76435d2e-2dee-4c15-839f-812a8175f71a	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 20:04:26.338	2026-08-08 20:04:26.338	f	\N	0.00	0.00	0.00	0.00	0.00
c63433bb-06dc-4a13-824f-a6fb717270f7	ecbba26c-b8ee-4455-a09e-86fab13778df	P3A-000003	46f42d68-b2bc-4c52-aabb-f069c55992f8	76435d2e-2dee-4c15-839f-812a8175f71a	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 20:04:26.387	2026-08-08 20:04:26.387	f	\N	0.00	0.00	0.00	0.00	0.00
9df5110d-87ed-4aba-a767-24f3554c9a1d	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	P3A-000001	e14e5384-4ca3-4bf0-8e20-81c0c6b29acc	c288353a-509b-4c79-885e-ef46672d3da2	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:48:19.514	2026-08-08 18:48:19.514	f	\N	0.00	0.00	0.00	0.00	0.00
fa3e4c08-a520-4b9d-b998-f276714229da	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	P3A-000002	8403f49c-b44c-4219-8285-a0a15dc21cfc	c288353a-509b-4c79-885e-ef46672d3da2	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:48:19.629	2026-08-08 18:48:19.629	f	\N	0.00	0.00	0.00	0.00	0.00
9d2caebf-9132-457f-b192-9ca2da0e8223	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	P3A-000003	e4e7a9a6-e2fd-439b-ae8e-6201da3da0d8	c288353a-509b-4c79-885e-ef46672d3da2	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:48:19.72	2026-08-08 18:48:19.72	f	\N	0.00	0.00	0.00	0.00	0.00
d43d7bba-1ecb-4540-9212-328f609141f4	023866d9-236a-41cc-a36f-b9e516720f54	P3A-000001	efac0575-b89e-47fa-ae52-aa2e6b0c54fa	56627245-a7e8-4ebd-a25d-ed0a041a9a77	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:15:43.228	2026-08-08 18:15:43.228	f	\N	0.00	0.00	0.00	0.00	0.00
bc6d9bf0-e468-4ae1-9c38-5c1713cf1f9f	023866d9-236a-41cc-a36f-b9e516720f54	P3A-000002	9d1bc692-b543-444b-9a49-1eb5e225fcb1	56627245-a7e8-4ebd-a25d-ed0a041a9a77	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:15:43.335	2026-08-08 18:15:43.335	f	\N	0.00	0.00	0.00	0.00	0.00
90d4287a-d324-4667-a7e6-d5d67e5c9986	024b72fd-44b2-4f38-96c1-78b156fa58c2	P3A-000001	00f1cddc-14d8-4db0-a01d-f65478d0a43a	03584dfd-64c9-4296-a39f-23d2d5095195	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:22:33.745	2026-08-08 18:22:33.745	f	\N	0.00	0.00	0.00	0.00	0.00
71553621-1f98-48be-8382-b92352c88cc4	024b72fd-44b2-4f38-96c1-78b156fa58c2	P3A-000002	e25e74f0-3354-4150-b33a-0d6462b76df8	03584dfd-64c9-4296-a39f-23d2d5095195	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:22:33.833	2026-08-08 18:22:33.833	f	\N	0.00	0.00	0.00	0.00	0.00
884b9cd7-2828-4854-aa7d-f4e4d910f77d	024b72fd-44b2-4f38-96c1-78b156fa58c2	P3A-000003	3e0cd0a4-5889-49a7-8d50-13850f0f2ebd	03584dfd-64c9-4296-a39f-23d2d5095195	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:22:33.897	2026-08-08 18:22:33.897	f	\N	0.00	0.00	0.00	0.00	0.00
d82eda01-e05c-4a16-9fb4-00a0ebceb98c	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	P3A-000001	d7a5fa51-d422-49d6-a62d-22fac5d25cb6	6186f7cd-d9d3-498b-a085-65571b3acb00	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 20:53:03.601	2026-08-08 20:53:03.601	f	\N	0.00	0.00	0.00	0.00	0.00
aee6a521-88d8-413e-b193-e1770b5be74d	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	P3A-000002	a0e3df07-7077-4922-a959-4a97e3bfa8ef	6186f7cd-d9d3-498b-a085-65571b3acb00	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 20:53:03.682	2026-08-08 20:53:03.682	f	\N	0.00	0.00	0.00	0.00	0.00
2b6db5da-8669-420d-8662-52ee9245b199	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	P3A-000003	49f5ad86-5cc6-4c3e-a994-51b73911ae3c	6186f7cd-d9d3-498b-a085-65571b3acb00	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 20:53:03.739	2026-08-08 20:53:03.739	f	\N	0.00	0.00	0.00	0.00	0.00
8a5e95c6-1c78-49d6-ad18-95ddf25445c2	40511429-f937-4f0f-8a0a-6869154b7144	ALPHA--000001	e2f59f8e-7a23-4143-8688-e0c39138f6b1	fae25e27-94cb-4539-a75e-e4bbd03ecc9d	3000.00	0.00	3000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:24:37.548	2026-08-09 05:24:37.548	f	3000.00	0.00	0.00	0.00	0.00	0.00
ae2e4930-7efc-4e39-af8a-31c156cfc0a8	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000009	c3b67438-2f2c-40c5-bcea-d9d6a2b42692	b311deb8-bf37-4e1a-af29-5668c8d969a7	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:41:15.539	2026-08-09 05:41:15.539	f	2000.00	0.00	0.00	0.00	0.00	0.00
10dbf931-b7a0-4dbb-87f4-f66dd5977d4c	40511429-f937-4f0f-8a0a-6869154b7144	ALPHA--000002	f2822944-a077-49aa-8467-8165c80b177b	db50fa12-67e6-4104-bbf6-6133fde71d55	11200.00	0.00	11200.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:24:37.794	2026-08-09 05:24:37.897	t	10000.00	12.00	1200.00	600.00	600.00	0.00
a11c4bcd-8630-4c40-96f2-8f644f4551b7	40511429-f937-4f0f-8a0a-6869154b7144	ALPHA--000003	0273c3f6-77d3-46e8-970c-2552c957745b	7d51cdc5-1713-4059-b4f3-05c7015b9fb7	3000.00	0.00	3000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:24:48.33	2026-08-09 05:24:48.33	f	3000.00	0.00	0.00	0.00	0.00	0.00
90ace37a-f326-4986-9727-14766e9f7644	f33c8ba7-f382-4217-90cf-d9d133632537	P3A-000001	67f4684e-4faf-452b-9443-2d1de7ebde7a	e869070e-56da-4620-806b-9ceedd76a087	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:23:52.061	2026-08-08 18:23:52.061	f	\N	0.00	0.00	0.00	0.00	0.00
82cd69ae-ab15-4de8-8ad8-82c3026e141a	f33c8ba7-f382-4217-90cf-d9d133632537	P3A-000002	d42141db-c50d-412b-8131-57e5235f2fe3	e869070e-56da-4620-806b-9ceedd76a087	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:23:52.163	2026-08-08 18:23:52.163	f	\N	0.00	0.00	0.00	0.00	0.00
07f4c9ca-4513-450d-a9da-6f99d47fa010	f33c8ba7-f382-4217-90cf-d9d133632537	P3A-000003	09f89b5b-3629-4b30-a6ad-73ee0d897096	e869070e-56da-4620-806b-9ceedd76a087	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 18:23:52.232	2026-08-08 18:23:52.232	f	\N	0.00	0.00	0.00	0.00	0.00
44929c41-6b1f-4a56-a32f-661aab7d905f	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000010	516f1700-a528-4e2c-98ab-126e0bbc2eeb	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:41:24.531	2026-08-09 05:41:24.531	f	2000.00	0.00	0.00	0.00	0.00	0.00
f256efeb-ea5b-4e8d-b347-5adbaa64b8c8	40511429-f937-4f0f-8a0a-6869154b7144	ALPHA--000004	085e1d1b-bd10-4bf6-8a5f-527645ef2fd2	5856fbf4-6104-43d0-8dea-19e0949ce0e5	11200.00	0.00	11200.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:24:48.552	2026-08-09 05:24:48.686	t	10000.00	12.00	1200.00	600.00	600.00	0.00
c0cbdf51-8959-4a6b-a8ad-35cb58b42609	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	P3A-000001	6825ca41-65ad-44d1-ac51-26c5e51a4aff	454328e9-c6c5-4ba1-af6c-e50c7d4ea209	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:32:44.161	2026-08-08 19:32:44.161	f	\N	0.00	0.00	0.00	0.00	0.00
718913c3-5128-4237-a1b4-4e3f8cfc8857	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	P3A-000002	dc7511b9-6fcf-4730-b8b6-4e20a011aa26	454328e9-c6c5-4ba1-af6c-e50c7d4ea209	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:32:44.249	2026-08-08 19:32:44.249	f	\N	0.00	0.00	0.00	0.00	0.00
4c3f2a04-0a3c-4356-adc4-6d4072e569d2	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	P3A-000003	6ab3429f-2383-4980-99c5-7244afc0d29b	454328e9-c6c5-4ba1-af6c-e50c7d4ea209	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:32:44.314	2026-08-08 19:32:44.314	f	\N	0.00	0.00	0.00	0.00	0.00
82389f8f-2182-4c0c-bc47-7ec90fc1b285	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000001	e4231c07-5b61-4f16-9b9c-7b040ca31424	a2574cb7-a9e4-4fa7-932f-b8bcbeccfcaf	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:40:15.522	2026-08-09 05:40:15.522	f	2000.00	0.00	0.00	0.00	0.00	0.00
600fdb6e-a73e-4d1f-a3d5-74e574f420ec	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000002	7f804728-32e9-4341-b000-092e6b695706	a2574cb7-a9e4-4fa7-932f-b8bcbeccfcaf	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:40:15.62	2026-08-09 05:40:15.62	f	2000.00	0.00	0.00	0.00	0.00	0.00
1483a761-64ec-413d-a916-3c010a8cb713	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000003	08f5a7af-450a-4374-a1ab-4f46cc668a5d	3f591984-0ea4-41be-ba78-8c19c90edd1e	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:40:34.531	2026-08-09 05:40:34.531	f	2000.00	0.00	0.00	0.00	0.00	0.00
23a506ee-db20-4301-8051-f41eb472b2cb	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000004	276ebe92-db5b-402f-bdb0-3141ccf61217	3f591984-0ea4-41be-ba78-8c19c90edd1e	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:40:34.631	2026-08-09 05:40:34.631	f	2000.00	0.00	0.00	0.00	0.00	0.00
95d9a77d-62f9-447c-8d1a-c12c22785081	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000005	c5d9e4d7-912b-4500-b739-0a12a76baa68	20a7398b-5e98-4086-9c5e-7bbd07cdecd8	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:40:46.855	2026-08-09 05:40:46.855	f	2000.00	0.00	0.00	0.00	0.00	0.00
b521ba62-8a31-4d2c-bae5-66d2f090bada	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000006	1edf1f0b-6c98-431e-9257-a8a1a1afffa2	20a7398b-5e98-4086-9c5e-7bbd07cdecd8	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:40:46.975	2026-08-09 05:40:46.975	f	2000.00	0.00	0.00	0.00	0.00	0.00
38d7abe1-331d-4304-abc6-149fd3636286	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000007	add4274d-67e8-45b6-bc1e-5eb3aed23bae	598215b8-aa2e-4db8-911e-f6f60b5e413f	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:40:53.371	2026-08-09 05:40:53.371	f	2000.00	0.00	0.00	0.00	0.00	0.00
4494794b-6444-4653-b745-510f45f24c43	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000008	19961e12-5184-41ed-b724-ca75774410ab	f3ce6283-a79c-4456-b7b5-31596b775f0b	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:41:01.308	2026-08-09 05:41:01.308	f	2000.00	0.00	0.00	0.00	0.00	0.00
ad69c6e6-a6bc-42c9-be94-38cd34ade859	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000011	1263ff0a-a99c-4def-95bd-f7c8e3d6c4ff	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	2000.00	0.00	2000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:41:24.752	2026-08-09 05:41:24.752	f	2000.00	0.00	0.00	0.00	0.00	0.00
2c323653-9790-443f-a07c-f0f7cc538b9b	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000012	3b7a32fe-dc91-4dc7-96de-4854ee7d0b4f	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	3000.00	0.00	3000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:41:24.838	2026-08-09 05:41:24.838	f	3000.00	0.00	0.00	0.00	0.00	0.00
9aa8b065-fc00-485a-b0b6-adcdad522732	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000013	20fae768-75f8-49e0-ba9b-c8e084a6fda7	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	3000.00	0.00	3000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:41:24.987	2026-08-09 05:41:24.987	f	3000.00	0.00	0.00	0.00	0.00	0.00
793dbbde-f2b2-463d-b559-03a7bd362f47	3968e65b-4204-432c-ad93-26a831a79d3e	P3A-000001	a8a397a8-71ec-497d-9745-3be4f431ca54	0c615840-e4fd-46c7-865c-0e0cd1715e7a	1250.00	0.00	1250.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:38:59.585	2026-08-08 19:38:59.585	f	\N	0.00	0.00	0.00	0.00	0.00
7914f90f-9238-4aba-8250-3af915e77821	3968e65b-4204-432c-ad93-26a831a79d3e	P3A-000002	31e7bed5-07ee-4a70-a026-8fd6b9154931	0c615840-e4fd-46c7-865c-0e0cd1715e7a	2400.00	0.00	2400.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:38:59.674	2026-08-08 19:38:59.674	f	\N	0.00	0.00	0.00	0.00	0.00
1ef49609-6e1b-44da-9447-dfbf4b4453b3	3968e65b-4204-432c-ad93-26a831a79d3e	P3A-000003	02f93844-2adb-41c2-9635-6084d2666f3d	0c615840-e4fd-46c7-865c-0e0cd1715e7a	2500.00	0.00	2500.00	UNPAID	2026-08-08	\N	\N	2026-08-08 19:38:59.762	2026-08-08 19:38:59.762	f	\N	0.00	0.00	0.00	0.00	0.00
ea6473af-70be-4258-adb8-5f2c7a354578	c331e53c-fe17-49c2-97f1-9466a87bbe42	P3A-000014	50c904e1-9d72-49fb-92a8-a9509a8f2145	0fb2fbb1-7826-4fe9-a4ca-ffdec68cba62	4000.00	0.00	4000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:41:25.166	2026-08-09 05:41:25.166	f	4000.00	0.00	0.00	0.00	0.00	0.00
510e16c9-9ac3-4f79-9b4a-53d02427c937	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	P3A-000001	4f087fdf-7751-4208-b0e9-13e99e34cbc5	5bba967b-3011-46ff-89f8-3187d4540212	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:57:15.551	2026-08-09 05:57:15.551	f	1250.00	0.00	0.00	0.00	0.00	0.00
33f33b35-2a21-4920-b293-0af26f50810f	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	P3A-000002	718780b5-7d7f-499a-93d9-c0346b046891	5bba967b-3011-46ff-89f8-3187d4540212	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:57:15.675	2026-08-09 05:57:15.675	f	2400.00	0.00	0.00	0.00	0.00	0.00
e3397c68-51fb-48b7-94aa-32093d9101e3	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	P3A-000003	723e1ea3-53ce-42a4-bef6-324ee38f62f8	5bba967b-3011-46ff-89f8-3187d4540212	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 05:57:15.806	2026-08-09 05:57:15.806	f	2500.00	0.00	0.00	0.00	0.00	0.00
104c5801-65ef-43a3-9057-90739918670d	0757faaa-e55d-4863-9e88-c738651afa4c	P3A-000001	aa1d2888-7967-4130-b6e8-e115c50f0d2f	216f19f8-cb48-4add-a5dd-78a461c7213b	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:06:26.258	2026-08-09 09:06:26.258	f	1250.00	0.00	0.00	0.00	0.00	0.00
cf50f428-060a-43e4-9aaa-e10cc3b35458	6571c3c9-9c94-4b02-ac20-829a9af731b6	P3A-000001	bc1515e9-ef2c-44ee-8246-c30b6563948c	3ebee665-ab5a-40ac-b854-c0709e41d1a1	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:45:02.719	2026-08-09 08:45:02.719	f	1250.00	0.00	0.00	0.00	0.00	0.00
b072a53d-eca5-4033-9355-a81a703b2fc2	6571c3c9-9c94-4b02-ac20-829a9af731b6	P3A-000002	68a87cc5-73a1-49e6-a1e9-4086fbf50f2d	3ebee665-ab5a-40ac-b854-c0709e41d1a1	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:45:02.845	2026-08-09 08:45:02.845	f	2400.00	0.00	0.00	0.00	0.00	0.00
61ced321-bdc7-4fb0-87bb-5339c2200c7b	6571c3c9-9c94-4b02-ac20-829a9af731b6	P3A-000003	8c35380a-34bd-46a8-8f51-a8a5e7cedb56	3ebee665-ab5a-40ac-b854-c0709e41d1a1	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:45:02.913	2026-08-09 08:45:02.913	f	2500.00	0.00	0.00	0.00	0.00	0.00
a8deed2d-b6ee-42c1-8ff5-2635b82645e1	0757faaa-e55d-4863-9e88-c738651afa4c	P3A-000002	12f3aaec-3711-4de6-8996-99146a70fcfe	216f19f8-cb48-4add-a5dd-78a461c7213b	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:06:26.359	2026-08-09 09:06:26.359	f	2400.00	0.00	0.00	0.00	0.00	0.00
e116e9e1-6486-4864-a413-cffe7b64b927	0757faaa-e55d-4863-9e88-c738651afa4c	P3A-000003	efbb5ceb-77b8-472c-a19e-61b5170479e0	216f19f8-cb48-4add-a5dd-78a461c7213b	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:06:26.426	2026-08-09 09:06:26.426	f	2500.00	0.00	0.00	0.00	0.00	0.00
a4b004c7-2d4e-45b9-8eef-53e96ba45036	7a92e240-df0b-4c44-8bba-bd7574ae788b	INV-000001	5481bb47-a79e-45aa-bab2-f7cc6d9d1b5b	de767cc0-4d15-4b4f-b447-45e2b78b582b	4000.00	0.00	4000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 06:00:45.366	2026-08-09 06:00:45.366	f	4000.00	0.00	0.00	0.00	0.00	0.00
18a9a419-9dce-4f09-bde7-ceb8130b684d	8951aa6b-476b-46b7-b12b-de1998c8bbf7	INV-000001	72863e74-c2f4-4664-8bd2-361afb260c1c	3a135d6b-b340-4bb5-9517-6e393f4ecd37	4000.00	4000.00	0.00	PAID	2026-08-09	\N	\N	2026-08-09 06:00:59.726	2026-08-09 06:00:59.782	f	4000.00	0.00	0.00	0.00	0.00	0.00
12d3a383-80e7-4d82-859e-c13deba33b2e	8951aa6b-476b-46b7-b12b-de1998c8bbf7	INV-000002	488eed82-af85-4e0a-b913-aeed929249ae	947d7aa7-52e3-4bc9-bc6c-8c60dfc6a6e4	10000.00	0.00	10000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 06:00:59.965	2026-08-09 06:00:59.965	f	10000.00	0.00	0.00	0.00	0.00	0.00
cb3f061f-1b9d-4056-a4e4-437696ca40f4	d563fb11-8e19-4079-a843-4d579ba681ee	INV-000001	917b5051-a895-49b9-806b-0af8b07cc757	1c8d9ded-b57a-410c-9586-27799c17a308	4000.00	4000.00	0.00	PAID	2026-08-09	\N	\N	2026-08-09 06:01:11.002	2026-08-09 06:01:11.086	f	4000.00	0.00	0.00	0.00	0.00	0.00
3ab4ae6d-3191-4377-995a-40931f6bb940	d563fb11-8e19-4079-a843-4d579ba681ee	INV-000002	ec1bfe4a-2a53-40b2-ba85-3bc5dc2e67be	def7445f-91d4-4805-bfe7-50f6314ab0fd	11800.00	0.00	11800.00	UNPAID	2026-08-09	\N	\N	2026-08-09 06:01:11.269	2026-08-09 06:01:11.294	t	10000.00	18.00	1800.00	900.00	900.00	0.00
52bc7ec6-86a8-4631-93fb-3b053f32d5b5	d563fb11-8e19-4079-a843-4d579ba681ee	INV-000003	de6c32ea-506a-4185-a152-4d2e7ded6f61	1c8d9ded-b57a-410c-9586-27799c17a308	1000.00	0.00	1000.00	UNPAID	2026-08-09	\N	\N	2026-08-09 06:01:11.458	2026-08-09 06:01:11.458	f	1000.00	0.00	0.00	0.00	0.00	0.00
f23ec0ac-0c05-462c-b110-229e295db22f	4613e40d-bba4-424a-970e-ffc7836a19e2	P3A-000001	f87d2540-dbc3-43b2-b964-72fef6fd2c2f	fdc73b9b-b552-41bb-81cc-9f39cf4a8de6	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:47:59.059	2026-08-09 08:47:59.059	f	1250.00	0.00	0.00	0.00	0.00	0.00
aaa9f699-53f3-4913-8d4d-cf16b7ec7c14	4613e40d-bba4-424a-970e-ffc7836a19e2	P3A-000002	2a2aaf0a-4340-4b6b-9c57-4fb57f943b97	fdc73b9b-b552-41bb-81cc-9f39cf4a8de6	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:47:59.163	2026-08-09 08:47:59.163	f	2400.00	0.00	0.00	0.00	0.00	0.00
c83b40c9-5c2a-4f93-acf3-0f512e2b82fb	4613e40d-bba4-424a-970e-ffc7836a19e2	P3A-000003	3f1b22d5-d787-43ef-86d6-96b54e8957af	fdc73b9b-b552-41bb-81cc-9f39cf4a8de6	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:47:59.257	2026-08-09 08:47:59.257	f	2500.00	0.00	0.00	0.00	0.00	0.00
1d07cfb9-b0de-481c-84f2-3b1853faa5f1	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	P3A-000002	b3b48f13-43c0-4c04-ab1f-f0275909481c	cc80f7ff-acd4-4f2e-be1b-fc04c9c92b6b	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 06:01:25.563	2026-08-09 06:01:25.563	f	2400.00	0.00	0.00	0.00	0.00	0.00
93f44c54-944a-4238-b05c-bd290d9a024b	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	P3A-000001	1aca63a7-1b55-43f6-a212-067b4a8d998f	adbc29b9-d832-489a-ac6b-9fe8b37ee047	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:10:27.924	2026-08-09 09:10:27.924	f	1250.00	0.00	0.00	0.00	0.00	0.00
96a0c6a4-ddc3-4e0b-8241-5d377e5076a8	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	P3A-000002	09e674a1-3b3c-4b77-b2ea-9a20be04a7d4	adbc29b9-d832-489a-ac6b-9fe8b37ee047	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:10:28.045	2026-08-09 09:10:28.045	f	2400.00	0.00	0.00	0.00	0.00	0.00
865ff569-76dd-4d2f-b4b2-822277170c5f	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	P3A-000003	83ab09e2-4e35-4c61-ab59-4996abccf515	adbc29b9-d832-489a-ac6b-9fe8b37ee047	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:10:28.146	2026-08-09 09:10:28.146	f	2500.00	0.00	0.00	0.00	0.00	0.00
12788c22-bc89-4e13-8240-b2ef8715c8f3	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	P3A-000003	f342d045-8f17-42f6-987b-9ffd307b9dc6	cc80f7ff-acd4-4f2e-be1b-fc04c9c92b6b	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 06:01:25.655	2026-08-09 06:01:25.655	f	2500.00	0.00	0.00	0.00	0.00	0.00
b448ee74-3b54-434c-bbbc-ad1ef2ea0127	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	P3A-000001	f3694c61-ded1-4396-a40c-d3ab227dcc87	cc80f7ff-acd4-4f2e-be1b-fc04c9c92b6b	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 06:01:25.456	2026-08-09 06:01:25.456	f	1250.00	0.00	0.00	0.00	0.00	0.00
e38febf7-2463-4b44-8643-465026bc6bec	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	P3A-000001	8097a678-4eaf-4e98-a5dc-43512752e0d4	3adc64f9-1328-4b58-a1d6-218054706405	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:53:41.871	2026-08-09 08:53:41.871	f	1250.00	0.00	0.00	0.00	0.00	0.00
afc2b322-bf95-4c9d-82c7-d474f49a3d64	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	P3A-000002	53afb2d2-30ce-4277-ad17-2eaae6c8661b	3adc64f9-1328-4b58-a1d6-218054706405	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:53:41.984	2026-08-09 08:53:41.984	f	2400.00	0.00	0.00	0.00	0.00	0.00
82abecb2-f5c6-410e-95c9-2a4f43867bb5	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	P3A-000003	ca2fa862-a997-4ca5-91a2-2fcb1eb1d6b7	3adc64f9-1328-4b58-a1d6-218054706405	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 08:53:42.073	2026-08-09 08:53:42.073	f	2500.00	0.00	0.00	0.00	0.00	0.00
d6035bad-87fd-4c80-aa92-751f4caa5de3	b3bd9148-5bcf-46c7-aae9-d07d688834ca	P3A-000001	a210207d-d1e0-49a5-82d1-6b3a2cc7dc15	b4c95be1-9ae6-4f25-854a-a999e6cd0cb9	1250.00	0.00	1250.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:03:26.244	2026-08-09 09:03:26.244	f	1250.00	0.00	0.00	0.00	0.00	0.00
12c41429-6e56-4ccd-8a2e-12eaaf6fd71f	b3bd9148-5bcf-46c7-aae9-d07d688834ca	P3A-000002	fba0e72f-d1d1-4938-8ca0-bb2603ea8434	b4c95be1-9ae6-4f25-854a-a999e6cd0cb9	2400.00	0.00	2400.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:03:26.344	2026-08-09 09:03:26.344	f	2400.00	0.00	0.00	0.00	0.00	0.00
0934a14c-544d-4ef8-9111-7b92c6cad45b	b3bd9148-5bcf-46c7-aae9-d07d688834ca	P3A-000003	f64b1aa0-d902-4ca7-acc8-29674de02fa6	b4c95be1-9ae6-4f25-854a-a999e6cd0cb9	2500.00	0.00	2500.00	UNPAID	2026-08-09	\N	\N	2026-08-09 09:03:26.412	2026-08-09 09:03:26.412	f	2500.00	0.00	0.00	0.00	0.00	0.00
\.


--
-- Data for Name: job_fuel_entries; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.job_fuel_entries (id, company_id, job_id, machine_id, litres, cost, recorded_by, recorded_at) FROM stdin;
44608e9e-8329-4ef0-ba76-a08ce793561f	3b4fa961-b987-4207-bade-425969e8e1a5	6c98b642-52ac-44c3-9f62-3cded5794033	47b77082-85f7-4076-a807-e46743b14d1a	15.00	\N	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.98
10f49b19-21c7-4e2d-875c-8fbad930685a	023866d9-236a-41cc-a36f-b9e516720f54	91749a2f-6538-4080-8189-32464dd2b235	dfabea01-ad4b-48f9-8916-f19cbd6c5176	15.00	\N	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:43.32
733b0c72-7c04-46a0-9c40-fd34e73fc261	024b72fd-44b2-4f38-96c1-78b156fa58c2	a2778da0-0a83-47eb-84b5-6ff4581c52bf	b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	15.00	\N	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.824
f32531e7-4d19-4884-98a2-5f336812d9ec	f33c8ba7-f382-4217-90cf-d9d133632537	a7e75fb2-948f-4e44-918b-349684ea169f	4d3bd6ff-d190-40c2-a439-0173ba1db673	15.00	\N	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:52.146
d054b64c-0505-40dc-96c5-1380da192461	c329669f-35fe-4787-84c9-902251b14695	03701452-2909-4590-ab1f-0796c1b8098c	b28aa61a-9544-4f6d-b733-7bd450ab0e53	15.00	\N	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.331
fcbf3756-9531-4328-8a3b-19ff91717d2e	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	8015822f-8a9f-4c10-b540-062eb0bd4fb1	7cffb5ba-c738-4d32-8afc-dde5c24eac52	15.00	\N	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.615
7d735a4c-a246-42a7-bc1c-a1fc5b303444	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	133384a6-6025-4f6c-bc0a-0f6a5fe8c17c	b4634256-8789-4db0-88c3-0042c94986f7	15.00	\N	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.242
428553b8-ee65-4ac8-825a-f639fda668bf	3968e65b-4204-432c-ad93-26a831a79d3e	08463cb9-9842-4a38-ae16-0cd55cc6d219	a9754ce6-cf7e-4f94-bfde-c900853d603a	15.00	\N	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.663
d546b8a2-4531-4b29-a424-e38b24bd573c	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	40155f01-7415-455a-a259-587e2af7719f	e3cd9c96-272a-4b49-80cc-878dd0d59317	15.00	\N	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.401
5c47eec4-ecf3-4cbf-8fc8-840fb8ec90b8	ecbba26c-b8ee-4455-a09e-86fab13778df	7e5753d5-4ad9-4a9e-a58c-09110bf842e7	b61808f9-6b2e-4f80-8dd3-11909e2c884d	15.00	\N	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.331
99e85054-9cf1-4717-bc04-a480f7789268	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	cad31c2d-9e5b-4114-aef4-c188488db565	142de1ae-b2d7-4726-a644-5f49d04e69c4	15.00	\N	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.669
045424d2-db5c-416a-b936-58e46b62d818	c331e53c-fe17-49c2-97f1-9466a87bbe42	19ce7b52-7a46-4648-b54b-b5cc5d38d869	e4e64b4d-83e1-4fb6-af76-9476923ecc15	15.00	1350.00	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.912
cd891561-4883-40ec-92b3-ddb28231249d	c331e53c-fe17-49c2-97f1-9466a87bbe42	02c0c5e5-d727-490c-be21-2b4789c3d657	e4e64b4d-83e1-4fb6-af76-9476923ecc15	20.00	1800.00	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:25.098
dd5cc2cf-581a-4b55-82e9-e92482bf7828	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	6cf3e74e-a4f9-4133-9411-48efdded6714	fc9d0cf9-747b-4b68-87fc-8e2fc4972645	15.00	\N	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.66
693ba3e6-4a4a-4bde-b879-5aa8f68d5f80	7a92e240-df0b-4c44-8bba-bd7574ae788b	904de97f-7816-4197-822d-7302e3311687	244e2f3a-d41d-476b-97be-5f507048c9c3	15.00	1425.00	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09 06:00:45.293
7e053530-3d7b-4d5d-9789-746a6b05c119	8951aa6b-476b-46b7-b12b-de1998c8bbf7	883d6917-5c55-4a6a-8680-68257798433f	c5cb5d71-cb32-42b5-a2ac-c48b8c845f7e	15.00	1425.00	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.666
e1ac5cc5-fa86-4450-b3dd-af0a844d1267	8951aa6b-476b-46b7-b12b-de1998c8bbf7	bf6060c6-6f66-465c-b5ab-99bae7e3af69	c5cb5d71-cb32-42b5-a2ac-c48b8c845f7e	30.00	2850.00	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.888
03d63afa-e139-4b26-bfcb-e0142a18169b	d563fb11-8e19-4079-a843-4d579ba681ee	2bab8f27-d2da-4e5b-b5f9-a427b1e564ec	ece6db08-b21e-4738-bc77-9800dd0c5c5d	15.00	1425.00	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:10.945
66f4f6e1-92e5-41e2-959a-de7ab9333531	d563fb11-8e19-4079-a843-4d579ba681ee	e1c4e55b-06e9-4337-a19c-846d983dbd21	ece6db08-b21e-4738-bc77-9800dd0c5c5d	30.00	2850.00	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.184
d65ee7ae-d97b-4fd1-b3b9-948db6c7b11f	d563fb11-8e19-4079-a843-4d579ba681ee	da31e76d-541c-4b22-9e73-6adfc05cd222	ece6db08-b21e-4738-bc77-9800dd0c5c5d	10.00	\N	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.383
b8fb50b0-8ea9-4215-8e6d-a8e52d97e083	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	3edb7f11-ae39-4995-8466-d9579fd7e4ac	27540f0a-20ac-4e1b-bd37-c1583db03028	15.00	\N	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.546
9627f77a-b654-4431-920c-27b81bb546c0	6571c3c9-9c94-4b02-ac20-829a9af731b6	70927cc8-ddfa-43ef-a984-ae9976596a52	438e3ded-9440-4f7d-b87e-e5c7ce0b939a	15.00	\N	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.833
a2a3d1c2-2116-4170-a919-448699c60646	4613e40d-bba4-424a-970e-ffc7836a19e2	1a3827d4-3216-4afc-9559-694ffad2a6ba	5765c74a-7d2f-4443-8abe-2487b4bd6b56	15.00	\N	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:59.154
a4f2bacc-c660-4002-86b9-d3bb3a73b9f7	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	782df47c-5c80-4c4e-a272-4ce3603b7f9a	c790842b-760d-4cad-b053-8cc6091bb4e9	15.00	\N	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.976
c5d71903-6ff9-427c-9ca0-7df5f63b6521	b3bd9148-5bcf-46c7-aae9-d07d688834ca	a35cf4a7-28b1-4d25-a4c3-c7adbbb8f63e	f5024078-737d-4a6e-90e7-2b28964d9722	15.00	\N	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.336
aa000b43-4128-4d30-bb27-c237b0889df7	0757faaa-e55d-4863-9e88-c738651afa4c	7e3033ad-de05-4e0b-a914-bbe9acdaab1e	65aa4462-0a46-4bc5-aa07-bf538b853620	15.00	\N	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.351
fc0eac53-91a5-44f0-a577-972252dce092	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	5fb8bdec-e8fb-4d4f-b17b-daa3312976f6	ad9d7815-3d41-44cc-847f-3b2a7628b50b	15.00	\N	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:28.034
\.


--
-- Data for Name: job_photos; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.job_photos (id, company_id, job_id, file_url, caption, uploaded_by, created_at) FROM stdin;
ab75d175-b9ef-48a1-af9e-3884be25d3a2	c331e53c-fe17-49c2-97f1-9466a87bbe42	75e3eb25-317d-47e3-9d4c-e90c6b3a8224	https://example.com/completion-photo.jpg	Field finished	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.694
235699e4-494a-429c-aa9a-0fa9a9a15459	c331e53c-fe17-49c2-97f1-9466a87bbe42	02c0c5e5-d727-490c-be21-2b4789c3d657	https://example.com/field.jpg	Photo only	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:25.06
830fa969-d6f3-4676-a31b-344f80022387	7a92e240-df0b-4c44-8bba-bd7574ae788b	904de97f-7816-4197-822d-7302e3311687	https://shabooagri.s3.amazonaws.com/jobs/photo1.jpg	Completed field plowing photo	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09 06:00:45.312
33a525a9-9791-4f18-9a5e-afc8edd706ce	8951aa6b-476b-46b7-b12b-de1998c8bbf7	883d6917-5c55-4a6a-8680-68257798433f	https://shabooagri.s3.amazonaws.com/jobs/photo1.jpg	Completed field plowing photo	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.686
2456479b-c36f-4941-b39e-0dac9b9169f8	8951aa6b-476b-46b7-b12b-de1998c8bbf7	bf6060c6-6f66-465c-b5ab-99bae7e3af69	https://shabooagri.s3.amazonaws.com/jobs/photo2.jpg	Commercial harvesting photo	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.911
3c5a99ab-a587-4062-b711-21c1c16bf736	d563fb11-8e19-4079-a843-4d579ba681ee	2bab8f27-d2da-4e5b-b5f9-a427b1e564ec	https://shabooagri.s3.amazonaws.com/jobs/photo1.jpg	Completed field plowing photo	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:10.959
11096606-4404-4ddf-80e9-78539e7981da	d563fb11-8e19-4079-a843-4d579ba681ee	e1c4e55b-06e9-4337-a19c-846d983dbd21	https://shabooagri.s3.amazonaws.com/jobs/photo2.jpg	Commercial harvesting photo	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.21
4bbcff85-019b-4330-b61b-1c1249fb76d7	d563fb11-8e19-4079-a843-4d579ba681ee	da31e76d-541c-4b22-9e73-6adfc05cd222	https://shabooagri.s3.amazonaws.com/jobs/photo3.jpg	\N	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.356
\.


--
-- Data for Name: job_status_log; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.job_status_log (id, company_id, job_id, status, changed_by, changed_at, note) FROM stdin;
3fd2aef3-2314-446d-9fd1-8a8db66f9a5b	2fc53fa9-07fd-4172-af37-6a1034df9ecb	45446420-ca36-4ecf-9623-6410f1406684	WORKING	6233fb89-68db-4a83-b72e-7770af3fe2fb	2026-08-08 18:05:31.715	\N
b24655a5-bccd-4e98-b6c6-cb103422bebe	2fc53fa9-07fd-4172-af37-6a1034df9ecb	45446420-ca36-4ecf-9623-6410f1406684	COMPLETED	6233fb89-68db-4a83-b72e-7770af3fe2fb	2026-08-08 18:05:31.736	\N
78924dd6-de30-47b0-b930-dc473677358d	3b4fa961-b987-4207-bade-425969e8e1a5	1efdc8b8-1c87-44fc-b0f2-548072d0913d	WORKING	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.778	\N
ad21657a-edf7-451a-b83a-00e8fafd7b77	3b4fa961-b987-4207-bade-425969e8e1a5	1efdc8b8-1c87-44fc-b0f2-548072d0913d	PAUSED	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.807	Tea break
6bc5b999-e6df-4027-a873-d6e9f31fe9d8	3b4fa961-b987-4207-bade-425969e8e1a5	1efdc8b8-1c87-44fc-b0f2-548072d0913d	WORKING	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.832	Resumed field work
9edff919-b5df-4090-84ec-8d046bc650af	3b4fa961-b987-4207-bade-425969e8e1a5	1efdc8b8-1c87-44fc-b0f2-548072d0913d	COMPLETED	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.884	Field harvesting complete
7500c8cd-c5ee-4cdb-ad77-f6deca50e278	3b4fa961-b987-4207-bade-425969e8e1a5	6c98b642-52ac-44c3-9f62-3cded5794033	COMPLETED	3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	2026-08-08 18:15:15.976	Manual after-work entry
16a1ffca-b72e-43ef-b0ef-59ab52f0a9c7	023866d9-236a-41cc-a36f-b9e516720f54	699c48a4-67a7-4bd6-af78-e6c080e9263d	WORKING	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:43.112	\N
798c4559-ebe0-4dc5-adea-c13608053cf9	023866d9-236a-41cc-a36f-b9e516720f54	699c48a4-67a7-4bd6-af78-e6c080e9263d	PAUSED	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:43.142	Tea break
f1758f6f-564d-4f0a-960b-66c68d386dd0	023866d9-236a-41cc-a36f-b9e516720f54	699c48a4-67a7-4bd6-af78-e6c080e9263d	WORKING	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:43.175	Resumed field work
5c4a36f0-50b9-4765-a4a8-06f4c749a1e9	023866d9-236a-41cc-a36f-b9e516720f54	699c48a4-67a7-4bd6-af78-e6c080e9263d	COMPLETED	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:43.213	Field harvesting complete
2880a2a1-d1ee-45e5-8fb5-943b48314493	023866d9-236a-41cc-a36f-b9e516720f54	91749a2f-6538-4080-8189-32464dd2b235	COMPLETED	eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	2026-08-08 18:15:43.317	Manual after-work entry
5cbd8dab-cc0a-44f6-94c3-7ff452803d59	024b72fd-44b2-4f38-96c1-78b156fa58c2	552b1a99-ff9f-4255-9ef6-3fa40e467d9d	WORKING	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.633	\N
41a127c8-bd8a-4106-832e-00bcc297fa81	024b72fd-44b2-4f38-96c1-78b156fa58c2	552b1a99-ff9f-4255-9ef6-3fa40e467d9d	PAUSED	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.662	Tea break
a67a7ab8-b641-4eaa-8e58-ee2078978b19	024b72fd-44b2-4f38-96c1-78b156fa58c2	552b1a99-ff9f-4255-9ef6-3fa40e467d9d	WORKING	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.691	Resumed field work
755e0d5a-b4f3-4791-a98e-de3e80b5381b	024b72fd-44b2-4f38-96c1-78b156fa58c2	552b1a99-ff9f-4255-9ef6-3fa40e467d9d	COMPLETED	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.732	Field harvesting complete
53d4dc4b-2912-464a-b264-77634c5abee0	024b72fd-44b2-4f38-96c1-78b156fa58c2	a2778da0-0a83-47eb-84b5-6ff4581c52bf	COMPLETED	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.819	Manual after-work entry
379b7e1d-1c1f-4489-80f2-7ecb03b1b393	024b72fd-44b2-4f38-96c1-78b156fa58c2	0a54edf6-ce22-4423-9eb5-cb6bc1186b1f	COMPLETED	0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	2026-08-08 18:22:33.887	Manual after-work entry
2b5afdc0-3c43-4fe8-a291-380196c0d5c1	f33c8ba7-f382-4217-90cf-d9d133632537	d4c70ef0-79c0-4c3e-b191-190cb608c3ff	WORKING	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:51.949	\N
1bded464-8394-46d6-9217-46bfe9e34dbd	f33c8ba7-f382-4217-90cf-d9d133632537	d4c70ef0-79c0-4c3e-b191-190cb608c3ff	PAUSED	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:51.978	Tea break
8a72f710-1953-4093-b1f0-9d8c488dc319	f33c8ba7-f382-4217-90cf-d9d133632537	d4c70ef0-79c0-4c3e-b191-190cb608c3ff	WORKING	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:51.999	Resumed field work
a78be617-31e6-47b6-a0f6-e8a7c6ab1aa4	f33c8ba7-f382-4217-90cf-d9d133632537	d4c70ef0-79c0-4c3e-b191-190cb608c3ff	COMPLETED	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:52.046	Field harvesting complete
10bf3e40-bff5-4f6d-ad5e-f3cd895960a9	f33c8ba7-f382-4217-90cf-d9d133632537	a7e75fb2-948f-4e44-918b-349684ea169f	COMPLETED	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:52.14	Manual after-work entry
e44817dc-1099-4ed8-a267-9e602e794c36	f33c8ba7-f382-4217-90cf-d9d133632537	b659e1f2-4a6e-411c-889e-7834a063ee72	COMPLETED	7d49f586-0061-459d-a0e0-aeffe249a367	2026-08-08 18:23:52.222	Manual after-work entry
90ba0edc-e877-42a4-82e7-ca4d8bf555bd	c329669f-35fe-4787-84c9-902251b14695	92f7feaf-6004-44d8-9f61-d15dd584fe78	WORKING	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.146	\N
10d7c766-b627-4d07-9eaa-4b121fb0b9ce	c329669f-35fe-4787-84c9-902251b14695	92f7feaf-6004-44d8-9f61-d15dd584fe78	PAUSED	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.174	Tea break
570eb49f-b45f-4067-b7c8-75ca874dff91	c329669f-35fe-4787-84c9-902251b14695	92f7feaf-6004-44d8-9f61-d15dd584fe78	WORKING	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.211	Resumed field work
a3dcabc1-50d6-4379-b075-58a561364b3e	c329669f-35fe-4787-84c9-902251b14695	92f7feaf-6004-44d8-9f61-d15dd584fe78	COMPLETED	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.239	Field harvesting complete
c6d08de1-eab8-4dd6-934a-6343b041ca40	c329669f-35fe-4787-84c9-902251b14695	03701452-2909-4590-ab1f-0796c1b8098c	COMPLETED	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.326	Manual after-work entry
846f25a4-b6d3-4544-8e7d-9ea3428d8117	c329669f-35fe-4787-84c9-902251b14695	8516c52b-42d6-458a-be1b-d22637797428	COMPLETED	37b62ee0-d138-444f-bf02-380e575a7610	2026-08-08 18:33:49.397	Manual after-work entry
e317625c-a7e1-4fd9-b1c2-d2ad0d05cfeb	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	945bca08-3884-4b70-9735-6d52193709c5	WORKING	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.396	\N
29b69edc-4bb2-4a9d-8e67-8ae1828b147c	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	945bca08-3884-4b70-9735-6d52193709c5	PAUSED	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.428	Tea break
b4e6286c-2676-4a47-aba9-8dc5731a88d0	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	945bca08-3884-4b70-9735-6d52193709c5	WORKING	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.455	Resumed field work
4762c4b2-94c5-4bda-80fa-caa3e1063baf	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	945bca08-3884-4b70-9735-6d52193709c5	COMPLETED	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.502	Field harvesting complete
9b773907-b8c9-4391-b221-53a3202ab734	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	8015822f-8a9f-4c10-b540-062eb0bd4fb1	COMPLETED	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.61	Manual after-work entry
7d96beeb-8c51-4705-95d2-b3a20a9bb12c	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	35b2253a-5c08-4107-855e-0dcd76e2ef6f	COMPLETED	c5ec61b5-7c7c-4b26-ae96-f992bc632677	2026-08-08 18:48:19.706	Manual after-work entry
ca60e846-84c3-4185-9adf-f84e772cbdd5	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	3abef0df-9d31-4fa4-b851-a95760333ee1	WORKING	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.035	\N
1e5e3e91-7bab-4162-91f9-239960de5299	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	3abef0df-9d31-4fa4-b851-a95760333ee1	PAUSED	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.069	Tea break
816ea258-5553-4753-a113-1542e0839369	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	3abef0df-9d31-4fa4-b851-a95760333ee1	WORKING	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.106	Resumed field work
d7d29984-0497-418b-91e4-a5365bd0c8d8	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	3abef0df-9d31-4fa4-b851-a95760333ee1	COMPLETED	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.142	Field harvesting complete
474f9492-4b97-4ca8-b770-a8962fcb5d4d	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	133384a6-6025-4f6c-bc0a-0f6a5fe8c17c	COMPLETED	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.24	Manual after-work entry
2907c4ad-b2c7-4a27-b03f-d0e4b28e0c8d	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	aac6cd5b-5d09-4d88-b4c7-ed4aebcf4242	COMPLETED	086fa155-7bda-48c6-bbae-a4d6dfe4635b	2026-08-08 19:32:44.302	Manual after-work entry
b9cb4514-a944-4e91-a337-32405f80f626	3968e65b-4204-432c-ad93-26a831a79d3e	72997389-5223-4313-be25-3b1d7cf6d591	WORKING	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.457	\N
265247f1-9d49-40e4-9da4-50a9ef54afd8	3968e65b-4204-432c-ad93-26a831a79d3e	72997389-5223-4313-be25-3b1d7cf6d591	PAUSED	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.487	Tea break
2f1cca12-a485-4fc2-bef8-b28ace270695	3968e65b-4204-432c-ad93-26a831a79d3e	72997389-5223-4313-be25-3b1d7cf6d591	WORKING	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.515	Resumed field work
d0118455-ed48-4034-81cb-ffb533f9e29b	3968e65b-4204-432c-ad93-26a831a79d3e	72997389-5223-4313-be25-3b1d7cf6d591	COMPLETED	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.577	Field harvesting complete
0def75da-31b5-43be-a670-99afa12969b3	3968e65b-4204-432c-ad93-26a831a79d3e	08463cb9-9842-4a38-ae16-0cd55cc6d219	COMPLETED	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.659	Manual after-work entry
5cc70991-04d8-455a-91bc-6320ee77e997	3968e65b-4204-432c-ad93-26a831a79d3e	fb4d7a34-21e7-43ab-9b77-367612853d22	COMPLETED	5cc119e3-567f-49f8-b986-13b82bc3f960	2026-08-08 19:38:59.755	Manual after-work entry
af510f32-c6cc-441d-8d40-65a480f5e5c6	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	9584a767-e5f4-4080-a054-d6cea18c08ef	WORKING	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.207	\N
08b938aa-4b69-4b9d-94d3-082cc2175e80	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	9584a767-e5f4-4080-a054-d6cea18c08ef	PAUSED	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.229	Tea break
40112c5e-38c5-497a-a6ae-0c909c141d55	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	9584a767-e5f4-4080-a054-d6cea18c08ef	WORKING	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.256	Resumed field work
e5acd690-3d64-4613-b10f-c1ac55d64c44	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	9584a767-e5f4-4080-a054-d6cea18c08ef	COMPLETED	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.301	Field harvesting complete
ab380445-8a92-437a-988a-134c924c0257	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	40155f01-7415-455a-a259-587e2af7719f	COMPLETED	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.397	Manual after-work entry
e183a93f-4d2a-4491-b348-e2072e835a09	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	ef66d8c4-f9e7-4e3c-8255-0714e0ff7000	COMPLETED	c2b27c01-e11a-45a5-be98-78d4d91a03d5	2026-08-08 19:41:58.478	Manual after-work entry
bb6d7a79-7456-4dba-8289-9b833f091879	ecbba26c-b8ee-4455-a09e-86fab13778df	ef957aa2-2cd7-4201-a363-fc93c810ddb8	WORKING	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.193	\N
fac849cc-b9ff-4d06-a2da-2136318c5287	ecbba26c-b8ee-4455-a09e-86fab13778df	ef957aa2-2cd7-4201-a363-fc93c810ddb8	PAUSED	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.207	Tea break
8c00966f-6b9f-452e-891d-213ab5a35735	ecbba26c-b8ee-4455-a09e-86fab13778df	ef957aa2-2cd7-4201-a363-fc93c810ddb8	WORKING	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.233	Resumed field work
a056becc-7ced-445e-925c-6e1c6fa5737d	ecbba26c-b8ee-4455-a09e-86fab13778df	ef957aa2-2cd7-4201-a363-fc93c810ddb8	COMPLETED	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.268	Field harvesting complete
31465636-05f3-413b-b723-e03c15b91321	ecbba26c-b8ee-4455-a09e-86fab13778df	7e5753d5-4ad9-4a9e-a58c-09110bf842e7	COMPLETED	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.328	Manual after-work entry
93508dc8-97de-4bd8-a1d0-df221b43bcda	ecbba26c-b8ee-4455-a09e-86fab13778df	ddf8c6ff-0fd5-495e-b32e-9470368ecd86	COMPLETED	ef9723a8-a307-4ce6-a6f3-4db7d49bd774	2026-08-08 20:04:26.379	Manual after-work entry
5449efb8-cf37-4105-af45-465e2b0bf964	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	fd20d55f-8eb0-4810-a4e8-f5ed654cb4be	WORKING	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.541	\N
a9ef2c77-76fc-46b8-adfd-0ac6a0ee25fd	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	fd20d55f-8eb0-4810-a4e8-f5ed654cb4be	PAUSED	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.557	Tea break
3063bc16-0628-4eb1-b543-81ccd816aa9c	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	fd20d55f-8eb0-4810-a4e8-f5ed654cb4be	WORKING	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.573	Resumed field work
63908cba-a64d-4601-80e4-76b99440dac2	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	fd20d55f-8eb0-4810-a4e8-f5ed654cb4be	COMPLETED	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.593	Field harvesting complete
b7c9e7c8-a574-4095-881d-7eabe602ddf5	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	cad31c2d-9e5b-4114-aef4-c188488db565	COMPLETED	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.665	Manual after-work entry
4ef70de7-4825-432a-8a6e-0daeb13b07dd	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	61d207ed-79a0-4ee5-b3b8-deec5c1098e3	COMPLETED	22b76af9-0d7b-4d4e-828c-7cbd84dc9599	2026-08-08 20:53:03.733	Manual after-work entry
d3af5e27-8581-424a-bdbd-61d7f16edad3	40511429-f937-4f0f-8a0a-6869154b7144	ae3d947a-8e17-4307-b3b3-8dcb96980e64	WORKING	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:37.498	\N
d9f97b75-2932-4f87-ba42-cf347bb89016	40511429-f937-4f0f-8a0a-6869154b7144	ae3d947a-8e17-4307-b3b3-8dcb96980e64	COMPLETED	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:37.54	\N
63fef9b3-f193-4312-aafc-37f3d25ea7d1	40511429-f937-4f0f-8a0a-6869154b7144	4f08bb34-813a-4994-9702-6e10b4b6436f	WORKING	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:37.757	\N
687faef6-5b8f-451a-9012-1efdd7a873df	40511429-f937-4f0f-8a0a-6869154b7144	4f08bb34-813a-4994-9702-6e10b4b6436f	COMPLETED	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:37.783	\N
6db2e404-1ee9-4cb3-9001-03b1f0e62f74	40511429-f937-4f0f-8a0a-6869154b7144	30e89658-7dee-48ad-9293-a5d98b48ff2e	WORKING	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:48.275	\N
690eb9b2-055e-4ba0-a79a-c888a01105bc	40511429-f937-4f0f-8a0a-6869154b7144	30e89658-7dee-48ad-9293-a5d98b48ff2e	COMPLETED	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:48.321	\N
64e81c7b-17c3-45bb-a0cd-ed11578f654e	40511429-f937-4f0f-8a0a-6869154b7144	56218010-0bd8-4411-987c-738624a2c52a	WORKING	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:48.521	\N
092cd8f1-75b7-4dd0-b521-955c30a1ea8c	40511429-f937-4f0f-8a0a-6869154b7144	56218010-0bd8-4411-987c-738624a2c52a	COMPLETED	35b8db9a-eb66-4510-a522-3b1404c795ae	2026-08-09 05:24:48.545	\N
525fc111-3068-4930-96e0-7b7eb1d3a4ae	c331e53c-fe17-49c2-97f1-9466a87bbe42	3942b3dc-2477-49cd-996d-85cf0816d10b	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:15.512	\N
ffb54aa3-bb99-49ed-8bf8-020e5e18320d	c331e53c-fe17-49c2-97f1-9466a87bbe42	78a3042e-f6e5-42a9-849c-295ac0a9241c	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:15.609	\N
ce154a74-6893-471f-bd1d-3c214e1e70ab	c331e53c-fe17-49c2-97f1-9466a87bbe42	3b0986c3-db33-4406-b614-d1a99e743446	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:34.521	\N
658d4f32-aad7-4bd8-b84e-31fe59228dd0	c331e53c-fe17-49c2-97f1-9466a87bbe42	fcac71f1-c948-41ea-b454-d4c0593d1ff5	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:34.625	\N
76be534c-7f99-4e7c-8f8b-efa06f222a55	c331e53c-fe17-49c2-97f1-9466a87bbe42	f481c3e2-cbdf-48df-9f6e-20c76a4e4c9c	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:46.843	\N
80ace93a-46b1-49a5-baa1-718358a7b159	c331e53c-fe17-49c2-97f1-9466a87bbe42	6d78c450-19ee-403f-b85c-f6cac26273d8	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:46.966	\N
00cbaf1e-ad8c-4ff9-ac29-017ae796bfc0	c331e53c-fe17-49c2-97f1-9466a87bbe42	24029fc6-ff83-42a2-a8bd-8ff3cab4e21a	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:40:53.361	\N
0f009cbe-7a72-4d0c-9030-a6c6140671a7	c331e53c-fe17-49c2-97f1-9466a87bbe42	1bd680bd-7b58-4c9f-898c-159b8efd0de9	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:01.293	\N
b5a13964-25c1-4d40-9af5-84b1a3828772	c331e53c-fe17-49c2-97f1-9466a87bbe42	ba0297ad-ff88-4194-9c92-0fbad95b8203	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:15.531	\N
ca00dc7e-c2d0-4fff-b61c-f484a2a37578	c331e53c-fe17-49c2-97f1-9466a87bbe42	c8d0dd8d-9e0c-4d17-9990-5fa7d5902d39	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.52	\N
9dfc9543-7fbd-4406-a31f-8479729870e7	c331e53c-fe17-49c2-97f1-9466a87bbe42	75e3eb25-317d-47e3-9d4c-e90c6b3a8224	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.745	\N
9b4d6ddc-90e9-4870-905a-c74356c622cc	c331e53c-fe17-49c2-97f1-9466a87bbe42	e404553f-5d32-4c78-8795-ad9a570bd381	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.831	\N
1d0eacb6-c736-4988-bd41-b208c1e066d7	c331e53c-fe17-49c2-97f1-9466a87bbe42	19ce7b52-7a46-4648-b54b-b5cc5d38d869	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:24.975	\N
e24b9083-5b79-419a-a50c-6b3f7bc3ab64	c331e53c-fe17-49c2-97f1-9466a87bbe42	02c0c5e5-d727-490c-be21-2b4789c3d657	COMPLETED	553a8bfb-583e-488a-9b21-0abf99c52f51	2026-08-09 05:41:25.155	\N
41e630ad-d8e4-484e-a33e-64629323ee39	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	34552d70-2767-4e9c-ad24-efde49304ecc	WORKING	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.433	\N
1089e6b7-5a97-484f-a045-20001b4b140d	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	34552d70-2767-4e9c-ad24-efde49304ecc	PAUSED	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.457	Tea break
52a88b86-1d96-40a7-b625-8ab0a642d1a8	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	34552d70-2767-4e9c-ad24-efde49304ecc	WORKING	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.486	Resumed field work
a1422eed-dd60-40da-92c0-85bf119d5624	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	34552d70-2767-4e9c-ad24-efde49304ecc	COMPLETED	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.538	Field harvesting complete
9361d6df-ab40-4a51-a79f-f0e41e5f0b28	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	6cf3e74e-a4f9-4133-9411-48efdded6714	COMPLETED	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.656	Manual after-work entry
dda3aff7-7636-4a29-8e4e-566abbdb9384	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	cab08798-aeb3-422a-a767-d3ce314c195e	COMPLETED	b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	2026-08-09 05:57:15.794	Manual after-work entry
5394d459-98a1-4287-b586-2825ce94305b	7a92e240-df0b-4c44-8bba-bd7574ae788b	904de97f-7816-4197-822d-7302e3311687	WORKING	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09 06:00:45.233	\N
3914cf45-a54f-4b36-983e-78d75ff05396	7a92e240-df0b-4c44-8bba-bd7574ae788b	904de97f-7816-4197-822d-7302e3311687	PAUSED	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09 06:00:45.256	Tea break
ffbca9cf-3c7c-4d80-bfcd-cad8e9212f66	7a92e240-df0b-4c44-8bba-bd7574ae788b	904de97f-7816-4197-822d-7302e3311687	WORKING	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09 06:00:45.283	Resumed plowing
fb216d3f-7335-41cf-a675-56199678326e	7a92e240-df0b-4c44-8bba-bd7574ae788b	904de97f-7816-4197-822d-7302e3311687	COMPLETED	1f0db783-3016-444b-ad21-3d8834cadb60	2026-08-09 06:00:45.354	Plowing completed successfully
0f62d4ba-1351-49fd-87b9-8fc74ca88ba5	8951aa6b-476b-46b7-b12b-de1998c8bbf7	883d6917-5c55-4a6a-8680-68257798433f	WORKING	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.625	\N
83246963-ea27-446c-a128-6e3ac98b2fa4	8951aa6b-476b-46b7-b12b-de1998c8bbf7	883d6917-5c55-4a6a-8680-68257798433f	PAUSED	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.642	Tea break
ca88cc97-d58e-44b0-9cf9-c331b581bbd2	8951aa6b-476b-46b7-b12b-de1998c8bbf7	883d6917-5c55-4a6a-8680-68257798433f	WORKING	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.66	Resumed plowing
1b398803-71bb-42fb-9834-14af83dfff6a	8951aa6b-476b-46b7-b12b-de1998c8bbf7	883d6917-5c55-4a6a-8680-68257798433f	COMPLETED	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.718	Plowing completed successfully
3ed71db5-1559-43b8-8121-61a3ce98116c	8951aa6b-476b-46b7-b12b-de1998c8bbf7	bf6060c6-6f66-465c-b5ab-99bae7e3af69	WORKING	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.879	\N
ef333995-c6a9-47b5-8edc-efa1ddb864e1	8951aa6b-476b-46b7-b12b-de1998c8bbf7	bf6060c6-6f66-465c-b5ab-99bae7e3af69	COMPLETED	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.955	Commercial work completed
e8218080-72d1-4f3a-8052-dbfb2ba74d25	d563fb11-8e19-4079-a843-4d579ba681ee	2bab8f27-d2da-4e5b-b5f9-a427b1e564ec	WORKING	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:10.901	\N
7e5b52fe-fc4a-4a56-91af-1efa1f4fa42e	d563fb11-8e19-4079-a843-4d579ba681ee	2bab8f27-d2da-4e5b-b5f9-a427b1e564ec	PAUSED	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:10.924	Tea break
9b5ca90e-d558-413d-a8cd-b433c22fdba7	d563fb11-8e19-4079-a843-4d579ba681ee	2bab8f27-d2da-4e5b-b5f9-a427b1e564ec	WORKING	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:10.94	Resumed plowing
2caf1215-9a79-471c-83f9-2bb07661ca21	d563fb11-8e19-4079-a843-4d579ba681ee	2bab8f27-d2da-4e5b-b5f9-a427b1e564ec	COMPLETED	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:10.99	Plowing completed successfully
e59d269c-1856-421e-8565-99049781184f	d563fb11-8e19-4079-a843-4d579ba681ee	e1c4e55b-06e9-4337-a19c-846d983dbd21	WORKING	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.174	\N
e782f618-9463-4152-a1a7-54c3911a2f6f	d563fb11-8e19-4079-a843-4d579ba681ee	e1c4e55b-06e9-4337-a19c-846d983dbd21	COMPLETED	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.262	Commercial work completed
760ef99d-eabf-4538-b410-da5b8652553a	d563fb11-8e19-4079-a843-4d579ba681ee	da31e76d-541c-4b22-9e73-6adfc05cd222	WORKING	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.339	\N
952bb06d-a8ed-45df-abb3-7ece1f120389	d563fb11-8e19-4079-a843-4d579ba681ee	da31e76d-541c-4b22-9e73-6adfc05cd222	COMPLETED	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.447	\N
18b5e810-7248-4545-95cd-860bb6e789fe	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	bb6450c4-1ac9-466e-a2ce-3306c7ff4447	WORKING	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.316	\N
2f5c9cde-02e6-4a10-afa7-cac8be4ce489	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	bb6450c4-1ac9-466e-a2ce-3306c7ff4447	PAUSED	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.356	Tea break
fe73ed94-11dc-46fa-b204-e92fdd431d24	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	bb6450c4-1ac9-466e-a2ce-3306c7ff4447	WORKING	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.391	Resumed field work
edda4c5b-ce58-4143-94b2-c1ddf92de78f	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	bb6450c4-1ac9-466e-a2ce-3306c7ff4447	COMPLETED	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.439	Field harvesting complete
868d97ec-164c-4f26-abe6-109d680a2657	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	3edb7f11-ae39-4995-8466-d9579fd7e4ac	COMPLETED	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.543	Manual after-work entry
2a4429d8-66b4-4640-a21b-587e56415024	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	18292f45-885e-4c13-9d32-9376d81908cd	COMPLETED	c686a3f2-dc1c-4cd1-989e-58625b645450	2026-08-09 06:01:25.642	Manual after-work entry
188bb1f4-2e4f-4b23-9d88-d9cd3c1dcdef	6571c3c9-9c94-4b02-ac20-829a9af731b6	37255ac4-f95f-4e13-a365-da711ff5c3e8	WORKING	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.607	\N
dd8e638b-5256-4ae9-b0a8-d8560ac77ff7	6571c3c9-9c94-4b02-ac20-829a9af731b6	37255ac4-f95f-4e13-a365-da711ff5c3e8	PAUSED	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.633	Tea break
fd82b786-543f-4b25-880c-eb5bf1ee84e6	6571c3c9-9c94-4b02-ac20-829a9af731b6	37255ac4-f95f-4e13-a365-da711ff5c3e8	WORKING	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.657	Resumed field work
ff1e19ef-2c23-415c-8e50-5eae7313a8c8	6571c3c9-9c94-4b02-ac20-829a9af731b6	37255ac4-f95f-4e13-a365-da711ff5c3e8	COMPLETED	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.702	Field harvesting complete
ac9a8f98-0362-46aa-aa9e-f3c41b65e102	6571c3c9-9c94-4b02-ac20-829a9af731b6	70927cc8-ddfa-43ef-a984-ae9976596a52	COMPLETED	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.826	Manual after-work entry
187cd63f-12ad-408f-836d-0a7645ace017	6571c3c9-9c94-4b02-ac20-829a9af731b6	c2f79895-9ae6-472e-b58e-40d432031067	COMPLETED	0a738759-a63b-4f4e-8862-08939dfec98e	2026-08-09 08:45:02.906	Manual after-work entry
48e45044-5eed-4c88-a4ce-42ff4502894d	4613e40d-bba4-424a-970e-ffc7836a19e2	3e8b842b-47c2-4b82-9042-e1c7df579324	WORKING	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:58.936	\N
49e67b0f-187a-46c8-a283-e790dd60cfd7	4613e40d-bba4-424a-970e-ffc7836a19e2	3e8b842b-47c2-4b82-9042-e1c7df579324	PAUSED	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:58.967	Tea break
386a2618-528c-485a-9c74-b318edcb9576	4613e40d-bba4-424a-970e-ffc7836a19e2	3e8b842b-47c2-4b82-9042-e1c7df579324	WORKING	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:58.995	Resumed field work
6339d744-6aee-4de6-b063-6e299fc22e0b	4613e40d-bba4-424a-970e-ffc7836a19e2	3e8b842b-47c2-4b82-9042-e1c7df579324	COMPLETED	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:59.046	Field harvesting complete
f71facef-88ec-4736-9340-b2c6a8b8ea1c	4613e40d-bba4-424a-970e-ffc7836a19e2	1a3827d4-3216-4afc-9559-694ffad2a6ba	COMPLETED	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:59.151	Manual after-work entry
328c5015-6178-4d97-8373-982407f50b97	4613e40d-bba4-424a-970e-ffc7836a19e2	cd72f5d5-4de7-4597-9215-80c3573c154c	COMPLETED	96697222-d7a6-403a-9d25-c9fa4a78dbfe	2026-08-09 08:47:59.243	Manual after-work entry
65a65c8f-7f84-40a0-8cf0-218d10d5d20c	b3bd9148-5bcf-46c7-aae9-d07d688834ca	3a51e139-ccf3-44f4-9323-8fec30334462	WORKING	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.115	\N
ea0fccef-3a19-4392-90f5-9bb3ec6e85ad	b3bd9148-5bcf-46c7-aae9-d07d688834ca	3a51e139-ccf3-44f4-9323-8fec30334462	PAUSED	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.144	Tea break
fc9dd4b3-c92f-48d9-a92a-3ac55f259b3a	b3bd9148-5bcf-46c7-aae9-d07d688834ca	3a51e139-ccf3-44f4-9323-8fec30334462	WORKING	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.171	Resumed field work
f2a7f6c7-d44b-4436-8251-7a99905853c9	b3bd9148-5bcf-46c7-aae9-d07d688834ca	3a51e139-ccf3-44f4-9323-8fec30334462	COMPLETED	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.224	Field harvesting complete
58916cc0-fc42-487f-a8bc-76546f9c4f3a	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	f5487709-febc-46d4-a8f9-bf25da3e9b6d	WORKING	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.757	\N
ce98a80a-f8e5-4155-b116-7e825d4d2846	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	f5487709-febc-46d4-a8f9-bf25da3e9b6d	PAUSED	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.786	Tea break
b78868f9-2bfe-404c-bf97-ef71c55dbffe	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	f5487709-febc-46d4-a8f9-bf25da3e9b6d	WORKING	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.815	Resumed field work
607b6b6a-c32a-43b4-88d7-ab88f8e1ccda	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	f5487709-febc-46d4-a8f9-bf25da3e9b6d	COMPLETED	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.859	Field harvesting complete
6417db1d-7add-433e-a326-15fd0bc68337	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	782df47c-5c80-4c4e-a272-4ce3603b7f9a	COMPLETED	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:41.973	Manual after-work entry
6e5fb7c9-e6f9-4e59-982a-61a06ac0c70b	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	7663ae92-f0db-43df-b459-ec1ef86b6d95	COMPLETED	b1aace75-9cca-4012-815b-e391c66c31c5	2026-08-09 08:53:42.059	Manual after-work entry
23696f14-b39f-4578-9124-d4882b1713d2	b3bd9148-5bcf-46c7-aae9-d07d688834ca	a35cf4a7-28b1-4d25-a4c3-c7adbbb8f63e	COMPLETED	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.334	Manual after-work entry
833d8f88-0e66-470f-80b9-e805e03ad470	b3bd9148-5bcf-46c7-aae9-d07d688834ca	0c0a43fa-13fd-4206-9f9d-8f8bc1772fd8	COMPLETED	d52da64f-dddb-44ab-95b1-daa8f46cacdb	2026-08-09 09:03:26.403	Manual after-work entry
f76a075a-4d63-49ac-a5da-83dc5169d38b	0757faaa-e55d-4863-9e88-c738651afa4c	56a48c3c-afdb-4e99-96c9-515240967c56	WORKING	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.122	\N
6243e6c3-2e8c-4fbb-a282-cec55821965f	0757faaa-e55d-4863-9e88-c738651afa4c	56a48c3c-afdb-4e99-96c9-515240967c56	PAUSED	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.148	Tea break
afa11a81-29b6-4316-8c96-53dd70d3a381	0757faaa-e55d-4863-9e88-c738651afa4c	56a48c3c-afdb-4e99-96c9-515240967c56	WORKING	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.192	Resumed field work
36eea689-bd72-4845-8ba4-761706c7002b	0757faaa-e55d-4863-9e88-c738651afa4c	56a48c3c-afdb-4e99-96c9-515240967c56	COMPLETED	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.242	Field harvesting complete
f088269c-aaa5-46fa-837c-7efe150cedc7	0757faaa-e55d-4863-9e88-c738651afa4c	7e3033ad-de05-4e0b-a914-bbe9acdaab1e	COMPLETED	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.348	Manual after-work entry
5108b7bc-bd8e-4dc6-b0b5-27610f6d6c68	0757faaa-e55d-4863-9e88-c738651afa4c	58eee8f5-1ac6-4904-b6d9-aed7e3a59dea	COMPLETED	96b57699-b7b4-41a7-ac6d-9dd94a946280	2026-08-09 09:06:26.418	Manual after-work entry
f88bb9d5-136b-42a8-8eee-a10d9a50477a	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	b8f74b9c-c5d9-4d72-948e-6f892a3e5d9c	WORKING	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:27.787	\N
806ac096-954b-40dc-a5fd-85a1589dfe09	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	b8f74b9c-c5d9-4d72-948e-6f892a3e5d9c	PAUSED	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:27.81	Tea break
bb766678-c536-40d7-980b-a850f436a0dd	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	b8f74b9c-c5d9-4d72-948e-6f892a3e5d9c	WORKING	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:27.842	Resumed field work
59a72d4a-3ae5-4ac1-8c64-5de0b75542ad	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	b8f74b9c-c5d9-4d72-948e-6f892a3e5d9c	COMPLETED	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:27.907	Field harvesting complete
0763763f-fff9-4d08-84f9-9bcbeb85d59a	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	5fb8bdec-e8fb-4d4f-b17b-daa3312976f6	COMPLETED	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:28.028	Manual after-work entry
2f80c8de-c02d-44a2-80a1-5e96fe395749	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	a0161f32-7b9a-45b2-a0dc-54d57c085ce8	COMPLETED	5fe2b5b8-d137-490e-920b-e323a6aa8f5e	2026-08-09 09:10:28.135	Manual after-work entry
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.jobs (id, company_id, booking_id, machine_id, driver_id, status, start_time, end_time, total_paused_duration_sec, actual_hours, completed_acres, fuel_used_litres, notes, created_at, updated_at, execution_mode) FROM stdin;
6c98b642-52ac-44c3-9f62-3cded5794033	3b4fa961-b987-4207-bade-425969e8e1a5	fd6afc36-10b6-4b6e-a9f4-7407301f046b	47b77082-85f7-4076-a807-e46743b14d1a	ac32e94c-6afb-4ef4-ae91-0973fea37c05	COMPLETED	2026-08-08 13:15:15.752	2026-08-08 17:15:15.752	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 18:15:15.964	2026-08-08 18:15:15.964	MANUAL
552b1a99-ff9f-4255-9ef6-3fa40e467d9d	024b72fd-44b2-4f38-96c1-78b156fa58c2	00f1cddc-14d8-4db0-a01d-f65478d0a43a	b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	d411498c-9edc-42c2-99b8-c994d4bca031	COMPLETED	2026-08-08 15:22:33.592	2026-08-08 18:22:33.592	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 18:22:33.566	2026-08-08 18:22:33.708	LIVE
a2778da0-0a83-47eb-84b5-6ff4581c52bf	024b72fd-44b2-4f38-96c1-78b156fa58c2	e25e74f0-3354-4150-b33a-0d6462b76df8	b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	05970484-ef07-48f0-af0e-697d36491891	COMPLETED	2026-08-08 13:22:33.592	2026-08-08 17:22:33.592	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 18:22:33.81	2026-08-08 18:22:33.81	MANUAL
0a54edf6-ce22-4423-9eb5-cb6bc1186b1f	024b72fd-44b2-4f38-96c1-78b156fa58c2	3e0cd0a4-5889-49a7-8d50-13850f0f2ebd	b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	e460d3e1-6e27-4ee6-877c-d4e664a62bcd	COMPLETED	2026-08-08 10:22:33.592	2026-08-08 15:22:33.592	0	5.00	\N	\N	Yearly driver field work	2026-08-08 18:22:33.877	2026-08-08 18:22:33.877	MANUAL
9584a767-e5f4-4080-a054-d6cea18c08ef	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	c79049d8-ef5b-47ef-803b-c22bcc545285	e3cd9c96-272a-4b49-80cc-878dd0d59317	4f23afea-dad1-43f4-b35d-290f442df31a	COMPLETED	2026-08-08 16:41:58.17	2026-08-08 19:41:58.17	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 19:41:58.141	2026-08-08 19:41:58.278	LIVE
40155f01-7415-455a-a259-587e2af7719f	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	8336145c-8b29-4e78-a4d5-deb7814eb321	e3cd9c96-272a-4b49-80cc-878dd0d59317	f7311eeb-777c-47bb-b230-665bc00fc539	COMPLETED	2026-08-08 14:41:58.17	2026-08-08 18:41:58.17	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 19:41:58.386	2026-08-08 19:41:58.386	MANUAL
ef66d8c4-f9e7-4e3c-8255-0714e0ff7000	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	94e4917e-c897-4a20-a5fe-975d8334cab2	e3cd9c96-272a-4b49-80cc-878dd0d59317	7596db33-02b4-4f19-b4b6-72dda4a42715	COMPLETED	2026-08-08 11:41:58.17	2026-08-08 16:41:58.17	0	5.00	\N	\N	Yearly driver field work	2026-08-08 19:41:58.465	2026-08-08 19:41:58.465	MANUAL
d4c70ef0-79c0-4c3e-b191-190cb608c3ff	f33c8ba7-f382-4217-90cf-d9d133632537	67f4684e-4faf-452b-9443-2d1de7ebde7a	4d3bd6ff-d190-40c2-a439-0173ba1db673	719059e1-3eae-4f21-9e1b-e6c8baea80ab	COMPLETED	2026-08-08 15:23:51.916	2026-08-08 18:23:51.916	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 18:23:51.891	2026-08-08 18:23:52.023	LIVE
a7e75fb2-948f-4e44-918b-349684ea169f	f33c8ba7-f382-4217-90cf-d9d133632537	d42141db-c50d-412b-8131-57e5235f2fe3	4d3bd6ff-d190-40c2-a439-0173ba1db673	a99d6cd7-f926-49c8-afc3-f66c71ec5243	COMPLETED	2026-08-08 13:23:51.916	2026-08-08 17:23:51.916	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 18:23:52.125	2026-08-08 18:23:52.125	MANUAL
b659e1f2-4a6e-411c-889e-7834a063ee72	f33c8ba7-f382-4217-90cf-d9d133632537	09f89b5b-3629-4b30-a6ad-73ee0d897096	4d3bd6ff-d190-40c2-a439-0173ba1db673	69d0fa38-9408-427a-894b-8e37009f4451	COMPLETED	2026-08-08 10:23:51.916	2026-08-08 15:23:51.916	0	5.00	\N	\N	Yearly driver field work	2026-08-08 18:23:52.211	2026-08-08 18:23:52.211	MANUAL
ef957aa2-2cd7-4201-a363-fc93c810ddb8	ecbba26c-b8ee-4455-a09e-86fab13778df	591549bd-61a5-43fc-984c-4d8c650cdc2a	b61808f9-6b2e-4f80-8dd3-11909e2c884d	c8f29e7d-953e-4ff9-9da8-97ea57037c75	COMPLETED	2026-08-08 17:04:26.174	2026-08-08 20:04:26.174	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 20:04:26.16	2026-08-08 20:04:26.249	LIVE
7e5753d5-4ad9-4a9e-a58c-09110bf842e7	ecbba26c-b8ee-4455-a09e-86fab13778df	af28f33f-1a63-4b61-81a4-b0502a0afdfe	b61808f9-6b2e-4f80-8dd3-11909e2c884d	1eb6f6b0-2ad1-4c1c-96cc-76fcae41a0e7	COMPLETED	2026-08-08 15:04:26.174	2026-08-08 19:04:26.174	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 20:04:26.32	2026-08-08 20:04:26.32	MANUAL
ddf8c6ff-0fd5-495e-b32e-9470368ecd86	ecbba26c-b8ee-4455-a09e-86fab13778df	46f42d68-b2bc-4c52-aabb-f069c55992f8	b61808f9-6b2e-4f80-8dd3-11909e2c884d	048dd78c-ced5-4f25-bfca-2aac3bfa190f	COMPLETED	2026-08-08 12:04:26.174	2026-08-08 17:04:26.174	0	5.00	\N	\N	Yearly driver field work	2026-08-08 20:04:26.372	2026-08-08 20:04:26.372	MANUAL
afa86694-7d7d-4bef-a8cc-124361631c45	a6565866-d95e-4c4c-a2eb-76f3171c2907	f7f78fe2-fbd2-4cc4-bb8d-da62ed5ea659	8bc65fdb-4ab3-4edf-ada9-0601c295727f	affa378c-57a7-429d-8d2b-a68cdcf354ce	NOT_STARTED	\N	\N	0	\N	\N	\N	\N	2026-08-08 18:05:17.562	2026-08-08 18:05:17.562	LIVE
45446420-ca36-4ecf-9623-6410f1406684	2fc53fa9-07fd-4172-af37-6a1034df9ecb	526dc4ea-5d37-47d9-8678-e8825f1e6ce7	b992842f-5fa7-41a0-9a1c-5d933d0c6b8a	026b9227-d949-411b-b645-470004e4ffbf	COMPLETED	2026-08-08 18:05:31.698	2026-08-08 18:05:31.722	0	4.00	\N	\N	\N	2026-08-08 18:05:31.669	2026-08-08 18:05:31.724	LIVE
fd20d55f-8eb0-4810-a4e8-f5ed654cb4be	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	d7a5fa51-d422-49d6-a62d-22fac5d25cb6	142de1ae-b2d7-4726-a644-5f49d04e69c4	fae5c1d8-f25d-474b-b3e2-cd7d613d01f3	COMPLETED	2026-08-08 17:53:03.516	2026-08-08 20:53:03.516	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 20:53:03.502	2026-08-08 20:53:03.582	LIVE
cad31c2d-9e5b-4114-aef4-c188488db565	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	a0e3df07-7077-4922-a959-4a97e3bfa8ef	142de1ae-b2d7-4726-a644-5f49d04e69c4	2ce7d6e0-6c2a-4a93-b1ca-f2fe3945373a	COMPLETED	2026-08-08 15:53:03.516	2026-08-08 19:53:03.516	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 20:53:03.65	2026-08-08 20:53:03.65	MANUAL
61d207ed-79a0-4ee5-b3b8-deec5c1098e3	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	49f5ad86-5cc6-4c3e-a994-51b73911ae3c	142de1ae-b2d7-4726-a644-5f49d04e69c4	9d3b15a8-ff37-42d9-8704-b5cca82eccf0	COMPLETED	2026-08-08 12:53:03.516	2026-08-08 17:53:03.516	0	5.00	\N	\N	Yearly driver field work	2026-08-08 20:53:03.727	2026-08-08 20:53:03.727	MANUAL
9a0dc4e6-e857-418a-846b-a8446f1a91a9	40511429-f937-4f0f-8a0a-6869154b7144	97b7f047-acd4-4ab7-a684-a58d2a64f4e0	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	NOT_STARTED	\N	\N	0	\N	\N	\N	\N	2026-08-09 05:24:28.154	2026-08-09 05:24:28.154	LIVE
92f7feaf-6004-44d8-9f61-d15dd584fe78	c329669f-35fe-4787-84c9-902251b14695	c59c93d5-aeff-4a8d-83fd-ee77f7038507	b28aa61a-9544-4f6d-b733-7bd450ab0e53	74d9608a-08fd-4e3f-9ab2-03bf4ec6de0b	COMPLETED	2026-08-08 15:33:49.101	2026-08-08 18:33:49.101	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 18:33:49.073	2026-08-08 18:33:49.224	LIVE
03701452-2909-4590-ab1f-0796c1b8098c	c329669f-35fe-4787-84c9-902251b14695	d69e534b-0172-4693-928a-b97e29deac70	b28aa61a-9544-4f6d-b733-7bd450ab0e53	d91c3a85-5b3c-4581-9499-44a70f7c24fd	COMPLETED	2026-08-08 13:33:49.101	2026-08-08 17:33:49.101	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 18:33:49.314	2026-08-08 18:33:49.314	MANUAL
8516c52b-42d6-458a-be1b-d22637797428	c329669f-35fe-4787-84c9-902251b14695	26962e8e-bb8f-4f78-b23b-0f52c1549a24	b28aa61a-9544-4f6d-b733-7bd450ab0e53	1cfd404c-a11c-4bdc-a319-6ea54d6b1714	COMPLETED	2026-08-08 10:33:49.101	2026-08-08 15:33:49.101	0	5.00	\N	\N	Yearly driver field work	2026-08-08 18:33:49.388	2026-08-08 18:33:49.388	MANUAL
ae3d947a-8e17-4307-b3b3-8dcb96980e64	40511429-f937-4f0f-8a0a-6869154b7144	e2f59f8e-7a23-4143-8688-e0c39138f6b1	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	COMPLETED	2026-08-09 05:24:37.475	2026-08-09 05:24:37.524	0	2.00	\N	\N	\N	2026-08-09 05:24:37.43	2026-08-09 05:24:37.528	LIVE
1efdc8b8-1c87-44fc-b0f2-548072d0913d	3b4fa961-b987-4207-bade-425969e8e1a5	ae07c13a-9cd2-43bc-90d9-dc11e197b634	47b77082-85f7-4076-a807-e46743b14d1a	829e71a7-31b1-4d8c-83ce-bb780d6c4260	COMPLETED	2026-08-08 15:15:15.752	2026-08-08 18:15:15.752	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 18:15:15.739	2026-08-08 18:15:15.863	LIVE
4f08bb34-813a-4994-9702-6e10b4b6436f	40511429-f937-4f0f-8a0a-6869154b7144	f2822944-a077-49aa-8467-8165c80b177b	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	COMPLETED	2026-08-09 05:24:37.739	2026-08-09 05:24:37.768	0	5.00	\N	\N	\N	2026-08-09 05:24:37.71	2026-08-09 05:24:37.77	LIVE
30e89658-7dee-48ad-9293-a5d98b48ff2e	40511429-f937-4f0f-8a0a-6869154b7144	0273c3f6-77d3-46e8-970c-2552c957745b	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	COMPLETED	2026-08-09 05:24:48.252	2026-08-09 05:24:48.301	0	2.00	\N	\N	\N	2026-08-09 05:24:48.196	2026-08-09 05:24:48.305	LIVE
56218010-0bd8-4411-987c-738624a2c52a	40511429-f937-4f0f-8a0a-6869154b7144	085e1d1b-bd10-4bf6-8a5f-527645ef2fd2	b3f6b08f-7ff7-474a-b3f4-522fa59620de	bc3c685d-5076-4ad2-b3f0-921daee0523e	COMPLETED	2026-08-09 05:24:48.507	2026-08-09 05:24:48.533	0	5.00	\N	\N	\N	2026-08-09 05:24:48.475	2026-08-09 05:24:48.535	LIVE
945bca08-3884-4b70-9735-6d52193709c5	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	e14e5384-4ca3-4bf0-8e20-81c0c6b29acc	7cffb5ba-c738-4d32-8afc-dde5c24eac52	cfaf9d00-8728-49d1-a0b7-53a886d37887	COMPLETED	2026-08-08 15:48:19.363	2026-08-08 18:48:19.363	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 18:48:19.338	2026-08-08 18:48:19.484	LIVE
8015822f-8a9f-4c10-b540-062eb0bd4fb1	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	8403f49c-b44c-4219-8285-a0a15dc21cfc	7cffb5ba-c738-4d32-8afc-dde5c24eac52	ea648492-50f2-41b7-a4a8-4619492d59dc	COMPLETED	2026-08-08 13:48:19.363	2026-08-08 17:48:19.363	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 18:48:19.596	2026-08-08 18:48:19.596	MANUAL
35b2253a-5c08-4107-855e-0dcd76e2ef6f	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	e4e7a9a6-e2fd-439b-ae8e-6201da3da0d8	7cffb5ba-c738-4d32-8afc-dde5c24eac52	5792391b-6d3a-4bde-b612-53825149abd1	COMPLETED	2026-08-08 10:48:19.363	2026-08-08 15:48:19.363	0	5.00	\N	\N	Yearly driver field work	2026-08-08 18:48:19.694	2026-08-08 18:48:19.694	MANUAL
699c48a4-67a7-4bd6-af78-e6c080e9263d	023866d9-236a-41cc-a36f-b9e516720f54	efac0575-b89e-47fa-ae52-aa2e6b0c54fa	dfabea01-ad4b-48f9-8916-f19cbd6c5176	9713d310-89ea-4939-b59d-0c8418ab1f50	COMPLETED	2026-08-08 15:15:43.077	2026-08-08 18:15:43.077	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 18:15:43.042	2026-08-08 18:15:43.192	LIVE
91749a2f-6538-4080-8189-32464dd2b235	023866d9-236a-41cc-a36f-b9e516720f54	9d1bc692-b543-444b-9a49-1eb5e225fcb1	dfabea01-ad4b-48f9-8916-f19cbd6c5176	f362162c-0ef7-4562-9bfa-db40c75f9038	COMPLETED	2026-08-08 13:15:43.077	2026-08-08 17:15:43.077	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 18:15:43.302	2026-08-08 18:15:43.302	MANUAL
3abef0df-9d31-4fa4-b851-a95760333ee1	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	6825ca41-65ad-44d1-ac51-26c5e51a4aff	b4634256-8789-4db0-88c3-0042c94986f7	ff140ae3-cd9e-4b86-a578-763adfdbef5e	COMPLETED	2026-08-08 16:32:43.998	2026-08-08 19:32:43.998	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 19:32:43.98	2026-08-08 19:32:44.124	LIVE
133384a6-6025-4f6c-bc0a-0f6a5fe8c17c	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	dc7511b9-6fcf-4730-b8b6-4e20a011aa26	b4634256-8789-4db0-88c3-0042c94986f7	f0cab277-4386-4ba5-8f60-d63259da2085	COMPLETED	2026-08-08 14:32:43.998	2026-08-08 18:32:43.998	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 19:32:44.234	2026-08-08 19:32:44.234	MANUAL
aac6cd5b-5d09-4d88-b4c7-ed4aebcf4242	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	6ab3429f-2383-4980-99c5-7244afc0d29b	b4634256-8789-4db0-88c3-0042c94986f7	5289cbb6-f1f1-4335-b5e8-5cd0a6d630f4	COMPLETED	2026-08-08 11:32:43.998	2026-08-08 16:32:43.998	0	5.00	\N	\N	Yearly driver field work	2026-08-08 19:32:44.292	2026-08-08 19:32:44.292	MANUAL
72997389-5223-4313-be25-3b1d7cf6d591	3968e65b-4204-432c-ad93-26a831a79d3e	a8a397a8-71ec-497d-9745-3be4f431ca54	a9754ce6-cf7e-4f94-bfde-c900853d603a	9c115879-2053-4235-b1cc-f74836007f4f	COMPLETED	2026-08-08 16:38:59.422	2026-08-08 19:38:59.422	0	2.50	2.00	\N	Field harvesting complete	2026-08-08 19:38:59.389	2026-08-08 19:38:59.559	LIVE
08463cb9-9842-4a38-ae16-0cd55cc6d219	3968e65b-4204-432c-ad93-26a831a79d3e	31e7bed5-07ee-4a70-a026-8fd6b9154931	a9754ce6-cf7e-4f94-bfde-c900853d603a	016521df-2c84-4b1b-b206-8ef6b9e5f4cf	COMPLETED	2026-08-08 14:38:59.422	2026-08-08 18:38:59.422	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-08 19:38:59.649	2026-08-08 19:38:59.649	MANUAL
fb4d7a34-21e7-43ab-9b77-367612853d22	3968e65b-4204-432c-ad93-26a831a79d3e	02f93844-2adb-41c2-9635-6084d2666f3d	a9754ce6-cf7e-4f94-bfde-c900853d603a	ca505264-dd8c-44de-a80b-604cb57fa768	COMPLETED	2026-08-08 11:38:59.422	2026-08-08 16:38:59.422	0	5.00	\N	\N	Yearly driver field work	2026-08-08 19:38:59.742	2026-08-08 19:38:59.742	MANUAL
3942b3dc-2477-49cd-996d-85cf0816d10b	c331e53c-fe17-49c2-97f1-9466a87bbe42	e4231c07-5b61-4f16-9b9c-7b040ca31424	b94759ac-c1b4-4846-82ac-9ad0611f51ef	561a89dd-5391-4c0f-9a8d-4de9b1dd4331	COMPLETED	2026-08-09 05:40:15.427	2026-08-09 05:40:15.49	0	2.00	\N	\N	\N	2026-08-09 05:40:15.428	2026-08-09 05:40:15.494	LIVE
78a3042e-f6e5-42a9-849c-295ac0a9241c	c331e53c-fe17-49c2-97f1-9466a87bbe42	7f804728-32e9-4341-b000-092e6b695706	b94759ac-c1b4-4846-82ac-9ad0611f51ef	561a89dd-5391-4c0f-9a8d-4de9b1dd4331	COMPLETED	2026-08-09 05:40:15.566	2026-08-09 05:40:15.587	0	2.00	\N	\N	\N	2026-08-09 05:40:15.567	2026-08-09 05:40:15.59	LIVE
3b0986c3-db33-4406-b614-d1a99e743446	c331e53c-fe17-49c2-97f1-9466a87bbe42	08f5a7af-450a-4374-a1ab-4f46cc668a5d	41629117-a351-4d4d-a340-e67c4ef2995e	00baee60-ee3c-4c8d-99aa-363aa3f1d932	COMPLETED	2026-08-09 05:40:34.456	2026-08-09 05:40:34.503	0	2.00	\N	\N	\N	2026-08-09 05:40:34.469	2026-08-09 05:40:34.506	LIVE
a0161f32-7b9a-45b2-a0dc-54d57c085ce8	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	83ab09e2-4e35-4c61-ab59-4996abccf515	ad9d7815-3d41-44cc-847f-3b2a7628b50b	ca17848c-c61f-459f-80e3-4a34ef0cffbc	COMPLETED	2026-08-09 01:10:27.737	2026-08-09 06:10:27.737	0	5.00	\N	\N	Yearly driver field work	2026-08-09 09:10:28.125	2026-08-09 09:10:28.125	MANUAL
fcac71f1-c948-41ea-b454-d4c0593d1ff5	c331e53c-fe17-49c2-97f1-9466a87bbe42	276ebe92-db5b-402f-bdb0-3141ccf61217	41629117-a351-4d4d-a340-e67c4ef2995e	00baee60-ee3c-4c8d-99aa-363aa3f1d932	COMPLETED	2026-08-09 05:40:34.57	2026-08-09 05:40:34.611	0	2.00	\N	\N	\N	2026-08-09 05:40:34.572	2026-08-09 05:40:34.613	LIVE
f481c3e2-cbdf-48df-9f6e-20c76a4e4c9c	c331e53c-fe17-49c2-97f1-9466a87bbe42	c5d9e4d7-912b-4500-b739-0a12a76baa68	b3b1a599-c7e3-4795-ac3b-9b0ec89478af	006019a5-f6bc-4529-bdcb-5ae9b0bb365b	COMPLETED	2026-08-09 05:40:46.74	2026-08-09 05:40:46.78	0	2.00	\N	\N	\N	2026-08-09 05:40:46.743	2026-08-09 05:40:46.782	LIVE
6d78c450-19ee-403f-b85c-f6cac26273d8	c331e53c-fe17-49c2-97f1-9466a87bbe42	1edf1f0b-6c98-431e-9257-a8a1a1afffa2	b3b1a599-c7e3-4795-ac3b-9b0ec89478af	006019a5-f6bc-4529-bdcb-5ae9b0bb365b	COMPLETED	2026-08-09 05:40:46.904	2026-08-09 05:40:46.947	0	2.00	\N	\N	\N	2026-08-09 05:40:46.905	2026-08-09 05:40:46.95	LIVE
24029fc6-ff83-42a2-a8bd-8ff3cab4e21a	c331e53c-fe17-49c2-97f1-9466a87bbe42	add4274d-67e8-45b6-bc1e-5eb3aed23bae	ddf24861-df1a-40ce-8cbd-f8971788235e	86cf90cf-a146-4940-81a5-d36b0efee024	COMPLETED	2026-08-09 05:40:53.309	2026-08-09 05:40:53.342	0	2.00	\N	\N	\N	2026-08-09 05:40:53.31	2026-08-09 05:40:53.344	LIVE
01e90f7c-5f30-4efb-b5e5-b221c5421cb9	c331e53c-fe17-49c2-97f1-9466a87bbe42	31e8f624-09ce-4ba2-91d2-a2021f772560	ddf24861-df1a-40ce-8cbd-f8971788235e	86cf90cf-a146-4940-81a5-d36b0efee024	WORKING	2026-08-09 05:40:53.421	\N	0	\N	\N	\N	\N	2026-08-09 05:40:53.422	2026-08-09 05:40:53.422	LIVE
1bd680bd-7b58-4c9f-898c-159b8efd0de9	c331e53c-fe17-49c2-97f1-9466a87bbe42	19961e12-5184-41ed-b724-ca75774410ab	df9d9af3-48bd-4dcb-a4c7-ad0ae5996a14	ba502108-1332-4e02-9f07-1bfdaba21ff1	COMPLETED	2026-08-09 05:41:01.237	2026-08-09 05:41:01.271	0	2.00	\N	\N	\N	2026-08-09 05:41:01.238	2026-08-09 05:41:01.274	LIVE
8e96f9c4-8808-4223-86d1-4347dc489580	c331e53c-fe17-49c2-97f1-9466a87bbe42	47e46ee5-2384-4f52-989c-5d217d489c36	df9d9af3-48bd-4dcb-a4c7-ad0ae5996a14	ba502108-1332-4e02-9f07-1bfdaba21ff1	WORKING	2026-08-09 05:41:01.404	\N	0	\N	\N	\N	\N	2026-08-09 05:41:01.407	2026-08-09 05:41:01.407	LIVE
ba0297ad-ff88-4194-9c92-0fbad95b8203	c331e53c-fe17-49c2-97f1-9466a87bbe42	c3b67438-2f2c-40c5-bcea-d9d6a2b42692	aeed00f6-2da0-4e2d-a7ec-7abd7d5e9df2	b56ded97-d5d9-4f05-afc2-ccfc280d096d	COMPLETED	2026-08-09 05:41:15.486	2026-08-09 05:41:15.513	0	2.00	\N	\N	\N	2026-08-09 05:41:15.487	2026-08-09 05:41:15.516	LIVE
0ac46231-bde7-4d30-bd07-76c591c04221	c331e53c-fe17-49c2-97f1-9466a87bbe42	94cea4e8-e52a-4e70-a006-e3021a017ce6	aeed00f6-2da0-4e2d-a7ec-7abd7d5e9df2	b56ded97-d5d9-4f05-afc2-ccfc280d096d	WORKING	2026-08-09 05:41:15.581	\N	0	\N	\N	\N	\N	2026-08-09 05:41:15.582	2026-08-09 05:41:15.582	LIVE
c8d0dd8d-9e0c-4d17-9990-5fa7d5902d39	c331e53c-fe17-49c2-97f1-9466a87bbe42	516f1700-a528-4e2c-98ab-126e0bbc2eeb	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	COMPLETED	2026-08-09 05:41:24.469	2026-08-09 05:41:24.501	0	2.00	\N	\N	\N	2026-08-09 05:41:24.47	2026-08-09 05:41:24.503	LIVE
37255ac4-f95f-4e13-a365-da711ff5c3e8	6571c3c9-9c94-4b02-ac20-829a9af731b6	bc1515e9-ef2c-44ee-8246-c30b6563948c	438e3ded-9440-4f7d-b87e-e5c7ce0b939a	2d7190cc-31fe-4df8-b118-327a8fe6b4b9	COMPLETED	2026-08-09 05:45:02.562	2026-08-09 08:45:02.562	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 08:45:02.534	2026-08-09 08:45:02.681	LIVE
75e3eb25-317d-47e3-9d4c-e90c6b3a8224	c331e53c-fe17-49c2-97f1-9466a87bbe42	1263ff0a-a99c-4def-95bd-f7c8e3d6c4ff	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	COMPLETED	2026-08-09 05:41:24.568	2026-08-09 05:41:24.726	0	2.00	\N	\N	\N	2026-08-09 05:41:24.569	2026-08-09 05:41:24.731	LIVE
70927cc8-ddfa-43ef-a984-ae9976596a52	6571c3c9-9c94-4b02-ac20-829a9af731b6	68a87cc5-73a1-49e6-a1e9-4086fbf50f2d	438e3ded-9440-4f7d-b87e-e5c7ce0b939a	dd35887e-0923-46ce-9fcc-a25f7adbeec0	COMPLETED	2026-08-09 03:45:02.562	2026-08-09 07:45:02.562	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 08:45:02.814	2026-08-09 08:45:02.814	MANUAL
e404553f-5d32-4c78-8795-ad9a570bd381	c331e53c-fe17-49c2-97f1-9466a87bbe42	3b7a32fe-dc91-4dc7-96de-4854ee7d0b4f	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	COMPLETED	2026-08-09 05:41:24.795	2026-08-09 05:41:24.818	0	3.00	\N	\N	\N	2026-08-09 05:41:24.796	2026-08-09 05:41:24.82	LIVE
c2f79895-9ae6-472e-b58e-40d432031067	6571c3c9-9c94-4b02-ac20-829a9af731b6	8c35380a-34bd-46a8-8f51-a8a5e7cedb56	438e3ded-9440-4f7d-b87e-e5c7ce0b939a	f2f5613d-b786-4575-bfd8-8610f00ec2ca	COMPLETED	2026-08-09 00:45:02.562	2026-08-09 05:45:02.562	0	5.00	\N	\N	Yearly driver field work	2026-08-09 08:45:02.9	2026-08-09 08:45:02.9	MANUAL
19ce7b52-7a46-4648-b54b-b5cc5d38d869	c331e53c-fe17-49c2-97f1-9466a87bbe42	20fae768-75f8-49e0-ba9b-c8e084a6fda7	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	COMPLETED	2026-08-09 05:41:24.873	2026-08-09 05:41:24.953	0	3.00	\N	15.00	\N	2026-08-09 05:41:24.874	2026-08-09 05:41:24.956	LIVE
02c0c5e5-d727-490c-be21-2b4789c3d657	c331e53c-fe17-49c2-97f1-9466a87bbe42	50c904e1-9d72-49fb-92a8-a9509a8f2145	e4e64b4d-83e1-4fb6-af76-9476923ecc15	07514d29-246d-40f0-a1f6-83e1154dbb97	COMPLETED	2026-08-09 05:41:25.034	2026-08-09 05:41:25.133	0	4.00	\N	20.00	\N	2026-08-09 05:41:25.035	2026-08-09 05:41:25.135	LIVE
34552d70-2767-4e9c-ad24-efde49304ecc	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	4f087fdf-7751-4208-b0e9-13e99e34cbc5	fc9d0cf9-747b-4b68-87fc-8e2fc4972645	f8404ad6-a495-46da-9822-5ee75f15e530	COMPLETED	2026-08-09 02:57:15.368	2026-08-09 05:57:15.368	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 05:57:15.323	2026-08-09 05:57:15.511	LIVE
6cf3e74e-a4f9-4133-9411-48efdded6714	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	718780b5-7d7f-499a-93d9-c0346b046891	fc9d0cf9-747b-4b68-87fc-8e2fc4972645	901fa541-1770-4922-83b9-f49114e44896	COMPLETED	2026-08-09 00:57:15.368	2026-08-09 04:57:15.368	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 05:57:15.644	2026-08-09 05:57:15.644	MANUAL
cab08798-aeb3-422a-a767-d3ce314c195e	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	723e1ea3-53ce-42a4-bef6-324ee38f62f8	fc9d0cf9-747b-4b68-87fc-8e2fc4972645	4ec7738f-5693-45b7-9e82-b5663066ad4d	COMPLETED	2026-08-08 21:57:15.368	2026-08-09 02:57:15.368	0	5.00	\N	\N	Yearly driver field work	2026-08-09 05:57:15.787	2026-08-09 05:57:15.787	MANUAL
3e8b842b-47c2-4b82-9042-e1c7df579324	4613e40d-bba4-424a-970e-ffc7836a19e2	f87d2540-dbc3-43b2-b964-72fef6fd2c2f	5765c74a-7d2f-4443-8abe-2487b4bd6b56	d5de70d4-0b48-48f1-89fa-614e368b86c7	COMPLETED	2026-08-09 05:47:58.898	2026-08-09 08:47:58.898	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 08:47:58.872	2026-08-09 08:47:59.019	LIVE
e2c7a155-fc6f-4523-b4fb-a3e9c877740c	d8d7190c-b0f9-42e6-a510-8a401b035039	4946acf4-a12e-4c3b-b209-b7e36c649947	e6449a5d-c8d3-45a3-8b69-5b58a620f766	2db11df0-7514-4376-bc72-9b76a2b32bce	NOT_STARTED	\N	\N	0	\N	\N	\N	\N	2026-08-09 06:00:22.477	2026-08-09 06:00:22.477	LIVE
dafa3727-fac2-4b54-adb8-9b8fb2118174	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	b4f93cab-a074-48b3-8319-76d72a5db136	a23d99b5-8b66-40fc-bf2c-ba585333b551	d51f987d-b94e-4656-a338-b7f4d8194e8e	NOT_STARTED	\N	\N	0	\N	\N	\N	\N	2026-08-09 06:00:29.799	2026-08-09 06:00:29.799	LIVE
1a3827d4-3216-4afc-9559-694ffad2a6ba	4613e40d-bba4-424a-970e-ffc7836a19e2	2a2aaf0a-4340-4b6b-9c57-4fb57f943b97	5765c74a-7d2f-4443-8abe-2487b4bd6b56	7d192e61-4c2c-4c3f-9637-5036343b6007	COMPLETED	2026-08-09 03:47:58.898	2026-08-09 07:47:58.898	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 08:47:59.144	2026-08-09 08:47:59.144	MANUAL
cd72f5d5-4de7-4597-9215-80c3573c154c	4613e40d-bba4-424a-970e-ffc7836a19e2	3f1b22d5-d787-43ef-86d6-96b54e8957af	5765c74a-7d2f-4443-8abe-2487b4bd6b56	42ab42fb-00b5-42ee-8b7a-0a6db3e6a9c4	COMPLETED	2026-08-09 00:47:58.898	2026-08-09 05:47:58.898	0	5.00	\N	\N	Yearly driver field work	2026-08-09 08:47:59.231	2026-08-09 08:47:59.231	MANUAL
904de97f-7816-4197-822d-7302e3311687	7a92e240-df0b-4c44-8bba-bd7574ae788b	5481bb47-a79e-45aa-bab2-f7cc6d9d1b5b	244e2f3a-d41d-476b-97be-5f507048c9c3	533ebebc-3805-4cca-bbe4-514d18f289b3	COMPLETED	2026-08-09 06:00:45.009	2026-08-09 06:00:45.333	0	5.00	3.50	15.00	Plowing completed successfully	2026-08-09 06:00:45.001	2026-08-09 06:00:45.335	LIVE
883d6917-5c55-4a6a-8680-68257798433f	8951aa6b-476b-46b7-b12b-de1998c8bbf7	72863e74-c2f4-4664-8bd2-361afb260c1c	c5cb5d71-cb32-42b5-a2ac-c48b8c845f7e	60e3d45f-1001-4e82-b97b-9d038d9e2a11	COMPLETED	2026-08-09 06:00:59.386	2026-08-09 06:00:59.699	0	5.00	3.50	15.00	Plowing completed successfully	2026-08-09 06:00:59.381	2026-08-09 06:00:59.701	LIVE
da31e76d-541c-4b22-9e73-6adfc05cd222	d563fb11-8e19-4079-a843-4d579ba681ee	de6c32ea-506a-4185-a152-4d2e7ded6f61	ece6db08-b21e-4738-bc77-9800dd0c5c5d	75a463db-95e9-413c-8976-8a23150e00b7	COMPLETED	2026-08-09 06:01:11.313	2026-08-09 06:01:11.417	0	2.00	\N	10.00	\N	2026-08-09 06:01:11.31	2026-08-09 06:01:11.421	LIVE
bf6060c6-6f66-465c-b5ab-99bae7e3af69	8951aa6b-476b-46b7-b12b-de1998c8bbf7	488eed82-af85-4e0a-b913-aeed929249ae	c5cb5d71-cb32-42b5-a2ac-c48b8c845f7e	60e3d45f-1001-4e82-b97b-9d038d9e2a11	COMPLETED	2026-08-09 06:00:59.825	2026-08-09 06:00:59.93	0	10.00	8.00	30.00	Commercial work completed	2026-08-09 06:00:59.823	2026-08-09 06:00:59.933	LIVE
2bab8f27-d2da-4e5b-b5f9-a427b1e564ec	d563fb11-8e19-4079-a843-4d579ba681ee	917b5051-a895-49b9-806b-0af8b07cc757	ece6db08-b21e-4738-bc77-9800dd0c5c5d	75a463db-95e9-413c-8976-8a23150e00b7	COMPLETED	2026-08-09 06:01:10.653	2026-08-09 06:01:10.976	0	5.00	3.50	15.00	Plowing completed successfully	2026-08-09 06:01:10.649	2026-08-09 06:01:10.978	LIVE
e1c4e55b-06e9-4337-a19c-846d983dbd21	d563fb11-8e19-4079-a843-4d579ba681ee	ec1bfe4a-2a53-40b2-ba85-3bc5dc2e67be	ece6db08-b21e-4738-bc77-9800dd0c5c5d	75a463db-95e9-413c-8976-8a23150e00b7	COMPLETED	2026-08-09 06:01:11.134	2026-08-09 06:01:11.237	0	10.00	8.00	30.00	Commercial work completed	2026-08-09 06:01:11.131	2026-08-09 06:01:11.24	LIVE
bb6450c4-1ac9-466e-a2ce-3306c7ff4447	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	f3694c61-ded1-4396-a40c-d3ab227dcc87	27540f0a-20ac-4e1b-bd37-c1583db03028	3c57013a-0fb7-42c7-82fd-596f96e68001	COMPLETED	2026-08-09 03:01:25.285	2026-08-09 06:01:25.285	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 06:01:25.265	2026-08-09 06:01:25.417	LIVE
3edb7f11-ae39-4995-8466-d9579fd7e4ac	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	b3b48f13-43c0-4c04-ab1f-f0275909481c	27540f0a-20ac-4e1b-bd37-c1583db03028	368ab7ff-3124-4d4e-ba94-5d7aaa262e72	COMPLETED	2026-08-09 01:01:25.285	2026-08-09 05:01:25.285	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 06:01:25.533	2026-08-09 06:01:25.533	MANUAL
18292f45-885e-4c13-9d32-9376d81908cd	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	f342d045-8f17-42f6-987b-9ffd307b9dc6	27540f0a-20ac-4e1b-bd37-c1583db03028	1b6c0f78-b773-45c1-a7a1-5e78de790c94	COMPLETED	2026-08-08 22:01:25.285	2026-08-09 03:01:25.285	0	5.00	\N	\N	Yearly driver field work	2026-08-09 06:01:25.628	2026-08-09 06:01:25.628	MANUAL
b8f74b9c-c5d9-4d72-948e-6f892a3e5d9c	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	1aca63a7-1b55-43f6-a212-067b4a8d998f	ad9d7815-3d41-44cc-847f-3b2a7628b50b	7986cfdb-6f4e-4dbb-a571-53556a4015e0	COMPLETED	2026-08-09 06:10:27.737	2026-08-09 09:10:27.737	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 09:10:27.722	2026-08-09 09:10:27.862	LIVE
5fb8bdec-e8fb-4d4f-b17b-daa3312976f6	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	09e674a1-3b3c-4b77-b2ea-9a20be04a7d4	ad9d7815-3d41-44cc-847f-3b2a7628b50b	5965448a-26f4-4c56-8b8b-1c4bc14ccc5e	COMPLETED	2026-08-09 04:10:27.737	2026-08-09 08:10:27.737	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 09:10:28.015	2026-08-09 09:10:28.015	MANUAL
f5487709-febc-46d4-a8f9-bf25da3e9b6d	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	8097a678-4eaf-4e98-a5dc-43512752e0d4	c790842b-760d-4cad-b053-8cc6091bb4e9	88e5c90e-5fa1-48c3-8511-68744fffd513	COMPLETED	2026-08-09 05:53:41.713	2026-08-09 08:53:41.713	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 08:53:41.692	2026-08-09 08:53:41.835	LIVE
782df47c-5c80-4c4e-a272-4ce3603b7f9a	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	53afb2d2-30ce-4277-ad17-2eaae6c8661b	c790842b-760d-4cad-b053-8cc6091bb4e9	1a1c7b26-79a8-4f53-9c59-d6931e847e51	COMPLETED	2026-08-09 03:53:41.713	2026-08-09 07:53:41.713	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 08:53:41.961	2026-08-09 08:53:41.961	MANUAL
7663ae92-f0db-43df-b459-ec1ef86b6d95	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	ca2fa862-a997-4ca5-91a2-2fcb1eb1d6b7	c790842b-760d-4cad-b053-8cc6091bb4e9	cc727664-a212-485a-82a1-d0013c0ad9ed	COMPLETED	2026-08-09 00:53:41.713	2026-08-09 05:53:41.713	0	5.00	\N	\N	Yearly driver field work	2026-08-09 08:53:42.044	2026-08-09 08:53:42.044	MANUAL
3a51e139-ccf3-44f4-9323-8fec30334462	b3bd9148-5bcf-46c7-aae9-d07d688834ca	a210207d-d1e0-49a5-82d1-6b3a2cc7dc15	f5024078-737d-4a6e-90e7-2b28964d9722	9969fef3-e797-4c1b-877a-578c17bc93b3	COMPLETED	2026-08-09 06:03:26.083	2026-08-09 09:03:26.083	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 09:03:26.069	2026-08-09 09:03:26.19	LIVE
a35cf4a7-28b1-4d25-a4c3-c7adbbb8f63e	b3bd9148-5bcf-46c7-aae9-d07d688834ca	fba0e72f-d1d1-4938-8ca0-bb2603ea8434	f5024078-737d-4a6e-90e7-2b28964d9722	12c7cdc4-3d41-44c5-a3d1-2a79734298fd	COMPLETED	2026-08-09 04:03:26.083	2026-08-09 08:03:26.083	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 09:03:26.327	2026-08-09 09:03:26.327	MANUAL
0c0a43fa-13fd-4206-9f9d-8f8bc1772fd8	b3bd9148-5bcf-46c7-aae9-d07d688834ca	f64b1aa0-d902-4ca7-acc8-29674de02fa6	f5024078-737d-4a6e-90e7-2b28964d9722	c66895e0-8aaf-44e8-9e14-e87453cd2d5c	COMPLETED	2026-08-09 01:03:26.083	2026-08-09 06:03:26.083	0	5.00	\N	\N	Yearly driver field work	2026-08-09 09:03:26.395	2026-08-09 09:03:26.395	MANUAL
56a48c3c-afdb-4e99-96c9-515240967c56	0757faaa-e55d-4863-9e88-c738651afa4c	aa1d2888-7967-4130-b6e8-e115c50f0d2f	65aa4462-0a46-4bc5-aa07-bf538b853620	8eaeaffa-8cf5-4159-91de-7d3f574c1dbc	COMPLETED	2026-08-09 06:06:26.083	2026-08-09 09:06:26.083	0	2.50	2.00	\N	Field harvesting complete	2026-08-09 09:06:26.068	2026-08-09 09:06:26.216	LIVE
7e3033ad-de05-4e0b-a914-bbe9acdaab1e	0757faaa-e55d-4863-9e88-c738651afa4c	12f3aaec-3711-4de6-8996-99146a70fcfe	65aa4462-0a46-4bc5-aa07-bf538b853620	fd34d234-59ed-41cb-b051-4df09bac405a	COMPLETED	2026-08-09 04:06:26.083	2026-08-09 08:06:26.083	0	4.00	3.50	15.00	Late night after-work manual entry	2026-08-09 09:06:26.342	2026-08-09 09:06:26.342	MANUAL
58eee8f5-1ac6-4904-b6d9-aed7e3a59dea	0757faaa-e55d-4863-9e88-c738651afa4c	efbb5ceb-77b8-472c-a19e-61b5170479e0	65aa4462-0a46-4bc5-aa07-bf538b853620	b50a96dd-1b7b-40de-a33b-4e2789e2d9ed	COMPLETED	2026-08-09 01:06:26.083	2026-08-09 06:06:26.083	0	5.00	\N	\N	Yearly driver field work	2026-08-09 09:06:26.412	2026-08-09 09:06:26.412	MANUAL
\.


--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.licenses (id, license_number, saas_user_id, company_id, payment_id, start_date, expiry_date, status, renewal_count, notes, created_at, updated_at) FROM stdin;
9286bbe5-1acb-4516-82d8-31faa2419883	SAG-2026-24D4A1	567db271-c727-48d8-a006-cbffd4ef6125	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:45:36.081	2026-08-09 08:45:36.081
2996cf02-7aae-4571-992d-0edbad11a58f	SAG-2026-3852FB	eb7c5f04-73cd-4cab-9482-9d226ad5a76d	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:45:53.104	2026-08-09 08:45:53.104
88720ceb-9770-4a47-b443-b9783ff5cd7a	SAG-2026-19A60C	8f50bd4d-ff05-4f80-b4a0-30467581d715	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:45:53.525	2026-08-09 08:45:53.525
18aefb21-5ba6-42d9-866c-f7de51559e9a	SAG-2026-CAEA19	8f50bd4d-ff05-4f80-b4a0-30467581d715	\N	\N	2026-08-09 08:45:53.543	2027-08-09 08:45:53.543	LICENSE_ACTIVE	0	Annual PRO License Issued by Super Admin	2026-08-09 08:45:53.544	2026-08-09 08:45:53.544
ba29ea22-3031-4256-acc1-29969c20e88d	SAG-2026-ED9DFE	b2dd6b3c-c0af-460c-a1b1-2f51787c621a	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:03.372	2026-08-09 08:46:03.372
d0cd5ae8-97e4-4f79-b763-53d373c18c7e	SAG-2026-3D2D5D	dca6e873-da45-4439-a37c-02ac7e773bfe	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:03.789	2026-08-09 08:46:03.789
2cfd6129-cae2-48e4-9f42-9a3d98a9167e	SAG-2026-1CC6D2	dca6e873-da45-4439-a37c-02ac7e773bfe	\N	\N	2026-08-09 08:46:03.806	2027-08-09 08:46:03.806	LICENSE_ACTIVE	0	Annual PRO License Issued by Super Admin	2026-08-09 08:46:03.807	2026-08-09 08:46:03.807
860c0ec6-3847-4a3f-8dd6-9bc9bea19cbd	SAG-2026-18D504	c3682f6c-b267-4092-a4a4-4a2ea61eb217	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:11.387	2026-08-09 08:46:11.387
510e1175-e5c0-4349-8a94-27396e3804f7	SAG-2026-BD3079	334379fe-8e73-44c0-b273-e85494b33631	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:11.763	2026-08-09 08:46:11.763
59692180-b040-47a9-98f5-16a2338cd453	SAG-2026-E00B3E	334379fe-8e73-44c0-b273-e85494b33631	\N	\N	2026-08-09 08:46:11.779	2027-08-09 08:46:11.779	LICENSE_ACTIVE	0	Annual PRO License Issued by Super Admin	2026-08-09 08:46:11.782	2026-08-09 08:46:11.782
5dc37f00-2407-4c9b-bac1-12c4bddf4bb6	SAG-2026-74EF65	93db087c-2924-4c4a-bdbd-06fd6cacd476	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:20.606	2026-08-09 08:46:20.606
d976743c-14d6-44a9-9c92-4def1e1d3b44	SAG-2026-28220E	db6fe497-8cab-411a-8155-806b0f7b97c2	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:21.026	2026-08-09 08:46:21.026
6a72f046-c496-45ce-844c-d003988ffc89	SAG-2026-B15ADC	db6fe497-8cab-411a-8155-806b0f7b97c2	\N	\N	2026-08-09 08:46:21.044	2027-08-09 08:46:21.044	LICENSE_ACTIVE	0	Annual PRO License Issued by Super Admin	2026-08-09 08:46:21.046	2026-08-09 08:46:21.046
198b37f1-ecdb-4fc6-aee0-d58ef760fb17	SAG-2026-FCD08B	2a511485-aa8b-4935-8df8-c0342f273d0d	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:27.967	2026-08-09 08:46:27.967
3f574784-581a-4f13-abf2-2ed37333cee5	SAG-2026-7EC4AB	cc521f60-b071-42d3-8181-7a3fc57ca34d	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:28.412	2026-08-09 08:46:28.412
e5928390-9d9c-4d0c-b142-0efefd644b72	SAG-2026-7B7E04	cc521f60-b071-42d3-8181-7a3fc57ca34d	\N	03cbe04e-f4cd-4d6e-9dd4-bb5382801245	2026-08-09 08:46:28.467	2027-08-09 08:46:28.467	LICENSE_ACTIVE	0	Annual PRO License Issued by Super Admin	2026-08-09 08:46:28.431	2026-08-09 08:46:28.469
ab6db3b0-e554-42b8-a213-41807a1f4483	SAG-2026-C5B25C	fb72511f-4cfc-4336-83b6-89ad5f3a6c33	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:35.046	2026-08-09 08:46:35.046
0dc71cd6-ad72-4136-8868-ba986f2646d1	SAG-2026-FC2ED0	b2044d11-22a7-4df3-b2fe-5513b1011e2f	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 08:46:35.472	2026-08-09 08:46:35.472
0e399854-4b1a-4607-ad33-e592a9af6054	SAG-2026-06E8B7	b2044d11-22a7-4df3-b2fe-5513b1011e2f	\N	9ce19928-8cca-46c6-ac95-792b819b7928	2026-08-09 08:46:35.535	2027-08-09 08:46:35.535	LICENSE_ACTIVE	0	Annual PRO License Issued by Super Admin	2026-08-09 08:46:35.494	2026-08-09 08:46:35.536
762b911e-143c-4a06-8eba-288dd7b061fe	SAG-2026-BBEC83	c144d6e8-9bbc-48cc-b536-c87b82b2a88d	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 09:03:11.438	2026-08-09 09:03:11.438
d372499e-6105-4f0f-85f7-f15d40f7884d	SAG-2026-A1D931	3788bc3f-7d6f-4b2c-a823-226ca6160bcc	\N	\N	\N	\N	REGISTERED	0	\N	2026-08-09 09:03:11.868	2026-08-09 09:03:11.868
7f90a53c-60a8-41e8-a3f3-bcfe76410064	SAG-2026-2AD992	3788bc3f-7d6f-4b2c-a823-226ca6160bcc	\N	0cd7edff-989b-454d-bf3e-d8954a8aa2a3	2026-08-09 09:03:11.92	2027-08-09 09:03:11.92	LICENSE_ACTIVE	0	Annual PRO License Issued by Super Admin	2026-08-09 09:03:11.883	2026-08-09 09:03:11.921
\.


--
-- Data for Name: machine_types; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.machine_types (id, company_id, name) FROM stdin;
b0e9cfa1-6ebd-4258-8ec0-45b5e0feebbe	b3bd9148-5bcf-46c7-aae9-d07d688834ca	Harvester
d3394513-3404-478c-a39e-7f4597c202b3	83a7bea6-85d2-46e7-a1e1-b6be122ead57	Tractor B 1786266207750
81be83cb-e309-4fec-bf5c-1302681d2a80	c329669f-35fe-4787-84c9-902251b14695	Harvester
f012b828-04f4-4a29-9bd4-d6d38658806a	3decee45-30cb-44d3-aa82-9c76aaaf17f9	Tractor B
f3125c0f-2048-4a83-95b2-2080f52afe09	1f766620-668a-48de-8607-7683021a0a54	Tractor B 1786214839734
04c68931-79cf-4e19-8de1-ed49680166cb	91a9917a-f0fd-4190-9e08-bdffb119b6a2	Tractor B 1786214848188
2181dcb6-5993-4e78-93d1-0ee20e51e322	0757faaa-e55d-4863-9e88-c738651afa4c	Harvester
41659194-6229-4716-8aaf-73a35e219a0e	ecc55e3b-6b1a-438b-8ca4-e87e85c5ad18	Tractor B 1786214855482
269a68ee-58ad-4d31-a10d-188050f1f9a5	bf778816-9b29-4799-8e98-12ad5e14f1cc	Tractor B 1786214863010
e103a16b-bd58-4f9f-bc08-a6c560128908	f029f473-5cf7-4e43-a467-53bf749c007f	Tractor B 1786266387848
f4948c3a-2798-4c72-a0c3-99d69cadb784	8216654d-92e2-4c32-a802-59e105e5e231	Tractor B 1786214868737
d8815999-946d-403e-8b42-f0ac180185cf	e9c09207-6fea-46d5-8f07-7464472a519a	Harvester
cd27c797-af9c-4683-94c9-1c965bfdb09a	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	Harvester
a679395a-dbe5-40c1-9950-60d141136d66	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	Harvester
70adf903-1c24-4f95-88b0-601e0f825f92	8fbaf386-5fd4-44cb-9119-9108a7c653c2	Tractor B 1786212275037
4978446e-6632-421d-8a11-e351b182634d	1a1ead59-2b11-4f2a-85e5-71c30252fbab	Tractor B 1786212285428
54c27f7f-aaee-421c-9203-05c28090b957	c40dd20c-a216-4766-8dd3-db89037b4bc4	Tractor B 1786212295780
e4de6564-2250-47a0-ae25-73f18f1c1a85	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	Tractor B 1786212306832
bea1a6ca-e72f-4c3e-a198-26851caaf300	a6565866-d95e-4c4c-a2eb-76f3171c2907	Tractor B 1786212317057
432bfd6d-f171-46d9-acca-15b465c83334	2fc53fa9-07fd-4172-af37-6a1034df9ecb	Tractor B 1786212331132
5703ba4e-7bed-4635-b9dc-398933b88dfa	c8db4f1b-5092-4569-bea4-eaf2910c6faa	Tractor B 1786214902868
57d3d585-88ad-4838-baeb-32ea40cd849d	e0d94522-f11b-4854-bc46-fbea888f97fe	Tractor B 1786266629477
addc69ad-2d55-485b-bc22-ba5ab686af0f	655207e4-3278-43ad-862c-ded9ebab17ad	Tractor B 1786217560165
358fbbe6-3752-43ac-a53d-05edfe827da6	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	Harvester
b5e22862-e4b5-4cae-a866-11f59cea2a1d	c331e53c-fe17-49c2-97f1-9466a87bbe42	Harvester
622f8b30-4b2b-4c5f-8615-446e540aac86	a7ed8578-e3b6-4aec-91b1-214d09748c0e	Harvester
fe5ea775-07a3-4d50-9ac2-fb4df3ec9367	b51f455a-feb6-445f-8b08-8624162dc98b	Harvester
26b4cb6f-90b2-40ea-9f73-0c37b16f7acc	3b4fa961-b987-4207-bade-425969e8e1a5	Harvester
5e2b3aef-42f8-4d36-8cac-d9fe24c2270a	a131ac13-2fcf-4978-b15d-625caa686889	Tractor B 1786217935613
ce534158-576f-4410-b368-717e8168a02c	3968e65b-4204-432c-ad93-26a831a79d3e	Harvester
cf8caae4-d218-4301-8afe-6932775717a6	32c8de26-7af9-42c6-ad11-7c29676eedef	Tractor B 1786218114338
614232ec-15c0-490c-9bed-787a491fd3ba	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	Harvester
fef17524-944f-4c81-9e4b-78c97f807ddf	023866d9-236a-41cc-a36f-b9e516720f54	Harvester
3e0a87cd-f855-4aad-aab6-2601816c431f	024b72fd-44b2-4f38-96c1-78b156fa58c2	Harvester
5060cd8f-52ee-491d-a030-912a983b4bb5	f45447c4-0020-483d-b359-07f94c2c5f63	Tractor B 1786219462382
d1e38e81-4b94-4bbb-8ad7-083e3b7e352e	ecbba26c-b8ee-4455-a09e-86fab13778df	Harvester
ec404f04-059e-4232-8d2c-f24733eb4aec	f33c8ba7-f382-4217-90cf-d9d133632537	Harvester
bb93d29c-959e-47bd-84eb-781c15eadc65	bf2044b6-c144-49f8-99ad-4c8b553c7bab	Tractor B 1786222379208
36b6bc06-e0b7-4e8a-a4a5-ae0bb77137cd	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	Harvester
8dc419dc-6459-41a7-a429-5c95d3eb9191	40511429-f937-4f0f-8a0a-6869154b7144	Tractor Audit Type
2bdc6703-2f57-4fd9-a09f-104fa01ef9fc	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	Harvester
dc460970-446a-4961-93f6-5f81033c108f	81a49a66-8a66-412a-baa0-0e6c9dbe9ee4	Tractor B 1786255047288
552cd3c6-382f-4b84-914c-d082c1a2b697	d8d7190c-b0f9-42e6-a510-8a401b035039	Tractor 55HP
e7e48a6d-bda3-4a26-8485-f5cf0e583dc4	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	Tractor 55HP
859ae9e4-1f01-4a37-9d99-129177925ef8	7a92e240-df0b-4c44-8bba-bd7574ae788b	Tractor 55HP
37413664-f56a-4fa5-91ef-4f182e6e1b53	8951aa6b-476b-46b7-b12b-de1998c8bbf7	Tractor 55HP
e31fb1a9-3309-4983-b7e6-01a81455f3be	d563fb11-8e19-4079-a843-4d579ba681ee	Tractor 55HP
1e830767-9a8d-429a-9b73-f698ef5b4f86	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	Harvester
358b21db-d4e3-4f0a-b326-edc5fbc6f623	00a648e6-059a-4f7c-8a0a-db23f4b72728	Tractor B 1786255296835
5177cb50-af06-4baa-9628-00e8678894ba	6571c3c9-9c94-4b02-ac20-829a9af731b6	Harvester
8f69ddac-a325-420f-a2fe-6bfb2b7297ad	9e6118fb-f9a3-4475-bc22-65171cb0b8a9	Tractor B 1786265105884
70e621d3-acf8-4666-9cfe-0895db066730	4613e40d-bba4-424a-970e-ffc7836a19e2	Harvester
71ae06f9-bbae-4deb-9b3d-a9c3f8ec4aaa	6a965ec6-8bec-4b37-abe7-fcc032b63905	Tractor B 1786265281066
bd210942-7654-4293-99a7-8c409b9a0149	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	Harvester
d35b9780-dcfe-4a37-b352-87dcd3c189b1	23d1d972-91e4-4bb1-a69d-fd78bc56e666	Tractor B 1786265623397
\.


--
-- Data for Name: machines; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.machines (id, company_id, machine_type_id, registration_number, brand, model, purchase_year, fuel_type, status, hour_meter_reading, insurance_number, insurance_expiry_date, assigned_driver_id, next_service_due_hours, last_service_date, last_service_hour_meter, photo_url, is_active, created_at, updated_at) FROM stdin;
b28aa61a-9544-4f6d-b733-7bd450ab0e53	c329669f-35fe-4787-84c9-902251b14695	81be83cb-e309-4fec-bf5c-1302681d2a80	MH-12-8335	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:33:48.933	2026-08-08 18:33:48.933
3dda4e19-eccc-440e-be10-2a2bcc0b8f73	e9c09207-6fea-46d5-8f07-7464472a519a	d8815999-946d-403e-8b42-f0ac180185cf	REG2-1786214883825	\N	\N	\N	DIESEL	WORKING	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:48:04.621	2026-08-08 18:48:04.621
7cffb5ba-c738-4d32-8afc-dde5c24eac52	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	cd27c797-af9c-4683-94c9-1c965bfdb09a	MH-12-3112	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:48:19.188	2026-08-08 18:48:19.188
b4634256-8789-4db0-88c3-0042c94986f7	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	358fbbe6-3752-43ac-a53d-05edfe827da6	MH-12-4599	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 19:32:43.824	2026-08-08 19:32:43.824
a9754ce6-cf7e-4f94-bfde-c900853d603a	3968e65b-4204-432c-ad93-26a831a79d3e	ce534158-576f-4410-b368-717e8168a02c	MH-12-9386	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 19:38:59.207	2026-08-08 19:38:59.207
0a4e2a0a-aac9-4440-929a-40c8ca4c1c6b	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	e4de6564-2250-47a0-ae25-73f18f1c1a85	KA-01-BETA-6832	\N	John Deere B	\N	DIESEL	AVAILABLE	0.00	\N	\N	2f55981e-cc66-41ed-ba86-57d45899988b	\N	\N	\N	\N	t	2026-08-08 18:05:07.322	2026-08-08 18:05:07.322
8bc65fdb-4ab3-4edf-ada9-0601c295727f	a6565866-d95e-4c4c-a2eb-76f3171c2907	bea1a6ca-e72f-4c3e-a198-26851caaf300	KA-01-BETA-7057	\N	John Deere B	\N	DIESEL	AVAILABLE	0.00	\N	\N	affa378c-57a7-429d-8d2b-a68cdcf354ce	\N	\N	\N	\N	t	2026-08-08 18:05:17.496	2026-08-08 18:05:17.496
b992842f-5fa7-41a0-9a1c-5d933d0c6b8a	2fc53fa9-07fd-4172-af37-6a1034df9ecb	432bfd6d-f171-46d9-acca-15b465c83334	KA-01-BETA-1132	\N	John Deere B	\N	DIESEL	AVAILABLE	0.00	\N	\N	026b9227-d949-411b-b645-470004e4ffbf	\N	\N	\N	\N	t	2026-08-08 18:05:31.582	2026-08-08 18:05:31.582
e3cd9c96-272a-4b49-80cc-878dd0d59317	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	614232ec-15c0-490c-9bed-787a491fd3ba	MH-12-2400	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 19:41:57.972	2026-08-08 19:41:57.972
b61808f9-6b2e-4f80-8dd3-11909e2c884d	ecbba26c-b8ee-4455-a09e-86fab13778df	d1e38e81-4b94-4bbb-8ad7-083e3b7e352e	MH-12-6971	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 20:04:26.055	2026-08-08 20:04:26.055
2c1f0e64-573c-4071-80d7-8d3cb2690556	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-12-3754	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:14:51.939	2026-08-08 18:14:51.939
6484d177-f18c-4e23-9f01-06985cda7644	a7ed8578-e3b6-4aec-91b1-214d09748c0e	622f8b30-4b2b-4c5f-8615-446e540aac86	MH-12-2730	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:14:58.603	2026-08-08 18:14:58.603
2318341c-bfbf-4505-84b8-e2cf08f239b2	b51f455a-feb6-445f-8b08-8624162dc98b	fe5ea775-07a3-4d50-9ac2-fb4df3ec9367	MH-12-6952	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:15:07.511	2026-08-08 18:15:07.511
47b77082-85f7-4076-a807-e46743b14d1a	3b4fa961-b987-4207-bade-425969e8e1a5	26b4cb6f-90b2-40ea-9f73-0c37b16f7acc	MH-12-9211	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:15:15.608	2026-08-08 18:15:15.608
142de1ae-b2d7-4726-a644-5f49d04e69c4	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	36b6bc06-e0b7-4e8a-a4a5-ae0bb77137cd	MH-12-1767	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 20:53:03.392	2026-08-08 20:53:03.392
b3f6b08f-7ff7-474a-b3f4-522fa59620de	40511429-f937-4f0f-8a0a-6869154b7144	8dc419dc-6459-41a7-a429-5c95d3eb9191	OD02AB1234	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 05:23:27.077	2026-08-09 05:23:27.077
12c434d2-693c-4014-b3c0-3232368d4770	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-972392-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:32.397	2026-08-09 05:39:32.397
6b4e0a0a-137d-4dde-b0ee-3e42e4783eb3	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-972404-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:32.405	2026-08-09 05:39:32.405
dfabea01-ad4b-48f9-8916-f19cbd6c5176	023866d9-236a-41cc-a36f-b9e516720f54	fef17524-944f-4c81-9e4b-78c97f807ddf	MH-12-4727	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:15:42.897	2026-08-08 18:15:42.897
b7ee10bb-6bf5-4d49-9f41-7a9ff007a37b	024b72fd-44b2-4f38-96c1-78b156fa58c2	3e0a87cd-f855-4aad-aab6-2601816c431f	MH-12-1816	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:22:33.42	2026-08-08 18:22:33.42
000dbdaa-c151-4595-b9b8-ef51ed4bd5b8	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-972422-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:39:32.425	2026-08-09 05:39:32.425
de20cb04-f02d-4d1e-a1d8-886f5d2ec649	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-972430-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:39:32.432	2026-08-09 05:39:32.432
c23f3c99-2ccf-4b2c-9d49-4f3f639ca8d4	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-984955-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:44.956	2026-08-09 05:39:44.956
4d3bd6ff-d190-40c2-a439-0173ba1db673	f33c8ba7-f382-4217-90cf-d9d133632537	ec404f04-059e-4232-8d2c-f24733eb4aec	MH-12-4974	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-08 18:23:51.686	2026-08-08 18:23:51.686
5d737822-4ab1-4646-ae85-db787d53dae3	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-984968-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:44.969	2026-08-09 05:39:44.969
b157a0d8-8f28-4e4a-8a3d-56cb237a2f52	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-984990-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:39:44.995	2026-08-09 05:39:44.995
4cf10d59-a027-4486-af14-1c2458570797	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-985004-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:39:45.006	2026-08-09 05:39:45.006
7b4dbb4c-d5eb-4692-8ec2-414b96581add	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-991091-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:51.093	2026-08-09 05:39:51.093
4c17a537-67fc-4305-8c1e-d84f8b50d2a7	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-991103-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:51.105	2026-08-09 05:39:51.105
6f62a98d-ce14-43d0-80c3-85f23ad90bb4	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-991123-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:39:51.125	2026-08-09 05:39:51.125
e65fc476-fb3d-4d67-80d6-03eae0fa1201	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-991131-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:39:51.134	2026-08-09 05:39:51.134
46ad9e44-9001-4a03-8b8b-e9136f332d3e	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-996996-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:56.997	2026-08-09 05:39:56.997
763f32a5-7c7d-44a2-bb69-c34f7057298a	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-997002-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:39:57.003	2026-08-09 05:39:57.003
9046ae80-5cf4-46f0-8896-f0a3bca3da2a	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-997035-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:39:57.038	2026-08-09 05:39:57.038
70c66b48-07e5-41e7-9061-2ab37adc6d25	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-997046-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:39:57.048	2026-08-09 05:39:57.048
a7948034-0b85-47e6-aa4c-e91964c62457	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-004935-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:04.941	2026-08-09 05:40:04.941
d46eac62-ec22-4dee-8e82-488bafb250ed	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-004957-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:04.958	2026-08-09 05:40:04.958
f27d9036-76ae-4967-9b14-558addb25658	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-004992-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:40:05	2026-08-09 05:40:05
0c461750-80a3-4fe2-b47f-90ea4450b604	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-005016-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:40:05.018	2026-08-09 05:40:05.018
b94759ac-c1b4-4846-82ac-9ad0611f51ef	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-015270-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:15.271	2026-08-09 05:40:15.271
ab29f259-2ea3-4e18-9c90-86e0e0cdee0f	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-015279-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:15.281	2026-08-09 05:40:15.281
06dc9ec6-7725-4698-8b79-f5006862c3ba	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-015298-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:40:15.3	2026-08-09 05:40:15.3
23fb8411-6ae1-4b21-b757-4e1e41aac541	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-015307-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:40:15.308	2026-08-09 05:40:15.308
41629117-a351-4d4d-a340-e67c4ef2995e	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-034306-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:34.308	2026-08-09 05:40:34.308
30610217-cf9e-43ab-88d3-dc7631804204	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-034316-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:34.318	2026-08-09 05:40:34.318
8cffe5d4-fcc9-4650-81bb-b19b22e5395e	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-034338-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:40:34.342	2026-08-09 05:40:34.342
19d589d9-ad01-417b-ba5e-cb4818a7e5c7	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-034349-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:40:34.35	2026-08-09 05:40:34.35
b3b1a599-c7e3-4795-ac3b-9b0ec89478af	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-046577-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:46.578	2026-08-09 05:40:46.578
201b975c-06bf-4180-a8aa-04430f2d01f3	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-046583-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:46.584	2026-08-09 05:40:46.584
a14d3148-da45-4f0e-9ecd-b635eb03cb84	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-046601-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:40:46.602	2026-08-09 05:40:46.602
3507a9c4-2609-4219-8f49-5969dcef1170	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-046610-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:40:46.611	2026-08-09 05:40:46.611
ddf24861-df1a-40ce-8cbd-f8971788235e	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-053112-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:53.113	2026-08-09 05:40:53.113
5f6a8d23-fffa-42de-95a5-b8e921c61f80	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-053118-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:40:53.119	2026-08-09 05:40:53.119
20c4ff3e-eef2-4aa4-af4d-b1b615ec1d76	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-053150-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:40:53.155	2026-08-09 05:40:53.155
895a6c4c-75d1-4b06-b3c4-2e50c3ff799f	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-053163-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:40:53.164	2026-08-09 05:40:53.164
df9d9af3-48bd-4dcb-a4c7-ad0ae5996a14	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-061062-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:41:01.064	2026-08-09 05:41:01.064
c13dbadf-fd9d-47e8-a68b-66c861529282	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-061073-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:41:01.074	2026-08-09 05:41:01.074
eff1ce5e-c15e-42b2-827a-9671fd901f8d	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-061099-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:41:01.104	2026-08-09 05:41:01.104
ed2014c3-53e6-4de2-92fc-10a516b8de6f	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-061111-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:41:01.112	2026-08-09 05:41:01.112
aeed00f6-2da0-4e2d-a7ec-7abd7d5e9df2	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-075184-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:41:15.185	2026-08-09 05:41:15.185
cde247a3-2b25-4f10-97ea-278f57335ad3	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-075190-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:41:15.191	2026-08-09 05:41:15.191
c0f22d70-951d-44b6-82bf-4467fe214b05	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-075215-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:41:15.217	2026-08-09 05:41:15.217
93d742b3-ec0f-4766-b68e-b460ac1d8b2b	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-075226-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:41:15.228	2026-08-09 05:41:15.228
e4e64b4d-83e1-4fb6-af76-9476923ecc15	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-084273-N	\N	\N	\N	DIESEL	AVAILABLE	100.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:41:24.274	2026-08-09 05:41:24.274
8d3c5e36-5f0e-4167-8354-01d900c54c8a	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	MH-084281-A	\N	\N	\N	DIESEL	AVAILABLE	180.00	\N	\N	\N	200.00	\N	\N	\N	t	2026-08-09 05:41:24.282	2026-08-09 05:41:24.282
1264c0c6-a590-422d-981f-cef717acd86c	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-084305-N	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-09-18	\N	\N	\N	\N	\N	t	2026-08-09 05:41:24.308	2026-08-09 05:41:24.308
7183457f-02b0-4a47-9246-a5292b96584d	c331e53c-fe17-49c2-97f1-9466a87bbe42	b5e22862-e4b5-4cae-a866-11f59cea2a1d	INS-084313-A	\N	\N	\N	DIESEL	AVAILABLE	50.00	\N	2026-08-24	\N	\N	\N	\N	\N	t	2026-08-09 05:41:24.316	2026-08-09 05:41:24.316
fc9d0cf9-747b-4b68-87fc-8e2fc4972645	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	2bdc6703-2f57-4fd9-a09f-104fa01ef9fc	MH-12-2720	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 05:57:15.126	2026-08-09 05:57:15.126
65aa4462-0a46-4bc5-aa07-bf538b853620	0757faaa-e55d-4863-9e88-c738651afa4c	2181dcb6-5993-4e78-93d1-0ee20e51e322	MH-12-2064	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 09:06:25.878	2026-08-09 09:06:25.878
ad9d7815-3d41-44cc-847f-3b2a7628b50b	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	a679395a-dbe5-40c1-9950-60d141136d66	MH-12-6101	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 09:10:27.573	2026-08-09 09:10:27.573
e6449a5d-c8d3-45a3-8b69-5b58a620f766	d8d7190c-b0f9-42e6-a510-8a401b035039	552cd3c6-382f-4b84-914c-d082c1a2b697	OD-02-AT-4321	Mahindra	575 DI	2022	DIESEL	AVAILABLE	480.00	INS-99887766	2026-08-19	2db11df0-7514-4376-bc72-9b76a2b32bce	500.00	\N	\N	\N	t	2026-08-09 06:00:22.465	2026-08-09 06:00:22.465
a23d99b5-8b66-40fc-bf2c-ba585333b551	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	e7e48a6d-bda3-4a26-8485-f5cf0e583dc4	OD-02-AT-4321	Mahindra	575 DI	2022	DIESEL	AVAILABLE	480.00	INS-99887766	2026-08-19	d51f987d-b94e-4656-a338-b7f4d8194e8e	500.00	\N	\N	\N	t	2026-08-09 06:00:29.78	2026-08-09 06:00:29.78
244e2f3a-d41d-476b-97be-5f507048c9c3	7a92e240-df0b-4c44-8bba-bd7574ae788b	859ae9e4-1f01-4a37-9d99-129177925ef8	OD-02-AT-4321	Mahindra	575 DI	2022	DIESEL	AVAILABLE	480.00	INS-99887766	2026-08-19	533ebebc-3805-4cca-bbe4-514d18f289b3	500.00	\N	\N	\N	t	2026-08-09 06:00:44.987	2026-08-09 06:00:44.987
c5cb5d71-cb32-42b5-a2ac-c48b8c845f7e	8951aa6b-476b-46b7-b12b-de1998c8bbf7	37413664-f56a-4fa5-91ef-4f182e6e1b53	OD-02-AT-4321	Mahindra	575 DI	2022	DIESEL	AVAILABLE	480.00	INS-99887766	2026-08-19	60e3d45f-1001-4e82-b97b-9d038d9e2a11	500.00	\N	\N	\N	t	2026-08-09 06:00:59.368	2026-08-09 06:00:59.368
ece6db08-b21e-4738-bc77-9800dd0c5c5d	d563fb11-8e19-4079-a843-4d579ba681ee	e31fb1a9-3309-4983-b7e6-01a81455f3be	OD-02-AT-4321	Mahindra	575 DI	2022	DIESEL	AVAILABLE	480.00	INS-99887766	2026-08-19	75a463db-95e9-413c-8976-8a23150e00b7	500.00	\N	\N	\N	t	2026-08-09 06:01:10.634	2026-08-09 06:01:10.634
27540f0a-20ac-4e1b-bd37-c1583db03028	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	1e830767-9a8d-429a-9b73-f698ef5b4f86	MH-12-3011	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 06:01:25.019	2026-08-09 06:01:25.019
438e3ded-9440-4f7d-b87e-e5c7ce0b939a	6571c3c9-9c94-4b02-ac20-829a9af731b6	5177cb50-af06-4baa-9628-00e8678894ba	MH-12-8760	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 08:45:02.305	2026-08-09 08:45:02.305
5765c74a-7d2f-4443-8abe-2487b4bd6b56	4613e40d-bba4-424a-970e-ffc7836a19e2	70e621d3-acf8-4666-9cfe-0895db066730	MH-12-8350	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 08:47:58.701	2026-08-09 08:47:58.701
c790842b-760d-4cad-b053-8cc6091bb4e9	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	bd210942-7654-4293-99a7-8c409b9a0149	MH-12-7535	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 08:53:41.532	2026-08-09 08:53:41.532
f5024078-737d-4a6e-90e7-2b28964d9722	b3bd9148-5bcf-46c7-aae9-d07d688834ca	b0e9cfa1-6ebd-4258-8ec0-45b5e0feebbe	MH-12-3611	\N	\N	\N	DIESEL	AVAILABLE	0.00	\N	\N	\N	\N	\N	\N	\N	t	2026-08-09 09:03:25.921	2026-08-09 09:03:25.921
\.


--
-- Data for Name: maintenance_records; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.maintenance_records (id, company_id, machine_id, maintenance_schedule_id, service_date, hour_meter_at_service, description, cost, performed_by, created_at) FROM stdin;
\.


--
-- Data for Name: maintenance_schedules; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.maintenance_schedules (id, company_id, machine_id, interval_hours, interval_days, description, is_active) FROM stdin;
caf45276-0e10-4ac0-876d-8dcf74308584	2fc53fa9-07fd-4172-af37-6a1034df9ecb	b992842f-5fa7-41a0-9a1c-5d933d0c6b8a	100.00	\N	Oil filter change	t
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.otp_codes (id, identifier, code_hash, purpose, expires_at, consumed_at, attempt_count, created_at) FROM stdin;
d19c3c52-fee8-4a0e-8491-ecf28ce4e554	reset_owner_1786265631347@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-09 09:08:53.193	2026-08-09 08:53:53.394	0	2026-08-09 08:53:53.195
715be0ad-0b85-4280-8966-db198285c32b	reset_owner_1786266215512@example.com	40df0150a7ef07c6df2a5b51a6e5e8203b9fca0c9f9abfadb1854b954fe1d814	RESET	2026-08-09 09:18:35.727	\N	0	2026-08-09 09:03:35.729
8a0afeca-9da5-4382-9e99-23bff5e5e6a6	reset_owner_1786217543503@example.com	e05fbb2b084a73325a19b0961b4e8138427a057e43fa692f3d771ac77bac6976	RESET	2026-08-08 19:47:23.789	\N	0	2026-08-08 19:32:23.79
de8e30fa-c9c5-4c89-84f9-e64c0d16138e	reset_owner_1786217543503@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-08 19:31:23.809	\N	0	2026-08-08 19:32:23.81
f355708e-1494-41a7-809d-0c1c6bbabd27	reset_owner_1786217543503@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-08 19:47:23.814	2026-08-08 19:32:23.944	0	2026-08-08 19:32:23.815
09209842-21f9-4b9d-a748-88c845cc9a03	reset_owner_1786217931387@example.com	19359206b6f74757a2be91347405710e23b42403ddd3ef97abdc33f874c99bde	RESET	2026-08-08 19:53:51.594	\N	0	2026-08-08 19:38:51.595
66ad2af3-9d37-42b6-85d4-e990cb61d7aa	reset_owner_1786217931387@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-08 19:37:51.612	\N	0	2026-08-08 19:38:51.613
b7b51db4-0fc6-45b7-a0f9-02a09f54980f	reset_owner_1786217931387@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-08 19:53:51.617	2026-08-08 19:38:51.744	0	2026-08-08 19:38:51.618
ddf3d2f3-01d2-431b-9c29-5448a7550177	reset_owner_1786218108542@example.com	30e520d451cfc9870a7a305cb0f357ae438bee1c136e7c889d8fbcdc967bd7f3	RESET	2026-08-08 19:56:48.785	\N	0	2026-08-08 19:41:48.787
3720e863-7a40-4aac-8693-fcd79b8f3cbb	reset_owner_1786218108542@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-08 19:40:49.963	\N	0	2026-08-08 19:41:49.964
736b04c1-3a2c-49e5-ab52-28194cac694e	reset_owner_1786218108542@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-08 19:56:49.968	2026-08-08 19:41:50.137	0	2026-08-08 19:41:49.969
990ef7d7-9137-430f-958d-13f6e1cd1c63	reset_owner_1786219453681@example.com	2d468ab656eba8d706aa1aa0063f3bb2cd89d52dfe9e4907a912bbea2b8bee09	RESET	2026-08-08 20:19:13.912	\N	0	2026-08-08 20:04:13.914
6423d46b-f136-4122-b977-7f387666749c	reset_owner_1786219453681@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-08 20:03:15.45	\N	0	2026-08-08 20:04:15.451
b53009f9-7bed-43c9-94cd-1d7e19df7f3d	reset_owner_1786219453681@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-08 20:19:15.454	2026-08-08 20:04:15.577	0	2026-08-08 20:04:15.455
1fd344ea-ac44-4b4a-befc-441e6af4ae92	reset_owner_1786222370490@example.com	a7bc3f0aa6e11b5534c65621980d897332a50f93dd66f8d92a3ffb48c3c72066	RESET	2026-08-08 21:07:50.722	\N	0	2026-08-08 20:52:50.723
e2f21de5-521c-447a-9d35-3b4e1e7cd07e	reset_owner_1786222370490@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-08 20:51:52.339	\N	0	2026-08-08 20:52:52.34
b03c8d34-1186-4c82-a51d-399436f6a622	reset_owner_1786222370490@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-08 21:07:52.342	2026-08-08 20:52:52.46	0	2026-08-08 20:52:52.343
699f0752-cbd4-4c84-8e03-a9a474aa35e1	reset_owner_1786255052458@example.com	32e7af58339a66047d0368a006d5eee471b9ef6549d264d2501c4b137361acbd	RESET	2026-08-09 06:12:32.769	\N	0	2026-08-09 05:57:32.771
3b38b49f-7fc8-436b-8770-8473bc40fbbb	reset_owner_1786255052458@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-09 05:56:34.377	\N	0	2026-08-09 05:57:34.378
5a6f3b8e-f472-417b-a3f8-6ea5ec6f1d67	reset_owner_1786255052458@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-09 06:12:34.382	2026-08-09 05:57:34.607	0	2026-08-09 05:57:34.383
9e4ecb65-3c0f-4f23-b0e8-248a2ffc818a	reset_owner_1786255301687@example.com	c12058c6a8c1cbe559167a07501a5bf63c56d6a12802eabbc89df205c65e1bb6	RESET	2026-08-09 06:16:41.921	\N	0	2026-08-09 06:01:41.923
fdcf3378-52ec-4956-a4ff-9de58c4d5170	reset_owner_1786255301687@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-09 06:00:43.554	\N	0	2026-08-09 06:01:43.556
9fe4fbc7-d23a-4754-8328-659f6dcc4205	reset_owner_1786255301687@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-09 06:16:43.561	2026-08-09 06:01:43.725	0	2026-08-09 06:01:43.562
d1bc7f07-dae6-40e9-a4d0-94c3d6ab5302	Dasmanoranjan798@gmail.com	$2a$10$ZouMybHv2P7sZ0pTCIHj5u.f1O/Ctc4nXIu3mIuKJT3cVpHS7pcb2	LOGIN	2026-08-09 06:42:20.437	\N	0	2026-08-09 06:37:20.438
39ab1600-be7f-48ab-83eb-febb1efed5e3	reset_owner_1786265295542@example.com	2f16943015c8d885f99ccf2d77dca3fb6b93ddf3df1e0b14d053673c00b6e03e	RESET	2026-08-09 09:03:15.754	\N	0	2026-08-09 08:48:15.756
e0885f76-c04c-404e-9d46-ac75507fcc48	reset_owner_1786265295542@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-09 08:47:17.351	\N	0	2026-08-09 08:48:17.352
b9658ab9-a847-4bf1-866b-5d9d355fb04f	reset_owner_1786265295542@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-09 09:03:17.357	2026-08-09 08:48:17.519	0	2026-08-09 08:48:17.36
d0622562-d3b7-45f5-b54e-f77b2d913ad0	reset_owner_1786265631347@example.com	fc98e93ef59681e2f9535e4fca95bc46003acac34880cebc2815c787def9cc35	RESET	2026-08-09 09:08:51.642	\N	0	2026-08-09 08:53:51.644
2e145f62-f7cb-427d-8a49-5099325208a4	reset_owner_1786265631347@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-09 08:52:53.185	\N	0	2026-08-09 08:53:53.186
bf36b6bb-74e2-436c-ac79-6a63724fd2b1	reset_owner_1786266215512@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-09 09:02:37.247	\N	0	2026-08-09 09:03:37.248
5bc8647d-ed69-41b0-8a74-871ff9c35a78	reset_owner_1786266215512@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-09 09:18:37.252	2026-08-09 09:03:37.367	0	2026-08-09 09:03:37.253
a06d6af1-cbde-4421-9a4b-7ac5bd633717	reset_owner_1786266395729@example.com	43e6f189ed2c7018352260da3f89beb95448535db1d6a81277a3c665be230834	RESET	2026-08-09 09:21:35.949	\N	0	2026-08-09 09:06:35.951
3b2f942c-744c-453c-bfdf-fda92bf56cd5	reset_owner_1786266395729@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-09 09:05:37.502	\N	0	2026-08-09 09:06:37.504
a6b90cbc-7b9b-4f23-a0be-34dcf789c418	reset_owner_1786266395729@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-09 09:21:37.509	2026-08-09 09:06:37.643	0	2026-08-09 09:06:37.51
1b0b9367-8e7a-44da-a33c-c8490299ea67	reset_owner_1786266637089@example.com	8bc1a2e285ecfc971d54d353b090ddf39af58064179eb093331701e403f2d815	RESET	2026-08-09 09:25:37.302	\N	0	2026-08-09 09:10:37.304
7bd9dc20-a725-4b31-95cb-b224c11aa06c	reset_owner_1786266637089@example.com	8749f88ce2e0884673053eb29e9f4026d880d27f50824161262cca78d37e24fd	RESET	2026-08-09 09:09:38.828	\N	0	2026-08-09 09:10:38.83
ab2a9e2f-4ecc-41f0-9216-40522f0aa698	reset_owner_1786266637089@example.com	a354fac27874238496514eb33604cadbe95ab0f9ac6baf326bb029f753491bf1	RESET	2026-08-09 09:25:38.837	2026-08-09 09:10:38.988	0	2026-08-09 09:10:38.839
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.payments (id, company_id, invoice_id, amount, payment_method, reference_number, received_by, received_at, notes, created_at) FROM stdin;
ee7b287a-1530-4489-9b10-77fdc41bd1bd	8951aa6b-476b-46b7-b12b-de1998c8bbf7	18a9a419-9dce-4f09-bde7-ceb8130b684d	1500.00	UPI	UPI/987654/001	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.745	Advance cash paid via UPI	2026-08-09 06:00:59.745
0399ddf6-ddcb-49fd-ba10-0715cdc5b1e7	8951aa6b-476b-46b7-b12b-de1998c8bbf7	18a9a419-9dce-4f09-bde7-ceb8130b684d	2500.00	CASH	\N	5917a103-06b6-41b4-81bd-5ef527f43954	2026-08-09 06:00:59.774	Remaining balance paid in cash	2026-08-09 06:00:59.774
c208ef79-dd7c-4ae6-a910-0139da998dc0	d563fb11-8e19-4079-a843-4d579ba681ee	cb3f061f-1b9d-4056-a4e4-437696ca40f4	1500.00	UPI	UPI/987654/001	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.041	Advance cash paid via UPI	2026-08-09 06:01:11.041
09a637e4-a0f3-429d-ba9e-298d359ca9c6	d563fb11-8e19-4079-a843-4d579ba681ee	cb3f061f-1b9d-4056-a4e4-437696ca40f4	2500.00	CASH	\N	808c6af1-8955-4803-8580-fa136df6aad2	2026-08-09 06:01:11.079	Remaining balance paid in cash	2026-08-09 06:01:11.079
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.permissions (id, key, description) FROM stdin;
c97b29a7-7764-4893-9de9-18e3fee94462	dashboard.view	View dashboard metrics
9167fcc1-c0d2-4a66-8fcf-bccb3bceae75	booking.create	Create a booking
b04b6a7e-76a5-4f52-9ece-a163704efa38	booking.edit	Edit a booking
51234121-4440-4eea-8ba9-9a181f0b39a4	booking.delete	Cancel/delete a booking
b4cd517d-cf3b-4001-bc2d-7109a171dd59	machine.assign	Assign a machine to a booking
c651765c-ad9d-43c2-853a-cc3e595b2713	driver.assign	Assign a driver to a booking
156357b5-b39f-4940-85f4-6b58da5ee830	job.update_status	Record job execution progress
52552512-4b33-47f3-98f5-1f4e60d3a8b1	payment.receive	Record a payment against an invoice
1f2e2ce8-8798-42f2-bec0-744e14bca51c	report.generate	View/generate reports
44e95148-7ff7-4a12-a28f-2e49be00bb98	user.manage	Create/edit/deactivate users
83c3b6ae-b146-4ed1-8154-3c13d651ad26	settings.manage	Change company settings
e70ff4ad-1601-4af6-9d46-c635a9118437	data.export	Export data
26c9669f-bf10-49df-bab7-c7d222abc082	village.manage	Create/edit/delete villages
b5dd85d2-caea-4053-95fe-a8a813bfa293	machine_type.manage	Create/edit/delete machine types
45fbacad-1b42-4318-b7c5-01353f3466b7	machine.manage	Create/edit/delete machines
7fd214da-d40e-4f05-8d64-f23b9644c0af	employee.manage	Create/edit/delete employee records
aa42f5b6-6f12-4769-8c6f-5c4363002a5c	driver.manage	Create/edit/delete driver profiles
8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1	customer.manage	Create/edit/delete customer records
f8bf3446-59d2-479b-a773-44bb2f17f50b	operations.view	Browse operational lists
\.


--
-- Data for Name: pricing_methods; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.pricing_methods (id, company_id, key, label, unit, is_active) FROM stdin;
2682eabd-fa60-4914-9b85-668ce62a338e	c331e53c-fe17-49c2-97f1-9466a87bbe42	per_hour	Per Hour	hour	t
8344143e-08f9-4d04-907e-72c4ca67884b	a7ed8578-e3b6-4aec-91b1-214d09748c0e	per_hour	Per Hour	hour	t
fbb7dff9-c489-4bdc-8a78-95f954fefcb6	b51f455a-feb6-445f-8b08-8624162dc98b	per_hour	Per Hour	hour	t
dafacdd2-05f1-4125-8b1c-322fbfb08bb4	3b4fa961-b987-4207-bade-425969e8e1a5	per_hour	Per Hour	hour	t
ce4962ef-f3d3-4e7e-aedb-3697d4e2da07	99690b52-8af1-4813-b8a1-4af071a81549	per_hour	Per Hour	hour	t
c9da9b1e-f2a3-4f6c-b503-5fc96e1b0c9f	99690b52-8af1-4813-b8a1-4af071a81549	per_minute	Per Minute	minute	t
bbb9828a-c7b0-4b42-bf67-2120952739de	99690b52-8af1-4813-b8a1-4af071a81549	per_acre	Per Acre	acre	t
c67d1a8f-b398-42aa-b96f-8fbf3ce09fad	99690b52-8af1-4813-b8a1-4af071a81549	per_job	Per Job (Fixed)	\N	t
d18a50e3-ac97-403b-bc06-37a29c4c1305	99690b52-8af1-4813-b8a1-4af071a81549	minimum_charge	Minimum Charge	\N	t
8131779e-d94e-4833-8478-ebdbd65ebf3b	99690b52-8af1-4813-b8a1-4af071a81549	custom	Custom Rate	\N	t
cff1a3f5-00b8-4e43-ad02-aceb76a40698	1a1ead59-2b11-4f2a-85e5-71c30252fbab	per_hour	Per Hour	hour	t
ef0336bf-94ba-4cb7-a67e-132f1301e447	1a1ead59-2b11-4f2a-85e5-71c30252fbab	per_minute	Per Minute	minute	t
8c9dec36-1c1e-4bbb-9a62-b497f425ee7c	1a1ead59-2b11-4f2a-85e5-71c30252fbab	per_acre	Per Acre	acre	t
39575b5d-e971-4b51-8da2-766c01629e66	1a1ead59-2b11-4f2a-85e5-71c30252fbab	per_job	Per Job (Fixed)	\N	t
5a94e71b-b405-4d41-a13f-38d1b0e71960	1a1ead59-2b11-4f2a-85e5-71c30252fbab	minimum_charge	Minimum Charge	\N	t
a85ed37e-0cc0-42bc-a680-0a6481c7bd7a	1a1ead59-2b11-4f2a-85e5-71c30252fbab	custom	Custom Rate	\N	t
ef5241ea-291d-4d7e-8aec-a61e81fdc888	98052597-43cc-4b9a-a12b-72260f7e39ff	per_hour	Per Hour	hour	t
7d392d99-bcb8-4caa-bbcf-cacf3f4c38aa	98052597-43cc-4b9a-a12b-72260f7e39ff	per_minute	Per Minute	minute	t
7071a6c2-93a7-4af7-8757-0a69daca70ac	98052597-43cc-4b9a-a12b-72260f7e39ff	per_acre	Per Acre	acre	t
153c430e-63a2-4db3-88d7-6513a6de7376	98052597-43cc-4b9a-a12b-72260f7e39ff	per_job	Per Job (Fixed)	\N	t
f59c0bef-9ea9-4d0d-a631-c111421d4365	98052597-43cc-4b9a-a12b-72260f7e39ff	minimum_charge	Minimum Charge	\N	t
fc856f4d-78d6-4704-9376-9cb0df62a9f9	98052597-43cc-4b9a-a12b-72260f7e39ff	custom	Custom Rate	\N	t
1761fe27-d56c-4c58-a69a-744a07ac35e5	c40dd20c-a216-4766-8dd3-db89037b4bc4	per_hour	Per Hour	hour	t
65da18bd-f685-463d-8edd-8073c049be3c	c40dd20c-a216-4766-8dd3-db89037b4bc4	per_minute	Per Minute	minute	t
6395adbb-1a93-4b78-8ffb-b2268ed41493	c40dd20c-a216-4766-8dd3-db89037b4bc4	per_acre	Per Acre	acre	t
0bfa5627-4217-47f8-b4e6-843929ea8a4e	c40dd20c-a216-4766-8dd3-db89037b4bc4	per_job	Per Job (Fixed)	\N	t
f7d9d955-0d7f-4e47-b24d-f1f753ae63ee	c40dd20c-a216-4766-8dd3-db89037b4bc4	minimum_charge	Minimum Charge	\N	t
48e2671b-d8c7-4868-95eb-09ab79b62153	c40dd20c-a216-4766-8dd3-db89037b4bc4	custom	Custom Rate	\N	t
41cb4c75-41b2-4ffc-b343-70432b370369	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	per_hour	Per Hour	hour	t
3b9cb9a1-f5b5-4b48-a13b-63365fef1f01	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	per_minute	Per Minute	minute	t
5eb9baa5-94e5-434c-8e6c-6c68d8c7ba66	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	per_acre	Per Acre	acre	t
35852368-ddff-4dc2-b376-2664cc339323	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	per_job	Per Job (Fixed)	\N	t
e25c6e9e-2b7c-44c3-9283-d64d29299c25	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	minimum_charge	Minimum Charge	\N	t
5f301d81-08d3-4017-a965-561406402aad	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	custom	Custom Rate	\N	t
d9d1ca7c-3462-4706-b61d-ad5248814b09	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	per_hour	Per Hour	hour	t
386bc6ac-c147-453c-93a4-687aa0585bb3	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	per_minute	Per Minute	minute	t
9aeba653-9959-475d-a4ee-00a3a77d91b6	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	per_acre	Per Acre	acre	t
a6e84371-f765-4f35-9ce2-4c4e208d388f	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	per_job	Per Job (Fixed)	\N	t
7c9c8464-6ac4-4ba6-98d4-ebe1c312fb12	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	minimum_charge	Minimum Charge	\N	t
4321428f-1e0a-4621-aaed-c876c74b983a	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	custom	Custom Rate	\N	t
14cc2635-6a0c-46c5-8657-4715eda328ef	3e8490bb-07a1-497f-8b5b-8f2e470cf284	per_hour	Per Hour	hour	t
3ac46c64-36b0-43c0-a40f-78be70648de8	3e8490bb-07a1-497f-8b5b-8f2e470cf284	per_minute	Per Minute	minute	t
0e439a9b-3d99-4c05-9cf3-e6a49b903b68	3e8490bb-07a1-497f-8b5b-8f2e470cf284	per_acre	Per Acre	acre	t
1b801c1f-e13a-4690-befd-0ea183cf0bea	3e8490bb-07a1-497f-8b5b-8f2e470cf284	per_job	Per Job (Fixed)	\N	t
3532dd25-af7d-4d59-8dd4-4205b563623d	3e8490bb-07a1-497f-8b5b-8f2e470cf284	minimum_charge	Minimum Charge	\N	t
34eefe32-2cdb-4b89-aa4f-52db7a084415	3e8490bb-07a1-497f-8b5b-8f2e470cf284	custom	Custom Rate	\N	t
0e3d37af-600e-46d8-b9d8-9cc8898b8b37	a6565866-d95e-4c4c-a2eb-76f3171c2907	per_hour	Per Hour	hour	t
fa26a95e-b9fd-4564-bb3d-7cf7a7f4132f	a6565866-d95e-4c4c-a2eb-76f3171c2907	per_minute	Per Minute	minute	t
f75f267a-f633-459f-b885-b7f3ff4fd924	a6565866-d95e-4c4c-a2eb-76f3171c2907	per_acre	Per Acre	acre	t
0d89bbf6-a57a-427a-a3fe-2d7d939bdcc7	a6565866-d95e-4c4c-a2eb-76f3171c2907	per_job	Per Job (Fixed)	\N	t
4967feda-774d-4b67-b0ef-bb4e74d8cd84	a6565866-d95e-4c4c-a2eb-76f3171c2907	minimum_charge	Minimum Charge	\N	t
9ec61b20-fa4c-4498-8836-e08f76f52fc5	a6565866-d95e-4c4c-a2eb-76f3171c2907	custom	Custom Rate	\N	t
2d173e34-6472-477b-922e-b40457df382c	74dcfe64-85b0-4051-9c2c-8292caf839ea	per_hour	Per Hour	hour	t
556034b4-4804-4d5d-a1b3-c9cd10bfd5c9	74dcfe64-85b0-4051-9c2c-8292caf839ea	per_minute	Per Minute	minute	t
81dd5e28-859f-4391-9fe5-8e8febae8d30	74dcfe64-85b0-4051-9c2c-8292caf839ea	per_acre	Per Acre	acre	t
43f6d053-9804-4345-8b7d-8af77a36361a	74dcfe64-85b0-4051-9c2c-8292caf839ea	per_job	Per Job (Fixed)	\N	t
c30f9fcb-de8c-4657-aae2-7b081779a321	74dcfe64-85b0-4051-9c2c-8292caf839ea	minimum_charge	Minimum Charge	\N	t
bb53fd9f-4289-41b5-b758-8fc483e7592d	74dcfe64-85b0-4051-9c2c-8292caf839ea	custom	Custom Rate	\N	t
6912c958-19fa-4474-9872-9cc6c375e26a	2fc53fa9-07fd-4172-af37-6a1034df9ecb	per_hour	Per Hour	hour	t
6280c5f2-9c0e-417f-a7a0-5b1f585e41ef	2fc53fa9-07fd-4172-af37-6a1034df9ecb	per_minute	Per Minute	minute	t
1d5280bd-4851-4bf9-95e0-75afae4c985d	2fc53fa9-07fd-4172-af37-6a1034df9ecb	per_acre	Per Acre	acre	t
77b5bfb6-8bbc-46a2-bf6a-c82fa141ae2a	2fc53fa9-07fd-4172-af37-6a1034df9ecb	per_job	Per Job (Fixed)	\N	t
3b151f57-007d-40c2-9435-f6007ecdc68e	2fc53fa9-07fd-4172-af37-6a1034df9ecb	minimum_charge	Minimum Charge	\N	t
2a3685ac-cf29-44e5-af02-a82748bac8ac	2fc53fa9-07fd-4172-af37-6a1034df9ecb	custom	Custom Rate	\N	t
906ed506-633e-4255-bb6d-056076177176	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	per_hour	Per Hour	hour	t
995f2e6d-2dfc-49c5-b0c2-7873f8d2fcce	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	per_hour	Per Hour	hour	t
63725161-7dae-4578-923c-f93a3cd09943	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	per_hour	Per Hour	hour	t
f32fdf70-d97e-4b46-8560-1e87299901f9	29c82d91-d80e-4358-a180-dd5df8cae889	per_hour	Per Hour	hour	t
22d8f2f5-2a7b-4562-82ab-86ad901b1e0c	29c82d91-d80e-4358-a180-dd5df8cae889	per_minute	Per Minute	minute	t
3e9036fd-11dc-4f51-9bfd-62f0fa0f93fd	29c82d91-d80e-4358-a180-dd5df8cae889	per_acre	Per Acre	acre	t
1743d950-e614-48ed-a744-629212c4e450	29c82d91-d80e-4358-a180-dd5df8cae889	per_job	Per Job (Fixed)	\N	t
7b784b7f-26fc-476e-ac6d-565238506090	29c82d91-d80e-4358-a180-dd5df8cae889	minimum_charge	Minimum Charge	\N	t
10996f44-93bc-4cbc-914b-33d277c49746	29c82d91-d80e-4358-a180-dd5df8cae889	custom	Custom Rate	\N	t
9668fc58-b8cd-4357-baaa-8baf76a9e2fe	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	per_hour	Per Hour	hour	t
e449b153-a6de-49bd-b64a-227a6f5e2011	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	per_hour	Per Hour	hour	t
b8d135df-f817-45d2-8543-fa2e325e48e6	8951aa6b-476b-46b7-b12b-de1998c8bbf7	per_hour	Per Hour	hour	t
1c4683a1-eee1-4dc4-af9b-9dbaed558f27	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	per_hour	Per Hour	hour	t
93e560ce-2ba8-48c5-869b-04bc0a349da8	0757faaa-e55d-4863-9e88-c738651afa4c	per_hour	Per Hour	hour	t
087e5c7f-120b-48f6-a0b3-3b519b5f8eea	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	per_hour	Per Hour	hour	t
54552b35-1113-48c9-8b26-7b7e502b3bae	3968e65b-4204-432c-ad93-26a831a79d3e	per_hour	Per Hour	hour	t
ee7706ee-25d0-4661-a2d2-725908ca6f28	ecbba26c-b8ee-4455-a09e-86fab13778df	per_hour	Per Hour	hour	t
adea2e4d-c414-4489-8246-78ee12d9ae15	023866d9-236a-41cc-a36f-b9e516720f54	per_hour	Per Hour	hour	t
c09ad282-3763-4ecc-92b4-db6e9b5af8fa	024b72fd-44b2-4f38-96c1-78b156fa58c2	per_hour	Per Hour	hour	t
0737046e-404b-409b-8282-79e96ad9a731	40511429-f937-4f0f-8a0a-6869154b7144	per_hour	Per Hour	hour	t
bac3fb00-317e-4c7e-9641-1ea1bc33fea7	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	per_hour	Per Hour	hour	t
a8065539-a74d-4f4d-9d77-43b8f5e2d331	b3bd9148-5bcf-46c7-aae9-d07d688834ca	per_hour	Per Hour	hour	t
fc349e50-fdc6-4ce6-8494-6ff33d920813	d8d7190c-b0f9-42e6-a510-8a401b035039	per_hour	Per Hour	hour	t
21054393-d07e-4f60-84be-75cc324cba5b	7a92e240-df0b-4c44-8bba-bd7574ae788b	per_hour	Per Hour	hour	t
90081924-fe98-4d79-a4a7-e332913137e0	d563fb11-8e19-4079-a843-4d579ba681ee	per_hour	Per Hour	hour	t
e3f4f513-c321-4651-931c-70f743d22fa5	f33c8ba7-f382-4217-90cf-d9d133632537	per_hour	Per Hour	hour	t
7abba147-b4bd-4a6e-a42e-449ee496b74b	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	per_hour	Per Hour	hour	t
5330424f-4e69-4bdf-8336-f1ea1ae0f72e	c329669f-35fe-4787-84c9-902251b14695	per_hour	Per Hour	hour	t
a38697f1-2254-44b5-adf5-4a63ed21c97d	6571c3c9-9c94-4b02-ac20-829a9af731b6	per_hour	Per Hour	hour	t
3586c754-2e84-4638-87f7-2c72c44d4087	4613e40d-bba4-424a-970e-ffc7836a19e2	per_hour	Per Hour	hour	t
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, revoked_at, user_agent, ip_address, created_at) FROM stdin;
fe295e86-021f-4e6b-9045-4e20cfcc337c	a800bba5-52a3-4259-b5cf-4cf943beac89	bf7c363e6677d796d2ddbdd49a3df3128b7bc5f76e5f5bb80a26628964faf0f5	2026-09-08 08:48:01.506	\N	\N	\N	2026-08-09 08:48:01.508
9ff456cf-7609-474f-ae25-e9784ca0f016	0d2a6a28-0e51-4e12-af93-6e9363d345ac	f48b5d3426dacac5c9a9815f85af970995dfc26c132c1f5374fcf15970609662	2026-09-07 11:22:28.31	\N	\N	\N	2026-08-08 11:22:28.311
f35a65c6-884c-4ced-895c-2ba04bb3cae9	8b84b9c2-4955-468b-b628-15d395979415	c3433f831b6582c7b1801cb2158e798ed44743e4b3e6b3008b0c6abfdf208118	2026-09-07 11:22:28.412	\N	\N	\N	2026-08-08 11:22:28.413
6a6111d6-0197-4430-81e7-ae4e59cd7d74	83478eef-2314-446a-bb5c-112a5b6cdc1a	08ee85aa92fa6c7e5b7c9961218ff87eeea8a362498e3c185eeba63404aa22f7	2026-09-07 11:22:28.534	\N	\N	\N	2026-08-08 11:22:28.535
5d91ff75-72b8-4a93-b26a-e2fd4f79a98f	ef799722-fbd6-4054-95df-0d7575ca050e	14dc14b61c7e8797f23268871305552a8fc42b9e06d967638fd9c5b5267cf79a	2026-09-08 08:48:01.859	\N	\N	\N	2026-08-09 08:48:01.86
0afd75e3-5aae-4510-a98b-c249d33e234e	b1dc55b7-db88-404a-ab36-ceed3d7fa209	aca877019f86ec708bcbe9b1ce255575848747320299de530c488070802c2a9d	2026-09-07 12:59:18.334	\N	\N	\N	2026-08-08 12:59:18.336
6bd993fe-9b19-488c-aea9-1837d9583247	1be0e29b-8bcd-4c59-a82b-ca1bd7ac595c	607845a4af7bb16d1a8395b2edb346b363b05705328f02075b6dd078189de71d	2026-09-07 12:59:18.439	\N	\N	\N	2026-08-08 12:59:18.44
1ab998b0-bf75-4b36-b863-8d894ff3d14a	1f1be4bf-9cf7-447e-afd3-4d07dd67dbeb	8f5bf94ea5b897e23d80c538d921f94124ebc4015a455ada2f48f2baf182b429	2026-09-07 12:59:18.559	\N	\N	\N	2026-08-08 12:59:18.56
87910038-063c-49c3-959f-0efef6935029	fdcdafd5-3dbb-4313-b56e-2f1be6a05021	4c9de4cf2cf3a5978b9254027f455d8290e560e44492715563d17a075408bab5	2026-09-07 12:59:25.592	\N	\N	\N	2026-08-08 12:59:25.594
0b049813-f902-44e0-a1e2-5d8394cf938c	1043524c-c719-4b0b-a2ec-50c6f40c2afe	b99a0a5131084bf63a9547342461361f1fbdde70753c2876513e388842dfc7ac	2026-09-07 12:59:25.7	\N	\N	\N	2026-08-08 12:59:25.701
9271a626-f94b-4d18-aa07-df031b73297b	a7428dcc-c14f-4458-b037-f642aac32c37	307ace6a4e2c98cf70b963bad0d1ec619c968f7499de107284dd1cf9c5c9e38e	2026-09-07 12:59:25.824	\N	\N	\N	2026-08-08 12:59:25.825
99f71dfb-16ee-47df-8258-3f1dc9814f91	2717d7c9-e438-4b56-9912-e1b7fa6c13fe	d594be974e99d5a0ccc83d713d52e39987613b4bdf08550bc9893025f81989a8	2026-09-07 12:59:40.488	\N	\N	\N	2026-08-08 12:59:40.49
02533656-e293-4945-9ce6-5f1ce3ae9a03	7af3ee62-fb06-468e-b1b5-50bbe436ef27	d4b56c6ed562198b0780c32e380d9e59b2a47db9c54de62f5b33351d5bcf06b9	2026-09-07 12:59:40.595	\N	\N	\N	2026-08-08 12:59:40.596
99e00c24-5765-4e14-a9c2-5d639c3e03e9	256b445c-9a8b-4ac2-a9b6-32a4140e3a8c	209281bb88d9a788a43989103909871ad2ed4156319c5f64a2a7e6ccb0c5ea1e	2026-09-07 12:59:40.697	\N	\N	\N	2026-08-08 12:59:40.698
6ff6a846-1736-47fd-ba49-f9f7260a98a1	8f192145-abd8-4134-a793-cc334fdc39a3	8ac3c25cd87e21a7d21d9b965ef40514bce993ac1f90bbc280212708c33a7491	2026-09-07 13:00:11.832	\N	\N	\N	2026-08-08 13:00:11.834
4a27daf3-5a81-4c64-8030-2f2ba13bf139	494a5df6-94ed-468e-8a28-07391add83e4	319f3b04e9b17a89cd200770d3eea262a8aed5c501ca2d5f23dcdad8031af1de	2026-09-07 13:00:11.996	\N	\N	\N	2026-08-08 13:00:11.997
c45000a6-42e6-42b0-93fa-403cf08b7192	6f26272f-3e56-40b8-a486-c1975429be90	0ac41a1a5db05f4951f48ccd1f8bb1375dec962313e4f1b48130d00985aacfe9	2026-09-07 13:00:12.192	\N	\N	\N	2026-08-08 13:00:12.193
c45feae8-f6a9-46a7-a632-1d0dc8db64f4	50d522b8-7408-45ff-92d6-94940afce6d5	cc2e122286cced8c2eadb732bc99068ea64eda079d5452829ed0e635dc316646	2026-09-07 13:00:25.104	\N	\N	\N	2026-08-08 13:00:25.106
c1c06bae-7a84-4aec-a27f-f3cab52f30bb	285398bc-25da-468a-a0e4-313e33a05758	48969bbf8f91497898d549da5a20c84946952804f716838ae4c01e6a58d1bd03	2026-09-07 13:00:25.221	\N	\N	\N	2026-08-08 13:00:25.221
2a0442e2-5b37-494b-9fee-0e5106063d28	c694878f-d1df-471d-8b15-c85b96a5dd69	3fcfbf07f5d97c7f5c5c84af3cf0e8c8aaedbd218a180ca091c3ffb058ea3d72	2026-09-07 13:00:25.324	\N	\N	\N	2026-08-08 13:00:25.325
50f0d5ec-219d-42d2-b439-56d9e6f0267e	f52fc1ff-b111-48bc-9607-6956c468e503	2bd003ccbf440fe764bc9c4fd5376a01d36a7dab674d2c6beef4f514d7d00258	2026-09-07 13:00:33.862	\N	\N	\N	2026-08-08 13:00:33.863
6f69d4cc-0ce9-43b0-97ff-139632c9136b	b8beb125-7a83-4630-8d00-29e7fc27135b	7aef66f54b4e6381361d3dad69b5b67e0154fb597efe50b49164ecfaf816dc8a	2026-09-07 13:00:33.966	\N	\N	\N	2026-08-08 13:00:33.967
a1834b56-05c3-49c1-8e67-c64324506908	d3f33915-80b8-4831-9454-78ace16917cb	13f0b66c4f0fc7d52d89f2f7d9d829b252269c4057ec4f89d81425e366d6a517	2026-09-07 13:00:34.067	\N	\N	\N	2026-08-08 13:00:34.068
0fa6d7c9-e01f-4b53-9187-0857954a110e	4d6b0f11-97df-48d7-bbeb-38ccbc403d86	e056389d27ee1d4915528f636de9ed575685fae483f9d9c7407d91cd382dc2d2	2026-09-07 13:00:42.766	\N	\N	\N	2026-08-08 13:00:42.767
cb1bf3ed-d04e-45a3-bc99-806af1755425	2286372b-bfa0-4e12-94e9-1de8b3c3a21c	33f18ceb94196e7760f0e369b86088c19c4bb73f3d0e94a3f69eee050fe33bfe	2026-09-07 13:00:42.886	\N	\N	\N	2026-08-08 13:00:42.887
ef14e403-98f5-44b8-b8fd-ffd060927c21	14b1fccf-438e-455b-a4ac-35cc6093bcfd	f7200bb75ee113513cbfffeffa8b33b085f6a08d72521cd22bef6d083cacf0cf	2026-09-07 13:00:42.988	\N	\N	\N	2026-08-08 13:00:42.989
7651495a-d133-43b5-9377-ac2cab591f00	9fedc74c-7d55-4b9e-a83c-3ee98b982045	d8f57020aa56e5b0caaa58bca43f6d61af4a188cce218a5162ac37c30002253a	2026-09-07 18:47:19.871	\N	\N	\N	2026-08-08 18:47:19.873
3c385328-8b5f-430f-9545-8e4bec11ca33	77bd485b-e684-4fdb-82ff-022adbdba3e1	0400d27ea40e34b3636aef01fa78e2ac1b821034698670d7063c515082c4ed3b	2026-09-07 18:47:19.985	\N	\N	\N	2026-08-08 18:47:19.986
83e57651-a891-4181-962c-fbff3a71decb	34ecd01d-696f-4af1-a835-e31a00e7479e	2ebe80f1da88231c49dffc8217fa8e04b071b958d66401a288dc405a7e46fcc0	2026-09-07 18:47:28.332	\N	\N	\N	2026-08-08 18:47:28.334
46c9be42-24bf-411a-8abb-6485383429ad	a61c9c62-35b8-448a-8378-8c379905221b	1c8148dd4e1a781c0963341800f8c8bcddf5c40e4551d371d99710fe9ac3408f	2026-09-07 18:47:28.446	\N	\N	\N	2026-08-08 18:47:28.447
15726cb4-89fd-4b73-9044-0c67b916413a	3fc1932a-3cb1-4fc4-95b3-0eec98915d6d	464b1f75c40f94a5256e813e89597216461e0e9d0388cc62e69d575bae74b8af	2026-09-07 18:47:35.632	\N	\N	\N	2026-08-08 18:47:35.633
d6b3afcf-1dc9-4f64-b0f6-d01347553f4e	d1d6d8e0-0973-49a2-b42f-ad63af9bf613	7fbcfd0af1c4569ba20eb349f8b59b2999b9097c613040efd6ed76f4a34b8ad5	2026-09-07 18:47:35.746	\N	\N	\N	2026-08-08 18:47:35.747
1b4d95bb-201d-4436-81c0-69354d063ac0	dd938122-4e3b-4940-a8b7-5c39b9a77b44	714ad5dbba05521402792065db008cc176151bcfc918732d6f72cb449c412644	2026-09-07 18:47:43.149	\N	\N	\N	2026-08-08 18:47:43.151
125c10a7-c315-4703-9c1d-265ab90456a6	21ad8a73-0e09-49e8-a050-08af9cbf9983	96b77747332fc4734aa1258c1dbf00a0999ed3f1d4f04eb318b96bec5df11fba	2026-09-07 18:47:43.264	\N	\N	\N	2026-08-08 18:47:43.265
42437239-a001-4f8a-97a0-190051d5c7cd	eae1320c-7483-4857-97e1-0e91457d2dac	9e24bbcd064d28d357a65964b3b22ba8745739090aa22703c902c6257f36a750	2026-09-07 18:47:48.882	\N	\N	\N	2026-08-08 18:47:48.885
b536fdd8-2b74-40c5-973a-3061a943a2d9	a53f34f2-1634-4356-a7dd-d662d5045d7b	0a517e7637adf47a918f2394236ad211349900de941a467b84b617a7a0703777	2026-09-07 18:47:49	\N	\N	\N	2026-08-08 18:47:49.001
9eb5acb2-cd12-4e69-8e78-7f1c87b9cb19	bd33372a-c9b3-40fc-9a95-267330b8919d	95d4b1ce66f051b47f8e1d2a6d88ba9c146138a42b401466e538305f452de5bf	2026-09-07 18:48:04.045	\N	\N	\N	2026-08-08 18:48:04.046
bbe6517b-dfec-4aa8-9cfc-b95a4fd80746	b988a9aa-5954-4037-a9e3-16347aaa03b7	9e02e1a1276d054bfe8b6737305c18059dd9f2988d182b3982c884fec17e00d8	2026-09-07 18:48:04.365	\N	\N	\N	2026-08-08 18:48:04.366
3cceefe8-1d35-4179-a3b5-79e6103c46ea	01732611-871f-4326-8e33-f1f80445179d	35cec21d345969f23feaa19257f23b3611b8687eadc608f73ed718fc8742e72b	2026-09-07 18:48:04.533	\N	\N	\N	2026-08-08 18:48:04.535
0386d21a-0487-4390-9941-3a562a5b69f3	9036cb4f-1bea-47d6-9922-316dabacac20	f0ed8adaf2eda8bc1f9eb3d19da3201a9b26957723c080cbdf983253054d5195	2026-09-08 08:48:17.674	\N	\N	\N	2026-08-09 08:48:17.675
f70096f9-26e9-48a5-91d5-b724240775e3	9036cb4f-1bea-47d6-9922-316dabacac20	f0ed8adaf2eda8bc1f9eb3d19da3201a9b26957723c080cbdf983253054d5195	2026-09-08 08:48:17.928	\N	\N	\N	2026-08-09 08:48:17.929
c3a62d9b-683f-4300-83ee-4766f5231105	7f6e1fdf-d430-4681-b662-ebc188e57e8d	1cec811eb9e30f384f71aa4b168f21cb2e4935f2096918cefe6ecf395a83cf7c	2026-09-08 08:53:43.542	\N	\N	\N	2026-08-09 08:53:43.543
d1bd4725-61de-4bbc-9f13-9847adce58f6	77c52960-f67a-4edf-8eae-90c2c32a94df	2a3dfd2d54857d148aca796be9ff9a97f843f5f289624763820ca1f393b658f2	2026-09-08 08:53:43.652	\N	\N	\N	2026-08-09 08:53:43.653
cc17b9c4-272c-41d8-8f77-a9d71e898baf	973b0190-b2c6-49d3-9d28-2d1cdb7a74ca	f803f97fb75341ced145710be281b6284f06c74d26ac153c284b5bef0e38d36f	2026-09-08 08:53:53.554	\N	\N	\N	2026-08-09 08:53:53.555
153ae18d-0512-4734-a183-fbec1a94528c	973b0190-b2c6-49d3-9d28-2d1cdb7a74ca	f803f97fb75341ced145710be281b6284f06c74d26ac153c284b5bef0e38d36f	2026-09-08 08:53:53.827	\N	\N	\N	2026-08-09 08:53:53.827
dabbebaa-94bf-4be7-9e43-1e3847f09c8b	d70555da-2c13-4e27-b7c9-b45d6c444f42	803088186f8252191173f2be53fd4c726dcbf12a1137f848f40bce03ef92325f	2026-09-08 09:01:58.181	\N	\N	\N	2026-08-09 09:01:58.183
0148fb0e-0aa3-49d8-b534-f4de32a88d11	1babed97-82f7-4d16-b447-a5eda1e9ed43	8c1818dde86d62b16df813a91f7031d90e252d1bed76848bccf577908b501ba2	2026-09-08 09:03:09.294	\N	\N	\N	2026-08-09 09:03:09.295
fa68f5d9-d3c4-4fec-ad28-18f23f24d5c8	7cd48ff9-31bd-42a4-ae19-464d58b14a1a	6c78340ab1f53e8782a0edccba56ebff283a7a54b2c7ae557e09fbf776e231e1	2026-09-08 09:03:20.076	\N	\N	\N	2026-08-09 09:03:20.077
972bb6ca-2bc5-49ef-9300-293e93094994	ecbf156d-5a65-4245-819b-99b784b28987	8444ab08f30cfb30fe00da1703b76ffdc4bfafb3283d4bb121f383c3b99bd6be	2026-09-08 09:03:27.917	\N	\N	\N	2026-08-09 09:03:27.919
5efcb984-f8cd-4d8d-ab3a-c292fa2f2eaa	6e253a09-09c5-4851-ba06-278fcd1868e0	21f3803d62b29009b34831806542342a47beb13c93358114226ccf7bfbe1826d	2026-09-08 09:03:28.032	\N	\N	\N	2026-08-09 09:03:28.033
48286170-cb60-4be6-9ebe-e028d529ce57	e4565401-4b9f-4cd2-9e3d-fd72c5569457	be69e93846f40a6e1a0db6ebde50633eb3a2d4ed1d2521d2d1b0655acea35869	2026-09-07 18:29:26.313	\N	\N	\N	2026-08-08 18:29:26.314
9f0e288b-26be-4ccd-9077-cc86ec1ff891	e4565401-4b9f-4cd2-9e3d-fd72c5569457	738b9913d7162fe014e290ba5935c17f3b0f6de3916a054c976015e7d8787350	2026-09-07 18:30:10.157	\N	\N	\N	2026-08-08 18:30:10.158
d46374c8-9638-4636-9524-425ee873a096	72a391c8-c511-46ee-a879-5e6e3a61b77e	0dbc328b73439daa9ece956b21d583f3caa644731e7373398d4deb45fa884c7a	2026-09-08 06:43:36.448	2026-08-09 09:06:40.308	\N	\N	2026-08-09 06:43:36.449
f61bfa7c-df7f-4416-aef4-97a0382187b2	484e274b-bb7e-4679-9afd-a984a52a9a43	048257330af2d19e5941e2771b4bbac62017271fc90f0c736a8ddf728dbd032d	2026-09-07 18:48:23.008	\N	\N	\N	2026-08-08 18:48:23.01
ef66705c-5120-47ab-87fb-b2e4c5d33c13	5ac5cb9c-e6ce-4250-bdd0-f4d3137aa8c6	d745ada54e23ce8c2f0dc5cf2ff0938ee84c0055b64e995d501e46a097a66c94	2026-09-07 18:48:23.121	\N	\N	\N	2026-08-08 18:48:23.122
d190f21b-7b86-485e-8dab-83b2acfdf3ed	e4565401-4b9f-4cd2-9e3d-fd72c5569457	69ecae55500283a23dcd59cdf13edce9d4901aae53dc59928817ddfc6d605f96	2026-09-07 18:52:46.425	\N	\N	\N	2026-08-08 18:52:46.426
463d997b-ccaa-4fcc-a3fc-58a31d0278ba	a821940f-4b40-4ada-ba46-153a112fb158	ee43200db5f4f6861be09dd1402934ecc3028d0395b2391186b7666a23b5f49f	2026-09-07 19:32:40.308	\N	\N	\N	2026-08-08 19:32:40.309
5c83fded-7d0c-438c-b666-8f7f7e230854	5a3a556b-3a03-4159-8290-717c8e9959b8	4b6c5afe8b94deaebab42f555267bc4e3a5f9da6f6d69ed632fca910607015ba	2026-09-07 19:32:40.416	\N	\N	\N	2026-08-08 19:32:40.417
8485973f-ddc9-40fe-b3a3-1697f2ed480c	eaa19bc3-58de-40df-9a23-c5ca0c2c3882	e2e79348ae05f3c4a17521d37031e6e8ecbac15bb726deaf77ae96fa6ce2d2b6	2026-09-07 19:38:55.77	\N	\N	\N	2026-08-08 19:38:55.774
ad284dea-c8e7-4898-9b50-50b140b3e595	9b1f4cb4-6343-4dd9-b093-46bafdc147af	ce70085523ae0643533055e2a94177f05de8f56997a9d4bd46df37d342243880	2026-09-07 19:38:55.893	\N	\N	\N	2026-08-08 19:38:55.893
c49460cc-77c1-4c9f-8a05-2f0d8e5d52b1	3466c4a7-2011-4cf5-ba8d-3464c9cd4bc9	fa0688e2cd81dc8e17c6c127e20ecbf4fde54da81f3dd4a557908ba9a4d50240	2026-09-07 19:41:54.484	\N	\N	\N	2026-08-08 19:41:54.485
731ae22c-7451-4faa-98c6-ba98d0fc219c	bb9708fb-194b-49e0-b1e6-3e53a638c75d	9e02763d4dcd9ecf7b9e080a3b90f76654c72f26d4fa924fb9109cc836451e97	2026-09-07 19:41:54.592	\N	\N	\N	2026-08-08 19:41:54.593
9a5c476b-58a5-44b4-a7a5-56a7ecb31f81	9c67ad52-cfac-458c-a7e1-41410326bb87	9be3c59dcb565166aa1b3f95a1315a71fc44b18aed35acc1eb65c9ac67c102bb	2026-09-07 20:04:22.529	\N	\N	\N	2026-08-08 20:04:22.53
9715aaf3-bc30-4a64-b5f6-0698c6625dfc	994b0f5a-10b4-4d85-962a-308d9117a193	1a75080f0ea391087589494765c733d9a6d38136ea4d9c30671d548d41c0eebd	2026-09-07 20:04:22.638	\N	\N	\N	2026-08-08 20:04:22.639
b0bc4c74-6a43-4984-bf7e-d5dad269f244	72a391c8-c511-46ee-a879-5e6e3a61b77e	d7e2b48487f782fd98a46c53c6361930bd5aff88f260fba49a9dea3fe7bcb140	2026-09-07 20:49:52.759	\N	\N	\N	2026-08-08 20:49:52.76
8710f239-6fd9-4612-9607-8469015ac052	72a391c8-c511-46ee-a879-5e6e3a61b77e	d7e2b48487f782fd98a46c53c6361930bd5aff88f260fba49a9dea3fe7bcb140	2026-09-07 20:49:52.875	\N	\N	\N	2026-08-08 20:49:52.876
447b87f1-1493-438f-aff1-6d8db119719f	ad0a0e47-80be-4a23-82a6-d72e3de88b87	2882caff49f6eb52b0c101d3887df307528a2980f133469f7ca7b1eddcb0fc02	2026-09-07 20:52:52.568	\N	\N	\N	2026-08-08 20:52:52.569
82916839-d18c-4f0d-a09e-8ded813e2163	ad0a0e47-80be-4a23-82a6-d72e3de88b87	2882caff49f6eb52b0c101d3887df307528a2980f133469f7ca7b1eddcb0fc02	2026-09-07 20:52:52.763	\N	\N	\N	2026-08-08 20:52:52.764
84de1b33-1817-4d1f-9807-caa25473ea4d	ca0cdfc2-f5e5-4ece-ad98-1eff2c260a57	67d60d462ff6478b8de1e37624995f6b3bb6a202d842703259da75400e62dd9c	2026-09-07 20:52:59.346	\N	\N	\N	2026-08-08 20:52:59.348
335ac2d7-d4d7-4385-bebf-f9fca68afa06	8d91ec10-47b8-4903-b9d0-a82d31bbd909	c7310e40b48178729bc27407ca25a766c28328b33b5690a700970fd233faec57	2026-09-07 20:52:59.459	\N	\N	\N	2026-08-08 20:52:59.46
85a87607-1915-454c-bafe-366660077a80	72a391c8-c511-46ee-a879-5e6e3a61b77e	e67fd0db82ca3815ba7c3787d11a7f44134911daf5ba3e60c2c9fb5899842d90	2026-09-07 20:57:21.203	\N	\N	\N	2026-08-08 20:57:21.204
caecc1f9-f902-4c93-b401-4bb3b0b6f865	72a391c8-c511-46ee-a879-5e6e3a61b77e	3033efa0b21aedbec0ebc4f97571a2dbbea7e8ee03569cef39c33ae4b403d1fd	2026-09-07 21:04:42.366	\N	\N	\N	2026-08-08 21:04:42.366
a92e4f34-0977-45a1-91ba-c91030596eb9	72a391c8-c511-46ee-a879-5e6e3a61b77e	9dbab7976172409d54a6005a244530b45485435a52800534b04fdafcfb63e297	2026-09-07 21:05:38.461	2026-08-09 02:20:15.481	\N	\N	2026-08-08 21:05:38.462
5a8b5039-de57-4b10-b61a-eefa65cf02c6	72a391c8-c511-46ee-a879-5e6e3a61b77e	fd7745464eb370ec6b554a9b2aabe96ce4e2348d4160df5eade9d6acf63d046e	2026-09-08 02:20:15.484	\N	\N	\N	2026-08-09 02:20:15.485
d1f8cc6f-dba1-4031-a8c7-f6af4e7677b7	72a391c8-c511-46ee-a879-5e6e3a61b77e	74ad04ad5c6aab456caada5db952a2d22f4ecddb0bd187c716c99b5bcd3f0f80	2026-09-07 20:54:47.331	2026-08-09 02:42:21.403	\N	\N	2026-08-08 20:54:47.332
d3e6e021-b207-4618-a968-a8548e44a14f	72a391c8-c511-46ee-a879-5e6e3a61b77e	27db8671b72f3d1e5c8ee2bf02aa459f1bd5dbe0d3807147c074490391ffaf37	2026-09-08 02:42:21.406	\N	\N	\N	2026-08-09 02:42:21.407
fd2ba349-d52f-4928-9d23-1d123459a184	72a391c8-c511-46ee-a879-5e6e3a61b77e	12210ae53a3cf8f792b70fafdc6aea12d9097c181e631479488b4b01f249b30f	2026-09-08 02:42:33.259	2026-08-09 03:02:29.488	\N	\N	2026-08-09 02:42:33.259
f662cf38-c673-49b3-9732-fb94336fdf19	72a391c8-c511-46ee-a879-5e6e3a61b77e	3c24c0801afe1b462ddbc6648c3ffe5a1da57b3367f1ac38c434eccdb221d69f	2026-09-08 03:02:29.491	\N	\N	\N	2026-08-09 03:02:29.492
dc31be62-2239-4f23-a108-88e023410381	72a391c8-c511-46ee-a879-5e6e3a61b77e	bb527535de1fc1b9be6ae07f2fe5afe26cf1034a1a4a67ea863cd469f136ac0c	2026-09-08 03:02:39.655	\N	\N	\N	2026-08-09 03:02:39.655
a53b2e2e-2ed9-4fa0-802b-abd957a8e587	72a391c8-c511-46ee-a879-5e6e3a61b77e	8e460630a41fe595892b4e802700f0235aad61bb22117d362a84fa2443ede421	2026-09-08 02:20:20.606	2026-08-09 03:04:52.553	\N	\N	2026-08-09 02:20:20.607
388165e3-e96b-4956-bf79-b339575b37d7	72a391c8-c511-46ee-a879-5e6e3a61b77e	092b83cff09e1d7888fe508fdce7902392668aff51ee7a45060945fbf48f5163	2026-09-08 03:04:52.556	\N	\N	\N	2026-08-09 03:04:52.556
1f6ddbac-30de-4b0f-aecf-7ced18e864b3	72a391c8-c511-46ee-a879-5e6e3a61b77e	d37974bb775c2431fd45a9c433c92caae8926e4acb818bd1f7c66fd6234ca6e5	2026-09-08 03:04:56.551	\N	\N	\N	2026-08-09 03:04:56.552
d8f6dd9f-2ad2-4bff-a183-18b08e410aeb	72a391c8-c511-46ee-a879-5e6e3a61b77e	ba90beabf6bd71fef1e95ad35d80a1cb96ff326ac5418ada19536b86ca482a32	2026-09-08 03:05:35.382	\N	\N	\N	2026-08-09 03:05:35.383
fdc4bb35-ec60-49b3-8997-e6de07c176d7	72a391c8-c511-46ee-a879-5e6e3a61b77e	68f949f34f4942e225b9d26625198829470ca6d4367af908cdd6d9840d8c25f2	2026-09-08 03:11:58.69	\N	\N	\N	2026-08-09 03:11:58.69
8b8e8d2e-5cdf-43a1-a0d2-a0efc5423c10	72a391c8-c511-46ee-a879-5e6e3a61b77e	2ec809852e7fcfd5bf173d5b26773d493fb9884125f1c35210fecf539ce34505	2026-09-08 03:13:44.382	\N	\N	\N	2026-08-09 03:13:44.383
8c5f1ed6-c03e-4e8b-a6ab-ac112cb6d006	72a391c8-c511-46ee-a879-5e6e3a61b77e	308cfff3938571096d569b02cfefc214589516981c36b12c0b66eb45df1925fc	2026-09-08 03:32:38.017	\N	\N	\N	2026-08-09 03:32:38.018
f990d39b-ee7e-4b60-afdf-1da331e123dd	f43e02d6-4a6f-4f39-a0e6-d9650053b7d9	94c534e4eadf53acaf05bb3d7e3328a44cc1e016846927b2ec3f3ac7a86a2563	2026-09-08 05:13:02.227	\N	\N	\N	2026-08-09 05:13:02.229
8eb7fd4a-5944-4e1d-ad54-5db988853a31	72a391c8-c511-46ee-a879-5e6e3a61b77e	84d7d5eb05aa0e4af6429a45c15783a7e63d686e44e6b7c7cbf79257f6f8ee70	2026-09-08 03:50:00.988	2026-08-09 05:25:30.644	\N	\N	2026-08-09 03:50:00.989
a67732fa-fa4b-4d45-98e1-9eea6ad926a1	72a391c8-c511-46ee-a879-5e6e3a61b77e	cd3f5b3c07c01ab59446cd8cd8eaf7ee95f1125d6e8a6727cd73cdb2a6898ceb	2026-09-08 05:25:30.651	\N	\N	\N	2026-08-09 05:25:30.653
0fffda92-fc7e-4ba7-986b-c879e14755a3	72a391c8-c511-46ee-a879-5e6e3a61b77e	19ca41be25441435716dec20842404b49343f3796b39fc6f42e456ce2c802254	2026-09-08 05:33:20.595	2026-08-09 05:51:54.71	\N	\N	2026-08-09 05:33:20.596
2e41541f-6354-409e-96d3-286200cbb8d6	5ebfc665-cac7-4cf1-850e-0ca55f7de574	67658b1192ff9128bb978032998860a8f4c07eeb0590cf44f0f4375d2e21beba	2026-09-08 05:57:27.441	\N	\N	\N	2026-08-09 05:57:27.442
26889bc0-97df-4155-9c27-8a8b1c62332e	0b961000-86e2-410b-99a8-4055fb9a4136	386ea9f01716308c9236a90ae356a7ad0e6d95e9fedc2a55be01edbcebd30098	2026-09-08 05:57:27.555	\N	\N	\N	2026-08-09 05:57:27.556
0e7a2e54-54f4-4547-92e6-962a14213e2d	b897eb1f-88e7-4875-8c07-75360b11a2e5	7967cd357ba88cc85bccb094b260fdc86c5d63677dbc47a40eb7bbf4206f3be0	2026-09-08 05:57:34.998	\N	\N	\N	2026-08-09 05:57:34.999
649513a1-d2c9-437b-82ef-6c3599ef7cad	b897eb1f-88e7-4875-8c07-75360b11a2e5	34e8c87462a5a5c13f0a190d7145b6866127da9a8afc1e5beb83f69b8e9afb12	2026-09-08 05:57:35.473	\N	\N	\N	2026-08-09 05:57:35.474
cdb5c517-6626-4a39-85c4-f85e48611638	a10fd152-89b4-4b11-9968-641ecaa2d89d	7a48d51890198261eefebdb2850a1df64cad24f047fbbd6d0858e58808129cd2	2026-09-08 06:01:37.105	\N	\N	\N	2026-08-09 06:01:37.109
115f905c-61b7-48c2-914e-0475092d865a	b589ee8d-f3f9-4568-b358-bee9035a1eb9	9cc333173b5477157c4cba7a576e9c1d16c1ab325d366e8ed22693cf6a2273de	2026-09-08 06:01:37.375	\N	\N	\N	2026-08-09 06:01:37.376
46b47682-e196-4644-8f3f-1a5905d2d6b3	5ffd7f84-6e5c-43ed-ac10-9488bfa37744	3a7e0c829eeaf79b86a5b19da68894a06574e943262b6faabce92348abbaeec0	2026-09-08 06:01:43.858	\N	\N	\N	2026-08-09 06:01:43.859
eefe15cb-0eaf-44b0-93be-5c50dea826c3	5ffd7f84-6e5c-43ed-ac10-9488bfa37744	355115caade9d7e388b67afc5033b63498d18ca36b140207f555b329bfca4de6	2026-09-08 06:01:44.181	\N	\N	\N	2026-08-09 06:01:44.182
407d47d0-ccf8-4446-9a9f-b215a97cf39f	72a391c8-c511-46ee-a879-5e6e3a61b77e	9cc19c551df411f6f093020849e348059b812a0056641bb385177e028e4ba820	2026-09-08 05:51:54.715	2026-08-09 06:29:13.263	\N	\N	2026-08-09 05:51:54.716
d7900780-dfd1-465d-8417-3ad2b80b760d	72a391c8-c511-46ee-a879-5e6e3a61b77e	74c0860ac8418261566e7da3153e463dd034bacc8a5d32693ca0ab2b457cc65b	2026-09-08 06:29:13.268	\N	\N	\N	2026-08-09 06:29:13.269
616ec3b1-486a-4638-a83f-3e05b3074bea	72a391c8-c511-46ee-a879-5e6e3a61b77e	c5710776b5f051a929ddad9fb981dc77eace45258977b4603b230bf715a6ebb5	2026-09-08 06:31:29.697	\N	\N	\N	2026-08-09 06:31:29.698
1101c217-001d-4090-ab13-1c2c168d2d84	72a391c8-c511-46ee-a879-5e6e3a61b77e	eafe8ee01bb83c26d3d375f74ac569271345496c7cbe27e2fa0c08eb088905ee	2026-09-08 06:45:20.569	\N	\N	\N	2026-08-09 06:45:20.57
4d0c3306-063c-45ad-ab53-f32dc6fa02b5	c6619c64-6d4e-42a8-8247-d3d8785b272b	d74f7fa95cc7129e48251f6f79b5d7e45c7768214d24b68c3356fcaddcd18177	2026-09-08 08:45:06.043	\N	\N	\N	2026-08-09 08:45:06.045
e18c4ac0-fee8-4894-a54f-3d6b68fb978d	810d95f6-de08-475e-924f-5d7d251a7ab7	c8ef4933326be01849febf03fd806d280ff4557216d4b629613a9481d2376c5c	2026-09-08 08:45:06.163	\N	\N	\N	2026-08-09 08:45:06.164
0f1c52b2-702b-40a3-bd4c-9c573a75dfc6	02a23e8c-a718-47b1-84f0-d1478336e639	c5166c3951648fe956010a70cd686246d262aefa4d64f57b382c5dbbf10a275b	2026-09-08 09:03:37.543	\N	\N	\N	2026-08-09 09:03:37.544
365ea18d-607c-4577-a572-33e166c98d80	02a23e8c-a718-47b1-84f0-d1478336e639	c5166c3951648fe956010a70cd686246d262aefa4d64f57b382c5dbbf10a275b	2026-09-08 09:03:37.788	\N	\N	\N	2026-08-09 09:03:37.79
6df91480-d495-4255-af30-23bd9c7aff27	bc5503b0-0534-42e0-ad18-948c51afbdac	984efff31c477a02ea07c3d08ad2386dd620d15214f994d5dbaa2724b00c03cb	2026-09-08 09:06:13.733	\N	\N	\N	2026-08-09 09:06:13.738
d2c31625-5319-4520-a101-c80e2de79f83	92c67ac8-d7f7-4daf-82c6-52942d5d0e49	be01399184bd93e64229e5a76656c320c60ae081efede2af76e9e6d084078625	2026-09-08 09:06:18.095	\N	\N	\N	2026-08-09 09:06:18.099
1d1bd58d-d21f-485f-b1a5-bc11a44d5050	1ab2e0e6-638e-445b-a32a-e51c5cb3a627	5fb83e4f4a88f40dde1eea790633c044565bf8266a9b70db9c3e548909b38153	2026-09-08 09:06:19.996	\N	\N	\N	2026-08-09 09:06:20
839871fb-cdce-45c2-bf7c-997877753fe8	9da4dd60-708c-4173-8849-826b269a6eb7	c35d4f817521cf2e0404e351e2120701b1b5eadf9f7433eb5f5aa37abb926672	2026-09-08 09:06:28.067	\N	\N	\N	2026-08-09 09:06:28.069
1617ce65-20a0-42d8-b914-4d2a518aabfb	14378809-2834-430c-a48a-a6b54d6516c2	a82dfa3cfaadefcb2c5892f8f20c830b74adddce368b170680765d0444505677	2026-09-08 09:06:28.177	\N	\N	\N	2026-08-09 09:06:28.178
c6f5dd94-2523-46aa-b888-39717f6a7be8	7a5cb131-4d1b-4ae4-822b-840832188c6a	f6e44752672d9d24d402427e065c96e8d8bc67db588a449006e733a69ed0f50f	2026-09-08 09:06:37.795	\N	\N	\N	2026-08-09 09:06:37.796
104ae46a-d5c4-4aa0-a3ec-65da294201f7	7a5cb131-4d1b-4ae4-822b-840832188c6a	5cc8faaa2b433f2c2f4a93db603aaa1e77af646ea33096462867fb4a732696e0	2026-09-08 09:06:38.039	\N	\N	\N	2026-08-09 09:06:38.042
aaf2eacb-8e42-4d75-bb13-e9049bfef7b9	72a391c8-c511-46ee-a879-5e6e3a61b77e	84ee305b1217d762a7d9bad339c4ce02ac6fc5193966df9c13f14a8f53986158	2026-09-08 09:06:40.311	\N	\N	\N	2026-08-09 09:06:40.312
33ce0285-ec7a-440b-91e0-369416e53327	12117c2e-11f4-4f32-b96e-2afb05256e74	5db7e52a408dd5628202997ef47e136b2e3309314e1aeba90dcd778105342ae9	2026-09-08 09:10:19.623	\N	\N	\N	2026-08-09 09:10:19.624
b41a1d84-e402-42f2-ae58-0ebf2e2301b4	f5d6d9de-b8ad-43a9-95c2-5bc5b3d119d5	7ab6e970e3011693fd6a047949f32dfc09b8f4040e47f9d5854fc13f2d3ff49b	2026-09-08 09:10:21.614	\N	\N	\N	2026-08-09 09:10:21.615
c7754c6f-c529-4e66-aa0b-11553a42c5f7	23041a8d-daa0-4e82-9317-51c813e311a5	a1fcb674a523554ef15371b08bf24f2790993be54cda05419d3ba8fa92ce21db	2026-09-08 09:10:29.632	\N	\N	\N	2026-08-09 09:10:29.633
b024b72d-c2f4-430d-a912-41d4d18c9f1f	c0c24478-f3dd-4fca-b741-34cc76430fc1	d1d6041881be94892bf107b5cf4004f87ac97dc4b64863a7b20926b1f06c6482	2026-09-08 09:10:29.742	\N	\N	\N	2026-08-09 09:10:29.743
926b9bd0-0fa4-4722-a694-3fee6e48b299	e8801b4e-a320-4029-bbcc-d87ca2c10ca4	6f6c750f9f6544086ab31c178e3f1e0a34ed8ff56d94df2e2686065752e873a0	2026-09-08 09:10:39.123	\N	\N	\N	2026-08-09 09:10:39.124
bd2e0724-8435-4019-a2ee-e434dbc4c134	e8801b4e-a320-4029-bbcc-d87ca2c10ca4	6f6c750f9f6544086ab31c178e3f1e0a34ed8ff56d94df2e2686065752e873a0	2026-09-08 09:10:39.38	\N	\N	\N	2026-08-09 09:10:39.381
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
f7f81fff-2392-479b-b4f2-d009056b0c2a	c97b29a7-7764-4893-9de9-18e3fee94462
f7f81fff-2392-479b-b4f2-d009056b0c2a	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
f7f81fff-2392-479b-b4f2-d009056b0c2a	b04b6a7e-76a5-4f52-9ece-a163704efa38
f7f81fff-2392-479b-b4f2-d009056b0c2a	51234121-4440-4eea-8ba9-9a181f0b39a4
f7f81fff-2392-479b-b4f2-d009056b0c2a	b4cd517d-cf3b-4001-bc2d-7109a171dd59
f7f81fff-2392-479b-b4f2-d009056b0c2a	c651765c-ad9d-43c2-853a-cc3e595b2713
f7f81fff-2392-479b-b4f2-d009056b0c2a	156357b5-b39f-4940-85f4-6b58da5ee830
f7f81fff-2392-479b-b4f2-d009056b0c2a	52552512-4b33-47f3-98f5-1f4e60d3a8b1
f7f81fff-2392-479b-b4f2-d009056b0c2a	1f2e2ce8-8798-42f2-bec0-744e14bca51c
f7f81fff-2392-479b-b4f2-d009056b0c2a	44e95148-7ff7-4a12-a28f-2e49be00bb98
f7f81fff-2392-479b-b4f2-d009056b0c2a	83c3b6ae-b146-4ed1-8154-3c13d651ad26
f7f81fff-2392-479b-b4f2-d009056b0c2a	e70ff4ad-1601-4af6-9d46-c635a9118437
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	c97b29a7-7764-4893-9de9-18e3fee94462
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	b04b6a7e-76a5-4f52-9ece-a163704efa38
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	b4cd517d-cf3b-4001-bc2d-7109a171dd59
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	c651765c-ad9d-43c2-853a-cc3e595b2713
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	156357b5-b39f-4940-85f4-6b58da5ee830
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	52552512-4b33-47f3-98f5-1f4e60d3a8b1
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	1f2e2ce8-8798-42f2-bec0-744e14bca51c
ed52a830-1c11-4eac-8fde-75604abab500	156357b5-b39f-4940-85f4-6b58da5ee830
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	44e95148-7ff7-4a12-a28f-2e49be00bb98
f7f81fff-2392-479b-b4f2-d009056b0c2a	26c9669f-bf10-49df-bab7-c7d222abc082
f7f81fff-2392-479b-b4f2-d009056b0c2a	b5dd85d2-caea-4053-95fe-a8a813bfa293
f7f81fff-2392-479b-b4f2-d009056b0c2a	45fbacad-1b42-4318-b7c5-01353f3466b7
f7f81fff-2392-479b-b4f2-d009056b0c2a	7fd214da-d40e-4f05-8d64-f23b9644c0af
f7f81fff-2392-479b-b4f2-d009056b0c2a	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
f7f81fff-2392-479b-b4f2-d009056b0c2a	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
f7f81fff-2392-479b-b4f2-d009056b0c2a	f8bf3446-59d2-479b-a773-44bb2f17f50b
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	26c9669f-bf10-49df-bab7-c7d222abc082
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	b5dd85d2-caea-4053-95fe-a8a813bfa293
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	45fbacad-1b42-4318-b7c5-01353f3466b7
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	7fd214da-d40e-4f05-8d64-f23b9644c0af
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	f8bf3446-59d2-479b-a773-44bb2f17f50b
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	c97b29a7-7764-4893-9de9-18e3fee94462
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
ce2949bc-4f5a-49e5-87af-6092d06c6d22	b5dd85d2-caea-4053-95fe-a8a813bfa293
ce2949bc-4f5a-49e5-87af-6092d06c6d22	45fbacad-1b42-4318-b7c5-01353f3466b7
ce2949bc-4f5a-49e5-87af-6092d06c6d22	7fd214da-d40e-4f05-8d64-f23b9644c0af
ce2949bc-4f5a-49e5-87af-6092d06c6d22	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
ce2949bc-4f5a-49e5-87af-6092d06c6d22	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
ce2949bc-4f5a-49e5-87af-6092d06c6d22	f8bf3446-59d2-479b-a773-44bb2f17f50b
ce2949bc-4f5a-49e5-87af-6092d06c6d22	c97b29a7-7764-4893-9de9-18e3fee94462
ce2949bc-4f5a-49e5-87af-6092d06c6d22	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
ce2949bc-4f5a-49e5-87af-6092d06c6d22	b04b6a7e-76a5-4f52-9ece-a163704efa38
ce2949bc-4f5a-49e5-87af-6092d06c6d22	51234121-4440-4eea-8ba9-9a181f0b39a4
ce2949bc-4f5a-49e5-87af-6092d06c6d22	b4cd517d-cf3b-4001-bc2d-7109a171dd59
ce2949bc-4f5a-49e5-87af-6092d06c6d22	c651765c-ad9d-43c2-853a-cc3e595b2713
ce2949bc-4f5a-49e5-87af-6092d06c6d22	156357b5-b39f-4940-85f4-6b58da5ee830
ce2949bc-4f5a-49e5-87af-6092d06c6d22	52552512-4b33-47f3-98f5-1f4e60d3a8b1
ce2949bc-4f5a-49e5-87af-6092d06c6d22	1f2e2ce8-8798-42f2-bec0-744e14bca51c
ce2949bc-4f5a-49e5-87af-6092d06c6d22	44e95148-7ff7-4a12-a28f-2e49be00bb98
ce2949bc-4f5a-49e5-87af-6092d06c6d22	83c3b6ae-b146-4ed1-8154-3c13d651ad26
ce2949bc-4f5a-49e5-87af-6092d06c6d22	e70ff4ad-1601-4af6-9d46-c635a9118437
ce2949bc-4f5a-49e5-87af-6092d06c6d22	26c9669f-bf10-49df-bab7-c7d222abc082
1d263619-3889-40b8-a1f7-1b804d6e1403	c97b29a7-7764-4893-9de9-18e3fee94462
1d263619-3889-40b8-a1f7-1b804d6e1403	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
1d263619-3889-40b8-a1f7-1b804d6e1403	b04b6a7e-76a5-4f52-9ece-a163704efa38
1d263619-3889-40b8-a1f7-1b804d6e1403	b4cd517d-cf3b-4001-bc2d-7109a171dd59
1d263619-3889-40b8-a1f7-1b804d6e1403	c651765c-ad9d-43c2-853a-cc3e595b2713
1d263619-3889-40b8-a1f7-1b804d6e1403	156357b5-b39f-4940-85f4-6b58da5ee830
1d263619-3889-40b8-a1f7-1b804d6e1403	52552512-4b33-47f3-98f5-1f4e60d3a8b1
1d263619-3889-40b8-a1f7-1b804d6e1403	1f2e2ce8-8798-42f2-bec0-744e14bca51c
1d263619-3889-40b8-a1f7-1b804d6e1403	44e95148-7ff7-4a12-a28f-2e49be00bb98
1d263619-3889-40b8-a1f7-1b804d6e1403	26c9669f-bf10-49df-bab7-c7d222abc082
1d263619-3889-40b8-a1f7-1b804d6e1403	b5dd85d2-caea-4053-95fe-a8a813bfa293
1d263619-3889-40b8-a1f7-1b804d6e1403	45fbacad-1b42-4318-b7c5-01353f3466b7
1d263619-3889-40b8-a1f7-1b804d6e1403	7fd214da-d40e-4f05-8d64-f23b9644c0af
1d263619-3889-40b8-a1f7-1b804d6e1403	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
1d263619-3889-40b8-a1f7-1b804d6e1403	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
1d263619-3889-40b8-a1f7-1b804d6e1403	f8bf3446-59d2-479b-a773-44bb2f17f50b
c4a9352c-f519-4f21-9a42-bb3d2c81b141	156357b5-b39f-4940-85f4-6b58da5ee830
05c60e5e-2664-45a2-9cbe-5a766c096f86	b5dd85d2-caea-4053-95fe-a8a813bfa293
05c60e5e-2664-45a2-9cbe-5a766c096f86	45fbacad-1b42-4318-b7c5-01353f3466b7
05c60e5e-2664-45a2-9cbe-5a766c096f86	7fd214da-d40e-4f05-8d64-f23b9644c0af
05c60e5e-2664-45a2-9cbe-5a766c096f86	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
05c60e5e-2664-45a2-9cbe-5a766c096f86	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
05c60e5e-2664-45a2-9cbe-5a766c096f86	f8bf3446-59d2-479b-a773-44bb2f17f50b
05c60e5e-2664-45a2-9cbe-5a766c096f86	c97b29a7-7764-4893-9de9-18e3fee94462
05c60e5e-2664-45a2-9cbe-5a766c096f86	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
05c60e5e-2664-45a2-9cbe-5a766c096f86	b04b6a7e-76a5-4f52-9ece-a163704efa38
05c60e5e-2664-45a2-9cbe-5a766c096f86	51234121-4440-4eea-8ba9-9a181f0b39a4
05c60e5e-2664-45a2-9cbe-5a766c096f86	b4cd517d-cf3b-4001-bc2d-7109a171dd59
05c60e5e-2664-45a2-9cbe-5a766c096f86	c651765c-ad9d-43c2-853a-cc3e595b2713
05c60e5e-2664-45a2-9cbe-5a766c096f86	156357b5-b39f-4940-85f4-6b58da5ee830
05c60e5e-2664-45a2-9cbe-5a766c096f86	52552512-4b33-47f3-98f5-1f4e60d3a8b1
05c60e5e-2664-45a2-9cbe-5a766c096f86	1f2e2ce8-8798-42f2-bec0-744e14bca51c
05c60e5e-2664-45a2-9cbe-5a766c096f86	44e95148-7ff7-4a12-a28f-2e49be00bb98
05c60e5e-2664-45a2-9cbe-5a766c096f86	83c3b6ae-b146-4ed1-8154-3c13d651ad26
05c60e5e-2664-45a2-9cbe-5a766c096f86	e70ff4ad-1601-4af6-9d46-c635a9118437
05c60e5e-2664-45a2-9cbe-5a766c096f86	26c9669f-bf10-49df-bab7-c7d222abc082
6f006da6-ec24-4082-b62b-ba1197f8f456	c97b29a7-7764-4893-9de9-18e3fee94462
6f006da6-ec24-4082-b62b-ba1197f8f456	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
6f006da6-ec24-4082-b62b-ba1197f8f456	b04b6a7e-76a5-4f52-9ece-a163704efa38
6f006da6-ec24-4082-b62b-ba1197f8f456	b4cd517d-cf3b-4001-bc2d-7109a171dd59
6f006da6-ec24-4082-b62b-ba1197f8f456	c651765c-ad9d-43c2-853a-cc3e595b2713
6f006da6-ec24-4082-b62b-ba1197f8f456	156357b5-b39f-4940-85f4-6b58da5ee830
6f006da6-ec24-4082-b62b-ba1197f8f456	52552512-4b33-47f3-98f5-1f4e60d3a8b1
6f006da6-ec24-4082-b62b-ba1197f8f456	1f2e2ce8-8798-42f2-bec0-744e14bca51c
6f006da6-ec24-4082-b62b-ba1197f8f456	44e95148-7ff7-4a12-a28f-2e49be00bb98
6f006da6-ec24-4082-b62b-ba1197f8f456	26c9669f-bf10-49df-bab7-c7d222abc082
6f006da6-ec24-4082-b62b-ba1197f8f456	b5dd85d2-caea-4053-95fe-a8a813bfa293
6f006da6-ec24-4082-b62b-ba1197f8f456	45fbacad-1b42-4318-b7c5-01353f3466b7
6f006da6-ec24-4082-b62b-ba1197f8f456	7fd214da-d40e-4f05-8d64-f23b9644c0af
6f006da6-ec24-4082-b62b-ba1197f8f456	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
6f006da6-ec24-4082-b62b-ba1197f8f456	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
6f006da6-ec24-4082-b62b-ba1197f8f456	f8bf3446-59d2-479b-a773-44bb2f17f50b
b49ecf65-e7eb-45e2-9a6b-4616f0a0b102	156357b5-b39f-4940-85f4-6b58da5ee830
69c95746-861e-4f84-afe4-ec42b734eff9	c97b29a7-7764-4893-9de9-18e3fee94462
69c95746-861e-4f84-afe4-ec42b734eff9	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
69c95746-861e-4f84-afe4-ec42b734eff9	b04b6a7e-76a5-4f52-9ece-a163704efa38
69c95746-861e-4f84-afe4-ec42b734eff9	51234121-4440-4eea-8ba9-9a181f0b39a4
69c95746-861e-4f84-afe4-ec42b734eff9	b4cd517d-cf3b-4001-bc2d-7109a171dd59
69c95746-861e-4f84-afe4-ec42b734eff9	c651765c-ad9d-43c2-853a-cc3e595b2713
69c95746-861e-4f84-afe4-ec42b734eff9	156357b5-b39f-4940-85f4-6b58da5ee830
69c95746-861e-4f84-afe4-ec42b734eff9	52552512-4b33-47f3-98f5-1f4e60d3a8b1
69c95746-861e-4f84-afe4-ec42b734eff9	1f2e2ce8-8798-42f2-bec0-744e14bca51c
69c95746-861e-4f84-afe4-ec42b734eff9	44e95148-7ff7-4a12-a28f-2e49be00bb98
69c95746-861e-4f84-afe4-ec42b734eff9	83c3b6ae-b146-4ed1-8154-3c13d651ad26
69c95746-861e-4f84-afe4-ec42b734eff9	e70ff4ad-1601-4af6-9d46-c635a9118437
69c95746-861e-4f84-afe4-ec42b734eff9	26c9669f-bf10-49df-bab7-c7d222abc082
69c95746-861e-4f84-afe4-ec42b734eff9	b5dd85d2-caea-4053-95fe-a8a813bfa293
69c95746-861e-4f84-afe4-ec42b734eff9	45fbacad-1b42-4318-b7c5-01353f3466b7
69c95746-861e-4f84-afe4-ec42b734eff9	7fd214da-d40e-4f05-8d64-f23b9644c0af
69c95746-861e-4f84-afe4-ec42b734eff9	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
69c95746-861e-4f84-afe4-ec42b734eff9	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
69c95746-861e-4f84-afe4-ec42b734eff9	f8bf3446-59d2-479b-a773-44bb2f17f50b
3c742dbf-418b-49c8-af8b-64d442341049	c97b29a7-7764-4893-9de9-18e3fee94462
3c742dbf-418b-49c8-af8b-64d442341049	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
3c742dbf-418b-49c8-af8b-64d442341049	b04b6a7e-76a5-4f52-9ece-a163704efa38
3c742dbf-418b-49c8-af8b-64d442341049	b4cd517d-cf3b-4001-bc2d-7109a171dd59
3c742dbf-418b-49c8-af8b-64d442341049	c651765c-ad9d-43c2-853a-cc3e595b2713
3c742dbf-418b-49c8-af8b-64d442341049	156357b5-b39f-4940-85f4-6b58da5ee830
3c742dbf-418b-49c8-af8b-64d442341049	52552512-4b33-47f3-98f5-1f4e60d3a8b1
3c742dbf-418b-49c8-af8b-64d442341049	1f2e2ce8-8798-42f2-bec0-744e14bca51c
3c742dbf-418b-49c8-af8b-64d442341049	44e95148-7ff7-4a12-a28f-2e49be00bb98
3c742dbf-418b-49c8-af8b-64d442341049	26c9669f-bf10-49df-bab7-c7d222abc082
3c742dbf-418b-49c8-af8b-64d442341049	b5dd85d2-caea-4053-95fe-a8a813bfa293
3c742dbf-418b-49c8-af8b-64d442341049	45fbacad-1b42-4318-b7c5-01353f3466b7
3c742dbf-418b-49c8-af8b-64d442341049	7fd214da-d40e-4f05-8d64-f23b9644c0af
3c742dbf-418b-49c8-af8b-64d442341049	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
3c742dbf-418b-49c8-af8b-64d442341049	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
3c742dbf-418b-49c8-af8b-64d442341049	f8bf3446-59d2-479b-a773-44bb2f17f50b
14844705-cc42-4fbd-87ff-b2804156aedf	156357b5-b39f-4940-85f4-6b58da5ee830
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	c97b29a7-7764-4893-9de9-18e3fee94462
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	b04b6a7e-76a5-4f52-9ece-a163704efa38
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	51234121-4440-4eea-8ba9-9a181f0b39a4
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	b4cd517d-cf3b-4001-bc2d-7109a171dd59
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	c651765c-ad9d-43c2-853a-cc3e595b2713
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	156357b5-b39f-4940-85f4-6b58da5ee830
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	52552512-4b33-47f3-98f5-1f4e60d3a8b1
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	1f2e2ce8-8798-42f2-bec0-744e14bca51c
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	44e95148-7ff7-4a12-a28f-2e49be00bb98
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	83c3b6ae-b146-4ed1-8154-3c13d651ad26
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	e70ff4ad-1601-4af6-9d46-c635a9118437
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	26c9669f-bf10-49df-bab7-c7d222abc082
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	b5dd85d2-caea-4053-95fe-a8a813bfa293
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	45fbacad-1b42-4318-b7c5-01353f3466b7
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	7fd214da-d40e-4f05-8d64-f23b9644c0af
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	f8bf3446-59d2-479b-a773-44bb2f17f50b
aeba451d-4106-4d98-a01e-2821921c1657	c97b29a7-7764-4893-9de9-18e3fee94462
aeba451d-4106-4d98-a01e-2821921c1657	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
aeba451d-4106-4d98-a01e-2821921c1657	b04b6a7e-76a5-4f52-9ece-a163704efa38
aeba451d-4106-4d98-a01e-2821921c1657	b4cd517d-cf3b-4001-bc2d-7109a171dd59
aeba451d-4106-4d98-a01e-2821921c1657	c651765c-ad9d-43c2-853a-cc3e595b2713
aeba451d-4106-4d98-a01e-2821921c1657	156357b5-b39f-4940-85f4-6b58da5ee830
aeba451d-4106-4d98-a01e-2821921c1657	52552512-4b33-47f3-98f5-1f4e60d3a8b1
aeba451d-4106-4d98-a01e-2821921c1657	1f2e2ce8-8798-42f2-bec0-744e14bca51c
aeba451d-4106-4d98-a01e-2821921c1657	44e95148-7ff7-4a12-a28f-2e49be00bb98
aeba451d-4106-4d98-a01e-2821921c1657	26c9669f-bf10-49df-bab7-c7d222abc082
aeba451d-4106-4d98-a01e-2821921c1657	b5dd85d2-caea-4053-95fe-a8a813bfa293
aeba451d-4106-4d98-a01e-2821921c1657	45fbacad-1b42-4318-b7c5-01353f3466b7
aeba451d-4106-4d98-a01e-2821921c1657	7fd214da-d40e-4f05-8d64-f23b9644c0af
aeba451d-4106-4d98-a01e-2821921c1657	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
aeba451d-4106-4d98-a01e-2821921c1657	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
aeba451d-4106-4d98-a01e-2821921c1657	f8bf3446-59d2-479b-a773-44bb2f17f50b
eaf7aad9-739e-418b-8980-24217fb85ac4	156357b5-b39f-4940-85f4-6b58da5ee830
3bf67871-202c-4818-9bae-87e89c161209	c97b29a7-7764-4893-9de9-18e3fee94462
3bf67871-202c-4818-9bae-87e89c161209	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
3bf67871-202c-4818-9bae-87e89c161209	b04b6a7e-76a5-4f52-9ece-a163704efa38
3bf67871-202c-4818-9bae-87e89c161209	51234121-4440-4eea-8ba9-9a181f0b39a4
3bf67871-202c-4818-9bae-87e89c161209	b4cd517d-cf3b-4001-bc2d-7109a171dd59
3bf67871-202c-4818-9bae-87e89c161209	c651765c-ad9d-43c2-853a-cc3e595b2713
3bf67871-202c-4818-9bae-87e89c161209	156357b5-b39f-4940-85f4-6b58da5ee830
3bf67871-202c-4818-9bae-87e89c161209	52552512-4b33-47f3-98f5-1f4e60d3a8b1
3bf67871-202c-4818-9bae-87e89c161209	1f2e2ce8-8798-42f2-bec0-744e14bca51c
3bf67871-202c-4818-9bae-87e89c161209	44e95148-7ff7-4a12-a28f-2e49be00bb98
3bf67871-202c-4818-9bae-87e89c161209	83c3b6ae-b146-4ed1-8154-3c13d651ad26
3bf67871-202c-4818-9bae-87e89c161209	e70ff4ad-1601-4af6-9d46-c635a9118437
3bf67871-202c-4818-9bae-87e89c161209	26c9669f-bf10-49df-bab7-c7d222abc082
3bf67871-202c-4818-9bae-87e89c161209	b5dd85d2-caea-4053-95fe-a8a813bfa293
3bf67871-202c-4818-9bae-87e89c161209	45fbacad-1b42-4318-b7c5-01353f3466b7
3bf67871-202c-4818-9bae-87e89c161209	7fd214da-d40e-4f05-8d64-f23b9644c0af
3bf67871-202c-4818-9bae-87e89c161209	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
3bf67871-202c-4818-9bae-87e89c161209	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
3bf67871-202c-4818-9bae-87e89c161209	f8bf3446-59d2-479b-a773-44bb2f17f50b
24c8ae9a-c82f-493f-b44a-5f8f38542f03	c97b29a7-7764-4893-9de9-18e3fee94462
24c8ae9a-c82f-493f-b44a-5f8f38542f03	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
24c8ae9a-c82f-493f-b44a-5f8f38542f03	b04b6a7e-76a5-4f52-9ece-a163704efa38
24c8ae9a-c82f-493f-b44a-5f8f38542f03	b4cd517d-cf3b-4001-bc2d-7109a171dd59
24c8ae9a-c82f-493f-b44a-5f8f38542f03	c651765c-ad9d-43c2-853a-cc3e595b2713
24c8ae9a-c82f-493f-b44a-5f8f38542f03	156357b5-b39f-4940-85f4-6b58da5ee830
24c8ae9a-c82f-493f-b44a-5f8f38542f03	52552512-4b33-47f3-98f5-1f4e60d3a8b1
24c8ae9a-c82f-493f-b44a-5f8f38542f03	1f2e2ce8-8798-42f2-bec0-744e14bca51c
24c8ae9a-c82f-493f-b44a-5f8f38542f03	44e95148-7ff7-4a12-a28f-2e49be00bb98
24c8ae9a-c82f-493f-b44a-5f8f38542f03	26c9669f-bf10-49df-bab7-c7d222abc082
24c8ae9a-c82f-493f-b44a-5f8f38542f03	b5dd85d2-caea-4053-95fe-a8a813bfa293
24c8ae9a-c82f-493f-b44a-5f8f38542f03	45fbacad-1b42-4318-b7c5-01353f3466b7
24c8ae9a-c82f-493f-b44a-5f8f38542f03	7fd214da-d40e-4f05-8d64-f23b9644c0af
24c8ae9a-c82f-493f-b44a-5f8f38542f03	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
24c8ae9a-c82f-493f-b44a-5f8f38542f03	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
24c8ae9a-c82f-493f-b44a-5f8f38542f03	f8bf3446-59d2-479b-a773-44bb2f17f50b
6b53e881-c542-466e-b77a-f1873f2910c2	156357b5-b39f-4940-85f4-6b58da5ee830
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	c97b29a7-7764-4893-9de9-18e3fee94462
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	b04b6a7e-76a5-4f52-9ece-a163704efa38
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	51234121-4440-4eea-8ba9-9a181f0b39a4
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	b4cd517d-cf3b-4001-bc2d-7109a171dd59
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	c651765c-ad9d-43c2-853a-cc3e595b2713
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	156357b5-b39f-4940-85f4-6b58da5ee830
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	52552512-4b33-47f3-98f5-1f4e60d3a8b1
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	1f2e2ce8-8798-42f2-bec0-744e14bca51c
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	44e95148-7ff7-4a12-a28f-2e49be00bb98
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	83c3b6ae-b146-4ed1-8154-3c13d651ad26
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	e70ff4ad-1601-4af6-9d46-c635a9118437
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	26c9669f-bf10-49df-bab7-c7d222abc082
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	b5dd85d2-caea-4053-95fe-a8a813bfa293
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	45fbacad-1b42-4318-b7c5-01353f3466b7
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	7fd214da-d40e-4f05-8d64-f23b9644c0af
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	f8bf3446-59d2-479b-a773-44bb2f17f50b
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	c97b29a7-7764-4893-9de9-18e3fee94462
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	b04b6a7e-76a5-4f52-9ece-a163704efa38
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	b4cd517d-cf3b-4001-bc2d-7109a171dd59
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	c651765c-ad9d-43c2-853a-cc3e595b2713
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	156357b5-b39f-4940-85f4-6b58da5ee830
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	52552512-4b33-47f3-98f5-1f4e60d3a8b1
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	1f2e2ce8-8798-42f2-bec0-744e14bca51c
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	44e95148-7ff7-4a12-a28f-2e49be00bb98
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	26c9669f-bf10-49df-bab7-c7d222abc082
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	b5dd85d2-caea-4053-95fe-a8a813bfa293
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	45fbacad-1b42-4318-b7c5-01353f3466b7
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	7fd214da-d40e-4f05-8d64-f23b9644c0af
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	f8bf3446-59d2-479b-a773-44bb2f17f50b
2e689e58-3786-4264-a6c5-153841b5dca4	156357b5-b39f-4940-85f4-6b58da5ee830
78653bba-bd97-4d35-bcef-b2583e800502	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
78653bba-bd97-4d35-bcef-b2583e800502	f8bf3446-59d2-479b-a773-44bb2f17f50b
78653bba-bd97-4d35-bcef-b2583e800502	c97b29a7-7764-4893-9de9-18e3fee94462
78653bba-bd97-4d35-bcef-b2583e800502	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
78653bba-bd97-4d35-bcef-b2583e800502	b04b6a7e-76a5-4f52-9ece-a163704efa38
78653bba-bd97-4d35-bcef-b2583e800502	51234121-4440-4eea-8ba9-9a181f0b39a4
78653bba-bd97-4d35-bcef-b2583e800502	b4cd517d-cf3b-4001-bc2d-7109a171dd59
78653bba-bd97-4d35-bcef-b2583e800502	c651765c-ad9d-43c2-853a-cc3e595b2713
78653bba-bd97-4d35-bcef-b2583e800502	156357b5-b39f-4940-85f4-6b58da5ee830
78653bba-bd97-4d35-bcef-b2583e800502	52552512-4b33-47f3-98f5-1f4e60d3a8b1
78653bba-bd97-4d35-bcef-b2583e800502	1f2e2ce8-8798-42f2-bec0-744e14bca51c
78653bba-bd97-4d35-bcef-b2583e800502	44e95148-7ff7-4a12-a28f-2e49be00bb98
78653bba-bd97-4d35-bcef-b2583e800502	83c3b6ae-b146-4ed1-8154-3c13d651ad26
78653bba-bd97-4d35-bcef-b2583e800502	e70ff4ad-1601-4af6-9d46-c635a9118437
78653bba-bd97-4d35-bcef-b2583e800502	26c9669f-bf10-49df-bab7-c7d222abc082
78653bba-bd97-4d35-bcef-b2583e800502	b5dd85d2-caea-4053-95fe-a8a813bfa293
78653bba-bd97-4d35-bcef-b2583e800502	45fbacad-1b42-4318-b7c5-01353f3466b7
78653bba-bd97-4d35-bcef-b2583e800502	7fd214da-d40e-4f05-8d64-f23b9644c0af
78653bba-bd97-4d35-bcef-b2583e800502	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
7cc6517a-684a-4814-be72-886b6852cb89	c97b29a7-7764-4893-9de9-18e3fee94462
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	b04b6a7e-76a5-4f52-9ece-a163704efa38
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	b4cd517d-cf3b-4001-bc2d-7109a171dd59
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	c651765c-ad9d-43c2-853a-cc3e595b2713
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	156357b5-b39f-4940-85f4-6b58da5ee830
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	52552512-4b33-47f3-98f5-1f4e60d3a8b1
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	f8bf3446-59d2-479b-a773-44bb2f17f50b
36a6513b-ad30-45bc-90be-bd09352b2994	c97b29a7-7764-4893-9de9-18e3fee94462
36a6513b-ad30-45bc-90be-bd09352b2994	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
36a6513b-ad30-45bc-90be-bd09352b2994	b04b6a7e-76a5-4f52-9ece-a163704efa38
36a6513b-ad30-45bc-90be-bd09352b2994	b4cd517d-cf3b-4001-bc2d-7109a171dd59
36a6513b-ad30-45bc-90be-bd09352b2994	c651765c-ad9d-43c2-853a-cc3e595b2713
36a6513b-ad30-45bc-90be-bd09352b2994	156357b5-b39f-4940-85f4-6b58da5ee830
36a6513b-ad30-45bc-90be-bd09352b2994	52552512-4b33-47f3-98f5-1f4e60d3a8b1
36a6513b-ad30-45bc-90be-bd09352b2994	f8bf3446-59d2-479b-a773-44bb2f17f50b
ff57d6f5-4c23-4501-9e20-7318a6fca73c	c97b29a7-7764-4893-9de9-18e3fee94462
ff57d6f5-4c23-4501-9e20-7318a6fca73c	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
ff57d6f5-4c23-4501-9e20-7318a6fca73c	b04b6a7e-76a5-4f52-9ece-a163704efa38
ff57d6f5-4c23-4501-9e20-7318a6fca73c	b4cd517d-cf3b-4001-bc2d-7109a171dd59
ff57d6f5-4c23-4501-9e20-7318a6fca73c	c651765c-ad9d-43c2-853a-cc3e595b2713
ff57d6f5-4c23-4501-9e20-7318a6fca73c	156357b5-b39f-4940-85f4-6b58da5ee830
ff57d6f5-4c23-4501-9e20-7318a6fca73c	52552512-4b33-47f3-98f5-1f4e60d3a8b1
ff57d6f5-4c23-4501-9e20-7318a6fca73c	f8bf3446-59d2-479b-a773-44bb2f17f50b
ce939d90-8c66-4235-a31b-7beef1a33d29	f8bf3446-59d2-479b-a773-44bb2f17f50b
2706db66-9e49-4c62-8a89-1c78328508ae	c97b29a7-7764-4893-9de9-18e3fee94462
2706db66-9e49-4c62-8a89-1c78328508ae	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
2706db66-9e49-4c62-8a89-1c78328508ae	b04b6a7e-76a5-4f52-9ece-a163704efa38
2706db66-9e49-4c62-8a89-1c78328508ae	b4cd517d-cf3b-4001-bc2d-7109a171dd59
2706db66-9e49-4c62-8a89-1c78328508ae	c651765c-ad9d-43c2-853a-cc3e595b2713
2706db66-9e49-4c62-8a89-1c78328508ae	156357b5-b39f-4940-85f4-6b58da5ee830
2706db66-9e49-4c62-8a89-1c78328508ae	52552512-4b33-47f3-98f5-1f4e60d3a8b1
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	c97b29a7-7764-4893-9de9-18e3fee94462
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	b04b6a7e-76a5-4f52-9ece-a163704efa38
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	51234121-4440-4eea-8ba9-9a181f0b39a4
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	b4cd517d-cf3b-4001-bc2d-7109a171dd59
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	c651765c-ad9d-43c2-853a-cc3e595b2713
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	156357b5-b39f-4940-85f4-6b58da5ee830
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	52552512-4b33-47f3-98f5-1f4e60d3a8b1
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	1f2e2ce8-8798-42f2-bec0-744e14bca51c
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	44e95148-7ff7-4a12-a28f-2e49be00bb98
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	83c3b6ae-b146-4ed1-8154-3c13d651ad26
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	e70ff4ad-1601-4af6-9d46-c635a9118437
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	26c9669f-bf10-49df-bab7-c7d222abc082
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	b5dd85d2-caea-4053-95fe-a8a813bfa293
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	45fbacad-1b42-4318-b7c5-01353f3466b7
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	7fd214da-d40e-4f05-8d64-f23b9644c0af
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	f8bf3446-59d2-479b-a773-44bb2f17f50b
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	c97b29a7-7764-4893-9de9-18e3fee94462
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	b04b6a7e-76a5-4f52-9ece-a163704efa38
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	b4cd517d-cf3b-4001-bc2d-7109a171dd59
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	c651765c-ad9d-43c2-853a-cc3e595b2713
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	156357b5-b39f-4940-85f4-6b58da5ee830
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	52552512-4b33-47f3-98f5-1f4e60d3a8b1
61e4b9c6-ebc2-49c4-872a-56f7085df0db	c97b29a7-7764-4893-9de9-18e3fee94462
61e4b9c6-ebc2-49c4-872a-56f7085df0db	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
61e4b9c6-ebc2-49c4-872a-56f7085df0db	b04b6a7e-76a5-4f52-9ece-a163704efa38
61e4b9c6-ebc2-49c4-872a-56f7085df0db	b4cd517d-cf3b-4001-bc2d-7109a171dd59
61e4b9c6-ebc2-49c4-872a-56f7085df0db	c651765c-ad9d-43c2-853a-cc3e595b2713
61e4b9c6-ebc2-49c4-872a-56f7085df0db	156357b5-b39f-4940-85f4-6b58da5ee830
61e4b9c6-ebc2-49c4-872a-56f7085df0db	52552512-4b33-47f3-98f5-1f4e60d3a8b1
61e4b9c6-ebc2-49c4-872a-56f7085df0db	f8bf3446-59d2-479b-a773-44bb2f17f50b
971784a0-36da-4f0b-8dfd-af5555f1eeb2	c97b29a7-7764-4893-9de9-18e3fee94462
971784a0-36da-4f0b-8dfd-af5555f1eeb2	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
971784a0-36da-4f0b-8dfd-af5555f1eeb2	b04b6a7e-76a5-4f52-9ece-a163704efa38
971784a0-36da-4f0b-8dfd-af5555f1eeb2	b4cd517d-cf3b-4001-bc2d-7109a171dd59
971784a0-36da-4f0b-8dfd-af5555f1eeb2	c651765c-ad9d-43c2-853a-cc3e595b2713
971784a0-36da-4f0b-8dfd-af5555f1eeb2	156357b5-b39f-4940-85f4-6b58da5ee830
971784a0-36da-4f0b-8dfd-af5555f1eeb2	52552512-4b33-47f3-98f5-1f4e60d3a8b1
971784a0-36da-4f0b-8dfd-af5555f1eeb2	f8bf3446-59d2-479b-a773-44bb2f17f50b
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	c97b29a7-7764-4893-9de9-18e3fee94462
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
323747f5-1d98-4b35-88e8-13b6673715b6	c97b29a7-7764-4893-9de9-18e3fee94462
323747f5-1d98-4b35-88e8-13b6673715b6	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
323747f5-1d98-4b35-88e8-13b6673715b6	b04b6a7e-76a5-4f52-9ece-a163704efa38
323747f5-1d98-4b35-88e8-13b6673715b6	b4cd517d-cf3b-4001-bc2d-7109a171dd59
323747f5-1d98-4b35-88e8-13b6673715b6	c651765c-ad9d-43c2-853a-cc3e595b2713
323747f5-1d98-4b35-88e8-13b6673715b6	156357b5-b39f-4940-85f4-6b58da5ee830
323747f5-1d98-4b35-88e8-13b6673715b6	52552512-4b33-47f3-98f5-1f4e60d3a8b1
323747f5-1d98-4b35-88e8-13b6673715b6	f8bf3446-59d2-479b-a773-44bb2f17f50b
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	b04b6a7e-76a5-4f52-9ece-a163704efa38
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	b4cd517d-cf3b-4001-bc2d-7109a171dd59
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	c651765c-ad9d-43c2-853a-cc3e595b2713
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	156357b5-b39f-4940-85f4-6b58da5ee830
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	52552512-4b33-47f3-98f5-1f4e60d3a8b1
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	f8bf3446-59d2-479b-a773-44bb2f17f50b
de048a83-eec3-4f20-a129-0df23c964503	c97b29a7-7764-4893-9de9-18e3fee94462
de048a83-eec3-4f20-a129-0df23c964503	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
de048a83-eec3-4f20-a129-0df23c964503	b04b6a7e-76a5-4f52-9ece-a163704efa38
de048a83-eec3-4f20-a129-0df23c964503	b4cd517d-cf3b-4001-bc2d-7109a171dd59
de048a83-eec3-4f20-a129-0df23c964503	c651765c-ad9d-43c2-853a-cc3e595b2713
de048a83-eec3-4f20-a129-0df23c964503	156357b5-b39f-4940-85f4-6b58da5ee830
de048a83-eec3-4f20-a129-0df23c964503	52552512-4b33-47f3-98f5-1f4e60d3a8b1
de048a83-eec3-4f20-a129-0df23c964503	f8bf3446-59d2-479b-a773-44bb2f17f50b
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	1f2e2ce8-8798-42f2-bec0-744e14bca51c
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	44e95148-7ff7-4a12-a28f-2e49be00bb98
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	26c9669f-bf10-49df-bab7-c7d222abc082
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	b5dd85d2-caea-4053-95fe-a8a813bfa293
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	45fbacad-1b42-4318-b7c5-01353f3466b7
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	7fd214da-d40e-4f05-8d64-f23b9644c0af
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	f8bf3446-59d2-479b-a773-44bb2f17f50b
d27fc6e5-e731-46c5-bb7c-f77c03a18ace	156357b5-b39f-4940-85f4-6b58da5ee830
4e005b1b-d37b-46f9-a834-bd1a7e689917	c97b29a7-7764-4893-9de9-18e3fee94462
4e005b1b-d37b-46f9-a834-bd1a7e689917	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
4e005b1b-d37b-46f9-a834-bd1a7e689917	b04b6a7e-76a5-4f52-9ece-a163704efa38
4e005b1b-d37b-46f9-a834-bd1a7e689917	b4cd517d-cf3b-4001-bc2d-7109a171dd59
4e005b1b-d37b-46f9-a834-bd1a7e689917	c651765c-ad9d-43c2-853a-cc3e595b2713
4e005b1b-d37b-46f9-a834-bd1a7e689917	156357b5-b39f-4940-85f4-6b58da5ee830
4e005b1b-d37b-46f9-a834-bd1a7e689917	52552512-4b33-47f3-98f5-1f4e60d3a8b1
4e005b1b-d37b-46f9-a834-bd1a7e689917	f8bf3446-59d2-479b-a773-44bb2f17f50b
225de02f-4f0e-406a-9ed6-6524dd5a3dda	c97b29a7-7764-4893-9de9-18e3fee94462
225de02f-4f0e-406a-9ed6-6524dd5a3dda	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
225de02f-4f0e-406a-9ed6-6524dd5a3dda	b04b6a7e-76a5-4f52-9ece-a163704efa38
225de02f-4f0e-406a-9ed6-6524dd5a3dda	b4cd517d-cf3b-4001-bc2d-7109a171dd59
225de02f-4f0e-406a-9ed6-6524dd5a3dda	c651765c-ad9d-43c2-853a-cc3e595b2713
225de02f-4f0e-406a-9ed6-6524dd5a3dda	156357b5-b39f-4940-85f4-6b58da5ee830
225de02f-4f0e-406a-9ed6-6524dd5a3dda	52552512-4b33-47f3-98f5-1f4e60d3a8b1
225de02f-4f0e-406a-9ed6-6524dd5a3dda	f8bf3446-59d2-479b-a773-44bb2f17f50b
8a452d14-2cc7-452e-ae56-fa1cd72695c1	c97b29a7-7764-4893-9de9-18e3fee94462
8a452d14-2cc7-452e-ae56-fa1cd72695c1	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
8a452d14-2cc7-452e-ae56-fa1cd72695c1	b04b6a7e-76a5-4f52-9ece-a163704efa38
8a452d14-2cc7-452e-ae56-fa1cd72695c1	51234121-4440-4eea-8ba9-9a181f0b39a4
8a452d14-2cc7-452e-ae56-fa1cd72695c1	b4cd517d-cf3b-4001-bc2d-7109a171dd59
8a452d14-2cc7-452e-ae56-fa1cd72695c1	c651765c-ad9d-43c2-853a-cc3e595b2713
8a452d14-2cc7-452e-ae56-fa1cd72695c1	156357b5-b39f-4940-85f4-6b58da5ee830
8a452d14-2cc7-452e-ae56-fa1cd72695c1	52552512-4b33-47f3-98f5-1f4e60d3a8b1
8a452d14-2cc7-452e-ae56-fa1cd72695c1	1f2e2ce8-8798-42f2-bec0-744e14bca51c
8a452d14-2cc7-452e-ae56-fa1cd72695c1	44e95148-7ff7-4a12-a28f-2e49be00bb98
8a452d14-2cc7-452e-ae56-fa1cd72695c1	83c3b6ae-b146-4ed1-8154-3c13d651ad26
7cc6517a-684a-4814-be72-886b6852cb89	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
7cc6517a-684a-4814-be72-886b6852cb89	b04b6a7e-76a5-4f52-9ece-a163704efa38
7cc6517a-684a-4814-be72-886b6852cb89	b4cd517d-cf3b-4001-bc2d-7109a171dd59
7cc6517a-684a-4814-be72-886b6852cb89	c651765c-ad9d-43c2-853a-cc3e595b2713
7cc6517a-684a-4814-be72-886b6852cb89	156357b5-b39f-4940-85f4-6b58da5ee830
7cc6517a-684a-4814-be72-886b6852cb89	52552512-4b33-47f3-98f5-1f4e60d3a8b1
7cc6517a-684a-4814-be72-886b6852cb89	1f2e2ce8-8798-42f2-bec0-744e14bca51c
7cc6517a-684a-4814-be72-886b6852cb89	44e95148-7ff7-4a12-a28f-2e49be00bb98
7cc6517a-684a-4814-be72-886b6852cb89	26c9669f-bf10-49df-bab7-c7d222abc082
7cc6517a-684a-4814-be72-886b6852cb89	b5dd85d2-caea-4053-95fe-a8a813bfa293
7cc6517a-684a-4814-be72-886b6852cb89	45fbacad-1b42-4318-b7c5-01353f3466b7
7cc6517a-684a-4814-be72-886b6852cb89	7fd214da-d40e-4f05-8d64-f23b9644c0af
7cc6517a-684a-4814-be72-886b6852cb89	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
7cc6517a-684a-4814-be72-886b6852cb89	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
7cc6517a-684a-4814-be72-886b6852cb89	f8bf3446-59d2-479b-a773-44bb2f17f50b
df41cd2e-fee0-4e0a-ac5c-bf0718bb63ae	156357b5-b39f-4940-85f4-6b58da5ee830
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	f8bf3446-59d2-479b-a773-44bb2f17f50b
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	c97b29a7-7764-4893-9de9-18e3fee94462
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	b04b6a7e-76a5-4f52-9ece-a163704efa38
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	51234121-4440-4eea-8ba9-9a181f0b39a4
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	b4cd517d-cf3b-4001-bc2d-7109a171dd59
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	c651765c-ad9d-43c2-853a-cc3e595b2713
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	156357b5-b39f-4940-85f4-6b58da5ee830
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	52552512-4b33-47f3-98f5-1f4e60d3a8b1
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	1f2e2ce8-8798-42f2-bec0-744e14bca51c
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	44e95148-7ff7-4a12-a28f-2e49be00bb98
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	83c3b6ae-b146-4ed1-8154-3c13d651ad26
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	e70ff4ad-1601-4af6-9d46-c635a9118437
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	26c9669f-bf10-49df-bab7-c7d222abc082
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	b5dd85d2-caea-4053-95fe-a8a813bfa293
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	45fbacad-1b42-4318-b7c5-01353f3466b7
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	7fd214da-d40e-4f05-8d64-f23b9644c0af
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
a585a67a-51eb-4c03-8c32-dd6564a9a099	c97b29a7-7764-4893-9de9-18e3fee94462
a585a67a-51eb-4c03-8c32-dd6564a9a099	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
a585a67a-51eb-4c03-8c32-dd6564a9a099	b04b6a7e-76a5-4f52-9ece-a163704efa38
a585a67a-51eb-4c03-8c32-dd6564a9a099	b4cd517d-cf3b-4001-bc2d-7109a171dd59
a585a67a-51eb-4c03-8c32-dd6564a9a099	c651765c-ad9d-43c2-853a-cc3e595b2713
a585a67a-51eb-4c03-8c32-dd6564a9a099	156357b5-b39f-4940-85f4-6b58da5ee830
a585a67a-51eb-4c03-8c32-dd6564a9a099	52552512-4b33-47f3-98f5-1f4e60d3a8b1
a585a67a-51eb-4c03-8c32-dd6564a9a099	1f2e2ce8-8798-42f2-bec0-744e14bca51c
a585a67a-51eb-4c03-8c32-dd6564a9a099	44e95148-7ff7-4a12-a28f-2e49be00bb98
a585a67a-51eb-4c03-8c32-dd6564a9a099	26c9669f-bf10-49df-bab7-c7d222abc082
a585a67a-51eb-4c03-8c32-dd6564a9a099	b5dd85d2-caea-4053-95fe-a8a813bfa293
a585a67a-51eb-4c03-8c32-dd6564a9a099	45fbacad-1b42-4318-b7c5-01353f3466b7
a585a67a-51eb-4c03-8c32-dd6564a9a099	7fd214da-d40e-4f05-8d64-f23b9644c0af
a585a67a-51eb-4c03-8c32-dd6564a9a099	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
a585a67a-51eb-4c03-8c32-dd6564a9a099	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
a585a67a-51eb-4c03-8c32-dd6564a9a099	f8bf3446-59d2-479b-a773-44bb2f17f50b
0a811a12-2fa1-49cc-8ca6-3ee0fb4f8523	156357b5-b39f-4940-85f4-6b58da5ee830
6824152d-d3c2-43a8-b23a-189adbe8ffa3	c97b29a7-7764-4893-9de9-18e3fee94462
6824152d-d3c2-43a8-b23a-189adbe8ffa3	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
6824152d-d3c2-43a8-b23a-189adbe8ffa3	b04b6a7e-76a5-4f52-9ece-a163704efa38
6824152d-d3c2-43a8-b23a-189adbe8ffa3	51234121-4440-4eea-8ba9-9a181f0b39a4
6824152d-d3c2-43a8-b23a-189adbe8ffa3	b4cd517d-cf3b-4001-bc2d-7109a171dd59
6824152d-d3c2-43a8-b23a-189adbe8ffa3	c651765c-ad9d-43c2-853a-cc3e595b2713
6824152d-d3c2-43a8-b23a-189adbe8ffa3	156357b5-b39f-4940-85f4-6b58da5ee830
6824152d-d3c2-43a8-b23a-189adbe8ffa3	52552512-4b33-47f3-98f5-1f4e60d3a8b1
6824152d-d3c2-43a8-b23a-189adbe8ffa3	1f2e2ce8-8798-42f2-bec0-744e14bca51c
6824152d-d3c2-43a8-b23a-189adbe8ffa3	44e95148-7ff7-4a12-a28f-2e49be00bb98
6824152d-d3c2-43a8-b23a-189adbe8ffa3	83c3b6ae-b146-4ed1-8154-3c13d651ad26
6824152d-d3c2-43a8-b23a-189adbe8ffa3	e70ff4ad-1601-4af6-9d46-c635a9118437
6824152d-d3c2-43a8-b23a-189adbe8ffa3	26c9669f-bf10-49df-bab7-c7d222abc082
6824152d-d3c2-43a8-b23a-189adbe8ffa3	b5dd85d2-caea-4053-95fe-a8a813bfa293
6824152d-d3c2-43a8-b23a-189adbe8ffa3	45fbacad-1b42-4318-b7c5-01353f3466b7
6824152d-d3c2-43a8-b23a-189adbe8ffa3	7fd214da-d40e-4f05-8d64-f23b9644c0af
6824152d-d3c2-43a8-b23a-189adbe8ffa3	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
6824152d-d3c2-43a8-b23a-189adbe8ffa3	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
6824152d-d3c2-43a8-b23a-189adbe8ffa3	f8bf3446-59d2-479b-a773-44bb2f17f50b
4e713e8b-86b0-4f77-a93f-a3044be417ce	c97b29a7-7764-4893-9de9-18e3fee94462
4e713e8b-86b0-4f77-a93f-a3044be417ce	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
4e713e8b-86b0-4f77-a93f-a3044be417ce	b04b6a7e-76a5-4f52-9ece-a163704efa38
4e713e8b-86b0-4f77-a93f-a3044be417ce	b4cd517d-cf3b-4001-bc2d-7109a171dd59
4e713e8b-86b0-4f77-a93f-a3044be417ce	c651765c-ad9d-43c2-853a-cc3e595b2713
4e713e8b-86b0-4f77-a93f-a3044be417ce	156357b5-b39f-4940-85f4-6b58da5ee830
4e713e8b-86b0-4f77-a93f-a3044be417ce	52552512-4b33-47f3-98f5-1f4e60d3a8b1
4e713e8b-86b0-4f77-a93f-a3044be417ce	1f2e2ce8-8798-42f2-bec0-744e14bca51c
4e713e8b-86b0-4f77-a93f-a3044be417ce	44e95148-7ff7-4a12-a28f-2e49be00bb98
4e713e8b-86b0-4f77-a93f-a3044be417ce	26c9669f-bf10-49df-bab7-c7d222abc082
4e713e8b-86b0-4f77-a93f-a3044be417ce	b5dd85d2-caea-4053-95fe-a8a813bfa293
4e713e8b-86b0-4f77-a93f-a3044be417ce	45fbacad-1b42-4318-b7c5-01353f3466b7
4e713e8b-86b0-4f77-a93f-a3044be417ce	7fd214da-d40e-4f05-8d64-f23b9644c0af
4e713e8b-86b0-4f77-a93f-a3044be417ce	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
4e713e8b-86b0-4f77-a93f-a3044be417ce	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
4e713e8b-86b0-4f77-a93f-a3044be417ce	f8bf3446-59d2-479b-a773-44bb2f17f50b
fba11cae-715d-41b8-997f-7ebef2def202	156357b5-b39f-4940-85f4-6b58da5ee830
380f1e42-a55b-419c-9351-3ff2b8bb0e79	c97b29a7-7764-4893-9de9-18e3fee94462
380f1e42-a55b-419c-9351-3ff2b8bb0e79	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
380f1e42-a55b-419c-9351-3ff2b8bb0e79	b04b6a7e-76a5-4f52-9ece-a163704efa38
380f1e42-a55b-419c-9351-3ff2b8bb0e79	51234121-4440-4eea-8ba9-9a181f0b39a4
380f1e42-a55b-419c-9351-3ff2b8bb0e79	b4cd517d-cf3b-4001-bc2d-7109a171dd59
380f1e42-a55b-419c-9351-3ff2b8bb0e79	c651765c-ad9d-43c2-853a-cc3e595b2713
380f1e42-a55b-419c-9351-3ff2b8bb0e79	156357b5-b39f-4940-85f4-6b58da5ee830
380f1e42-a55b-419c-9351-3ff2b8bb0e79	52552512-4b33-47f3-98f5-1f4e60d3a8b1
380f1e42-a55b-419c-9351-3ff2b8bb0e79	1f2e2ce8-8798-42f2-bec0-744e14bca51c
380f1e42-a55b-419c-9351-3ff2b8bb0e79	44e95148-7ff7-4a12-a28f-2e49be00bb98
380f1e42-a55b-419c-9351-3ff2b8bb0e79	83c3b6ae-b146-4ed1-8154-3c13d651ad26
380f1e42-a55b-419c-9351-3ff2b8bb0e79	e70ff4ad-1601-4af6-9d46-c635a9118437
380f1e42-a55b-419c-9351-3ff2b8bb0e79	26c9669f-bf10-49df-bab7-c7d222abc082
380f1e42-a55b-419c-9351-3ff2b8bb0e79	b5dd85d2-caea-4053-95fe-a8a813bfa293
380f1e42-a55b-419c-9351-3ff2b8bb0e79	45fbacad-1b42-4318-b7c5-01353f3466b7
380f1e42-a55b-419c-9351-3ff2b8bb0e79	7fd214da-d40e-4f05-8d64-f23b9644c0af
380f1e42-a55b-419c-9351-3ff2b8bb0e79	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
380f1e42-a55b-419c-9351-3ff2b8bb0e79	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
380f1e42-a55b-419c-9351-3ff2b8bb0e79	f8bf3446-59d2-479b-a773-44bb2f17f50b
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	c97b29a7-7764-4893-9de9-18e3fee94462
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	b04b6a7e-76a5-4f52-9ece-a163704efa38
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	b4cd517d-cf3b-4001-bc2d-7109a171dd59
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	c651765c-ad9d-43c2-853a-cc3e595b2713
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	156357b5-b39f-4940-85f4-6b58da5ee830
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	52552512-4b33-47f3-98f5-1f4e60d3a8b1
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	1f2e2ce8-8798-42f2-bec0-744e14bca51c
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	44e95148-7ff7-4a12-a28f-2e49be00bb98
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	26c9669f-bf10-49df-bab7-c7d222abc082
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	b5dd85d2-caea-4053-95fe-a8a813bfa293
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	45fbacad-1b42-4318-b7c5-01353f3466b7
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	7fd214da-d40e-4f05-8d64-f23b9644c0af
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	f8bf3446-59d2-479b-a773-44bb2f17f50b
3ea4c518-0514-4b80-a547-42b9faa8080c	156357b5-b39f-4940-85f4-6b58da5ee830
9c9439fd-b33f-4294-9cd2-a5ca3175e606	c97b29a7-7764-4893-9de9-18e3fee94462
9c9439fd-b33f-4294-9cd2-a5ca3175e606	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
9c9439fd-b33f-4294-9cd2-a5ca3175e606	b04b6a7e-76a5-4f52-9ece-a163704efa38
9c9439fd-b33f-4294-9cd2-a5ca3175e606	51234121-4440-4eea-8ba9-9a181f0b39a4
9c9439fd-b33f-4294-9cd2-a5ca3175e606	b4cd517d-cf3b-4001-bc2d-7109a171dd59
9c9439fd-b33f-4294-9cd2-a5ca3175e606	c651765c-ad9d-43c2-853a-cc3e595b2713
9c9439fd-b33f-4294-9cd2-a5ca3175e606	156357b5-b39f-4940-85f4-6b58da5ee830
9c9439fd-b33f-4294-9cd2-a5ca3175e606	52552512-4b33-47f3-98f5-1f4e60d3a8b1
9c9439fd-b33f-4294-9cd2-a5ca3175e606	1f2e2ce8-8798-42f2-bec0-744e14bca51c
9c9439fd-b33f-4294-9cd2-a5ca3175e606	44e95148-7ff7-4a12-a28f-2e49be00bb98
9c9439fd-b33f-4294-9cd2-a5ca3175e606	83c3b6ae-b146-4ed1-8154-3c13d651ad26
9c9439fd-b33f-4294-9cd2-a5ca3175e606	e70ff4ad-1601-4af6-9d46-c635a9118437
9c9439fd-b33f-4294-9cd2-a5ca3175e606	26c9669f-bf10-49df-bab7-c7d222abc082
9c9439fd-b33f-4294-9cd2-a5ca3175e606	b5dd85d2-caea-4053-95fe-a8a813bfa293
9c9439fd-b33f-4294-9cd2-a5ca3175e606	45fbacad-1b42-4318-b7c5-01353f3466b7
9c9439fd-b33f-4294-9cd2-a5ca3175e606	7fd214da-d40e-4f05-8d64-f23b9644c0af
9c9439fd-b33f-4294-9cd2-a5ca3175e606	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
9c9439fd-b33f-4294-9cd2-a5ca3175e606	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
9c9439fd-b33f-4294-9cd2-a5ca3175e606	f8bf3446-59d2-479b-a773-44bb2f17f50b
67f0bafb-e1b8-4881-aa21-decb8a923e56	c97b29a7-7764-4893-9de9-18e3fee94462
67f0bafb-e1b8-4881-aa21-decb8a923e56	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
67f0bafb-e1b8-4881-aa21-decb8a923e56	b04b6a7e-76a5-4f52-9ece-a163704efa38
67f0bafb-e1b8-4881-aa21-decb8a923e56	b4cd517d-cf3b-4001-bc2d-7109a171dd59
67f0bafb-e1b8-4881-aa21-decb8a923e56	c651765c-ad9d-43c2-853a-cc3e595b2713
67f0bafb-e1b8-4881-aa21-decb8a923e56	156357b5-b39f-4940-85f4-6b58da5ee830
67f0bafb-e1b8-4881-aa21-decb8a923e56	52552512-4b33-47f3-98f5-1f4e60d3a8b1
67f0bafb-e1b8-4881-aa21-decb8a923e56	1f2e2ce8-8798-42f2-bec0-744e14bca51c
67f0bafb-e1b8-4881-aa21-decb8a923e56	44e95148-7ff7-4a12-a28f-2e49be00bb98
67f0bafb-e1b8-4881-aa21-decb8a923e56	26c9669f-bf10-49df-bab7-c7d222abc082
67f0bafb-e1b8-4881-aa21-decb8a923e56	b5dd85d2-caea-4053-95fe-a8a813bfa293
67f0bafb-e1b8-4881-aa21-decb8a923e56	45fbacad-1b42-4318-b7c5-01353f3466b7
67f0bafb-e1b8-4881-aa21-decb8a923e56	7fd214da-d40e-4f05-8d64-f23b9644c0af
67f0bafb-e1b8-4881-aa21-decb8a923e56	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
67f0bafb-e1b8-4881-aa21-decb8a923e56	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
67f0bafb-e1b8-4881-aa21-decb8a923e56	f8bf3446-59d2-479b-a773-44bb2f17f50b
85b63c45-8255-4cfe-87f6-8670c7fac862	156357b5-b39f-4940-85f4-6b58da5ee830
669d9173-d488-40a6-a075-318f30e31250	c97b29a7-7764-4893-9de9-18e3fee94462
669d9173-d488-40a6-a075-318f30e31250	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
669d9173-d488-40a6-a075-318f30e31250	b04b6a7e-76a5-4f52-9ece-a163704efa38
669d9173-d488-40a6-a075-318f30e31250	51234121-4440-4eea-8ba9-9a181f0b39a4
669d9173-d488-40a6-a075-318f30e31250	b4cd517d-cf3b-4001-bc2d-7109a171dd59
669d9173-d488-40a6-a075-318f30e31250	c651765c-ad9d-43c2-853a-cc3e595b2713
669d9173-d488-40a6-a075-318f30e31250	156357b5-b39f-4940-85f4-6b58da5ee830
669d9173-d488-40a6-a075-318f30e31250	52552512-4b33-47f3-98f5-1f4e60d3a8b1
669d9173-d488-40a6-a075-318f30e31250	1f2e2ce8-8798-42f2-bec0-744e14bca51c
669d9173-d488-40a6-a075-318f30e31250	44e95148-7ff7-4a12-a28f-2e49be00bb98
669d9173-d488-40a6-a075-318f30e31250	83c3b6ae-b146-4ed1-8154-3c13d651ad26
669d9173-d488-40a6-a075-318f30e31250	e70ff4ad-1601-4af6-9d46-c635a9118437
669d9173-d488-40a6-a075-318f30e31250	26c9669f-bf10-49df-bab7-c7d222abc082
669d9173-d488-40a6-a075-318f30e31250	b5dd85d2-caea-4053-95fe-a8a813bfa293
669d9173-d488-40a6-a075-318f30e31250	45fbacad-1b42-4318-b7c5-01353f3466b7
669d9173-d488-40a6-a075-318f30e31250	7fd214da-d40e-4f05-8d64-f23b9644c0af
669d9173-d488-40a6-a075-318f30e31250	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
669d9173-d488-40a6-a075-318f30e31250	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
669d9173-d488-40a6-a075-318f30e31250	f8bf3446-59d2-479b-a773-44bb2f17f50b
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	c97b29a7-7764-4893-9de9-18e3fee94462
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	b04b6a7e-76a5-4f52-9ece-a163704efa38
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	b4cd517d-cf3b-4001-bc2d-7109a171dd59
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	c651765c-ad9d-43c2-853a-cc3e595b2713
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	156357b5-b39f-4940-85f4-6b58da5ee830
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	52552512-4b33-47f3-98f5-1f4e60d3a8b1
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	1f2e2ce8-8798-42f2-bec0-744e14bca51c
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	44e95148-7ff7-4a12-a28f-2e49be00bb98
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	26c9669f-bf10-49df-bab7-c7d222abc082
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	b5dd85d2-caea-4053-95fe-a8a813bfa293
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	45fbacad-1b42-4318-b7c5-01353f3466b7
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	7fd214da-d40e-4f05-8d64-f23b9644c0af
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	f8bf3446-59d2-479b-a773-44bb2f17f50b
7bc70e54-a1fc-4ebf-988d-f75ef4c859f7	156357b5-b39f-4940-85f4-6b58da5ee830
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	c97b29a7-7764-4893-9de9-18e3fee94462
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	b04b6a7e-76a5-4f52-9ece-a163704efa38
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	b4cd517d-cf3b-4001-bc2d-7109a171dd59
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	c651765c-ad9d-43c2-853a-cc3e595b2713
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	156357b5-b39f-4940-85f4-6b58da5ee830
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	52552512-4b33-47f3-98f5-1f4e60d3a8b1
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	f8bf3446-59d2-479b-a773-44bb2f17f50b
bbb2c358-1b37-48d1-bd85-f8a097344680	c97b29a7-7764-4893-9de9-18e3fee94462
bbb2c358-1b37-48d1-bd85-f8a097344680	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
bbb2c358-1b37-48d1-bd85-f8a097344680	b04b6a7e-76a5-4f52-9ece-a163704efa38
bbb2c358-1b37-48d1-bd85-f8a097344680	b4cd517d-cf3b-4001-bc2d-7109a171dd59
bbb2c358-1b37-48d1-bd85-f8a097344680	c651765c-ad9d-43c2-853a-cc3e595b2713
bbb2c358-1b37-48d1-bd85-f8a097344680	156357b5-b39f-4940-85f4-6b58da5ee830
bbb2c358-1b37-48d1-bd85-f8a097344680	52552512-4b33-47f3-98f5-1f4e60d3a8b1
bbb2c358-1b37-48d1-bd85-f8a097344680	f8bf3446-59d2-479b-a773-44bb2f17f50b
2706db66-9e49-4c62-8a89-1c78328508ae	f8bf3446-59d2-479b-a773-44bb2f17f50b
1682b3f9-e252-4568-9326-71a8ad1bac6e	c97b29a7-7764-4893-9de9-18e3fee94462
1682b3f9-e252-4568-9326-71a8ad1bac6e	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
1682b3f9-e252-4568-9326-71a8ad1bac6e	b04b6a7e-76a5-4f52-9ece-a163704efa38
1682b3f9-e252-4568-9326-71a8ad1bac6e	51234121-4440-4eea-8ba9-9a181f0b39a4
1682b3f9-e252-4568-9326-71a8ad1bac6e	b4cd517d-cf3b-4001-bc2d-7109a171dd59
1682b3f9-e252-4568-9326-71a8ad1bac6e	c651765c-ad9d-43c2-853a-cc3e595b2713
1682b3f9-e252-4568-9326-71a8ad1bac6e	156357b5-b39f-4940-85f4-6b58da5ee830
1682b3f9-e252-4568-9326-71a8ad1bac6e	52552512-4b33-47f3-98f5-1f4e60d3a8b1
1682b3f9-e252-4568-9326-71a8ad1bac6e	1f2e2ce8-8798-42f2-bec0-744e14bca51c
1682b3f9-e252-4568-9326-71a8ad1bac6e	44e95148-7ff7-4a12-a28f-2e49be00bb98
1682b3f9-e252-4568-9326-71a8ad1bac6e	83c3b6ae-b146-4ed1-8154-3c13d651ad26
1682b3f9-e252-4568-9326-71a8ad1bac6e	e70ff4ad-1601-4af6-9d46-c635a9118437
1682b3f9-e252-4568-9326-71a8ad1bac6e	26c9669f-bf10-49df-bab7-c7d222abc082
1682b3f9-e252-4568-9326-71a8ad1bac6e	b5dd85d2-caea-4053-95fe-a8a813bfa293
1682b3f9-e252-4568-9326-71a8ad1bac6e	45fbacad-1b42-4318-b7c5-01353f3466b7
1682b3f9-e252-4568-9326-71a8ad1bac6e	7fd214da-d40e-4f05-8d64-f23b9644c0af
1682b3f9-e252-4568-9326-71a8ad1bac6e	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
1682b3f9-e252-4568-9326-71a8ad1bac6e	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
1682b3f9-e252-4568-9326-71a8ad1bac6e	f8bf3446-59d2-479b-a773-44bb2f17f50b
5c9f93da-100f-42f2-a5c9-92175d86ab7c	c97b29a7-7764-4893-9de9-18e3fee94462
5c9f93da-100f-42f2-a5c9-92175d86ab7c	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
5c9f93da-100f-42f2-a5c9-92175d86ab7c	b04b6a7e-76a5-4f52-9ece-a163704efa38
5c9f93da-100f-42f2-a5c9-92175d86ab7c	b4cd517d-cf3b-4001-bc2d-7109a171dd59
5c9f93da-100f-42f2-a5c9-92175d86ab7c	c651765c-ad9d-43c2-853a-cc3e595b2713
5c9f93da-100f-42f2-a5c9-92175d86ab7c	156357b5-b39f-4940-85f4-6b58da5ee830
5c9f93da-100f-42f2-a5c9-92175d86ab7c	52552512-4b33-47f3-98f5-1f4e60d3a8b1
5c9f93da-100f-42f2-a5c9-92175d86ab7c	f8bf3446-59d2-479b-a773-44bb2f17f50b
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	c97b29a7-7764-4893-9de9-18e3fee94462
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	b04b6a7e-76a5-4f52-9ece-a163704efa38
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	b4cd517d-cf3b-4001-bc2d-7109a171dd59
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	c651765c-ad9d-43c2-853a-cc3e595b2713
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	156357b5-b39f-4940-85f4-6b58da5ee830
258eb3eb-7195-4f09-ab45-33dd488e92ca	c97b29a7-7764-4893-9de9-18e3fee94462
258eb3eb-7195-4f09-ab45-33dd488e92ca	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
258eb3eb-7195-4f09-ab45-33dd488e92ca	b04b6a7e-76a5-4f52-9ece-a163704efa38
258eb3eb-7195-4f09-ab45-33dd488e92ca	b4cd517d-cf3b-4001-bc2d-7109a171dd59
258eb3eb-7195-4f09-ab45-33dd488e92ca	c651765c-ad9d-43c2-853a-cc3e595b2713
258eb3eb-7195-4f09-ab45-33dd488e92ca	156357b5-b39f-4940-85f4-6b58da5ee830
258eb3eb-7195-4f09-ab45-33dd488e92ca	52552512-4b33-47f3-98f5-1f4e60d3a8b1
258eb3eb-7195-4f09-ab45-33dd488e92ca	f8bf3446-59d2-479b-a773-44bb2f17f50b
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	52552512-4b33-47f3-98f5-1f4e60d3a8b1
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	f8bf3446-59d2-479b-a773-44bb2f17f50b
26e28e80-50aa-404b-a833-e1b1e7f442b8	c97b29a7-7764-4893-9de9-18e3fee94462
26e28e80-50aa-404b-a833-e1b1e7f442b8	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
26e28e80-50aa-404b-a833-e1b1e7f442b8	b04b6a7e-76a5-4f52-9ece-a163704efa38
26e28e80-50aa-404b-a833-e1b1e7f442b8	b4cd517d-cf3b-4001-bc2d-7109a171dd59
26e28e80-50aa-404b-a833-e1b1e7f442b8	c651765c-ad9d-43c2-853a-cc3e595b2713
26e28e80-50aa-404b-a833-e1b1e7f442b8	156357b5-b39f-4940-85f4-6b58da5ee830
26e28e80-50aa-404b-a833-e1b1e7f442b8	52552512-4b33-47f3-98f5-1f4e60d3a8b1
26e28e80-50aa-404b-a833-e1b1e7f442b8	f8bf3446-59d2-479b-a773-44bb2f17f50b
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	83c3b6ae-b146-4ed1-8154-3c13d651ad26
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	c97b29a7-7764-4893-9de9-18e3fee94462
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	b04b6a7e-76a5-4f52-9ece-a163704efa38
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	b4cd517d-cf3b-4001-bc2d-7109a171dd59
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	c651765c-ad9d-43c2-853a-cc3e595b2713
61c08b33-a61f-42da-bb0f-8f82c787becb	c97b29a7-7764-4893-9de9-18e3fee94462
61c08b33-a61f-42da-bb0f-8f82c787becb	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
61c08b33-a61f-42da-bb0f-8f82c787becb	b04b6a7e-76a5-4f52-9ece-a163704efa38
61c08b33-a61f-42da-bb0f-8f82c787becb	51234121-4440-4eea-8ba9-9a181f0b39a4
61c08b33-a61f-42da-bb0f-8f82c787becb	b4cd517d-cf3b-4001-bc2d-7109a171dd59
61c08b33-a61f-42da-bb0f-8f82c787becb	c651765c-ad9d-43c2-853a-cc3e595b2713
61c08b33-a61f-42da-bb0f-8f82c787becb	156357b5-b39f-4940-85f4-6b58da5ee830
61c08b33-a61f-42da-bb0f-8f82c787becb	52552512-4b33-47f3-98f5-1f4e60d3a8b1
61c08b33-a61f-42da-bb0f-8f82c787becb	1f2e2ce8-8798-42f2-bec0-744e14bca51c
61c08b33-a61f-42da-bb0f-8f82c787becb	44e95148-7ff7-4a12-a28f-2e49be00bb98
61c08b33-a61f-42da-bb0f-8f82c787becb	83c3b6ae-b146-4ed1-8154-3c13d651ad26
61c08b33-a61f-42da-bb0f-8f82c787becb	e70ff4ad-1601-4af6-9d46-c635a9118437
61c08b33-a61f-42da-bb0f-8f82c787becb	26c9669f-bf10-49df-bab7-c7d222abc082
61c08b33-a61f-42da-bb0f-8f82c787becb	b5dd85d2-caea-4053-95fe-a8a813bfa293
61c08b33-a61f-42da-bb0f-8f82c787becb	45fbacad-1b42-4318-b7c5-01353f3466b7
61c08b33-a61f-42da-bb0f-8f82c787becb	7fd214da-d40e-4f05-8d64-f23b9644c0af
61c08b33-a61f-42da-bb0f-8f82c787becb	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
61c08b33-a61f-42da-bb0f-8f82c787becb	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
61c08b33-a61f-42da-bb0f-8f82c787becb	f8bf3446-59d2-479b-a773-44bb2f17f50b
5e15cb39-93b2-4f61-af6a-70d7e952fba6	c97b29a7-7764-4893-9de9-18e3fee94462
5e15cb39-93b2-4f61-af6a-70d7e952fba6	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
5e15cb39-93b2-4f61-af6a-70d7e952fba6	b04b6a7e-76a5-4f52-9ece-a163704efa38
664f88a8-c509-47e4-8e4a-3705d78ad451	c97b29a7-7764-4893-9de9-18e3fee94462
664f88a8-c509-47e4-8e4a-3705d78ad451	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
664f88a8-c509-47e4-8e4a-3705d78ad451	b04b6a7e-76a5-4f52-9ece-a163704efa38
664f88a8-c509-47e4-8e4a-3705d78ad451	b4cd517d-cf3b-4001-bc2d-7109a171dd59
664f88a8-c509-47e4-8e4a-3705d78ad451	c651765c-ad9d-43c2-853a-cc3e595b2713
664f88a8-c509-47e4-8e4a-3705d78ad451	156357b5-b39f-4940-85f4-6b58da5ee830
664f88a8-c509-47e4-8e4a-3705d78ad451	52552512-4b33-47f3-98f5-1f4e60d3a8b1
664f88a8-c509-47e4-8e4a-3705d78ad451	f8bf3446-59d2-479b-a773-44bb2f17f50b
5e15cb39-93b2-4f61-af6a-70d7e952fba6	b4cd517d-cf3b-4001-bc2d-7109a171dd59
5e15cb39-93b2-4f61-af6a-70d7e952fba6	c651765c-ad9d-43c2-853a-cc3e595b2713
5e15cb39-93b2-4f61-af6a-70d7e952fba6	156357b5-b39f-4940-85f4-6b58da5ee830
5e15cb39-93b2-4f61-af6a-70d7e952fba6	52552512-4b33-47f3-98f5-1f4e60d3a8b1
5e15cb39-93b2-4f61-af6a-70d7e952fba6	1f2e2ce8-8798-42f2-bec0-744e14bca51c
5e15cb39-93b2-4f61-af6a-70d7e952fba6	44e95148-7ff7-4a12-a28f-2e49be00bb98
5e15cb39-93b2-4f61-af6a-70d7e952fba6	26c9669f-bf10-49df-bab7-c7d222abc082
5e15cb39-93b2-4f61-af6a-70d7e952fba6	b5dd85d2-caea-4053-95fe-a8a813bfa293
5e15cb39-93b2-4f61-af6a-70d7e952fba6	45fbacad-1b42-4318-b7c5-01353f3466b7
5e15cb39-93b2-4f61-af6a-70d7e952fba6	7fd214da-d40e-4f05-8d64-f23b9644c0af
5e15cb39-93b2-4f61-af6a-70d7e952fba6	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
5e15cb39-93b2-4f61-af6a-70d7e952fba6	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
5e15cb39-93b2-4f61-af6a-70d7e952fba6	f8bf3446-59d2-479b-a773-44bb2f17f50b
800b0b99-3cf5-4281-a7e3-9585ed707b1b	156357b5-b39f-4940-85f4-6b58da5ee830
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	156357b5-b39f-4940-85f4-6b58da5ee830
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	52552512-4b33-47f3-98f5-1f4e60d3a8b1
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	1f2e2ce8-8798-42f2-bec0-744e14bca51c
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	44e95148-7ff7-4a12-a28f-2e49be00bb98
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	26c9669f-bf10-49df-bab7-c7d222abc082
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	b5dd85d2-caea-4053-95fe-a8a813bfa293
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	45fbacad-1b42-4318-b7c5-01353f3466b7
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	7fd214da-d40e-4f05-8d64-f23b9644c0af
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	f8bf3446-59d2-479b-a773-44bb2f17f50b
b8ce9e6d-f9e2-4d2c-b546-161ed18ed509	156357b5-b39f-4940-85f4-6b58da5ee830
9e39bf13-9d8a-437a-96d1-32177d0707c1	c97b29a7-7764-4893-9de9-18e3fee94462
9e39bf13-9d8a-437a-96d1-32177d0707c1	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
9e39bf13-9d8a-437a-96d1-32177d0707c1	b04b6a7e-76a5-4f52-9ece-a163704efa38
9e39bf13-9d8a-437a-96d1-32177d0707c1	b4cd517d-cf3b-4001-bc2d-7109a171dd59
9e39bf13-9d8a-437a-96d1-32177d0707c1	c651765c-ad9d-43c2-853a-cc3e595b2713
9e39bf13-9d8a-437a-96d1-32177d0707c1	156357b5-b39f-4940-85f4-6b58da5ee830
9e39bf13-9d8a-437a-96d1-32177d0707c1	52552512-4b33-47f3-98f5-1f4e60d3a8b1
9e39bf13-9d8a-437a-96d1-32177d0707c1	f8bf3446-59d2-479b-a773-44bb2f17f50b
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	c97b29a7-7764-4893-9de9-18e3fee94462
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	b04b6a7e-76a5-4f52-9ece-a163704efa38
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	51234121-4440-4eea-8ba9-9a181f0b39a4
bfc76e08-8167-47d1-8ce6-b526d6182f4a	c97b29a7-7764-4893-9de9-18e3fee94462
bfc76e08-8167-47d1-8ce6-b526d6182f4a	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
bfc76e08-8167-47d1-8ce6-b526d6182f4a	b04b6a7e-76a5-4f52-9ece-a163704efa38
bfc76e08-8167-47d1-8ce6-b526d6182f4a	51234121-4440-4eea-8ba9-9a181f0b39a4
bfc76e08-8167-47d1-8ce6-b526d6182f4a	b4cd517d-cf3b-4001-bc2d-7109a171dd59
bfc76e08-8167-47d1-8ce6-b526d6182f4a	c651765c-ad9d-43c2-853a-cc3e595b2713
bfc76e08-8167-47d1-8ce6-b526d6182f4a	156357b5-b39f-4940-85f4-6b58da5ee830
bfc76e08-8167-47d1-8ce6-b526d6182f4a	52552512-4b33-47f3-98f5-1f4e60d3a8b1
bfc76e08-8167-47d1-8ce6-b526d6182f4a	1f2e2ce8-8798-42f2-bec0-744e14bca51c
bfc76e08-8167-47d1-8ce6-b526d6182f4a	44e95148-7ff7-4a12-a28f-2e49be00bb98
bfc76e08-8167-47d1-8ce6-b526d6182f4a	83c3b6ae-b146-4ed1-8154-3c13d651ad26
bfc76e08-8167-47d1-8ce6-b526d6182f4a	e70ff4ad-1601-4af6-9d46-c635a9118437
bfc76e08-8167-47d1-8ce6-b526d6182f4a	26c9669f-bf10-49df-bab7-c7d222abc082
bfc76e08-8167-47d1-8ce6-b526d6182f4a	b5dd85d2-caea-4053-95fe-a8a813bfa293
bfc76e08-8167-47d1-8ce6-b526d6182f4a	45fbacad-1b42-4318-b7c5-01353f3466b7
bfc76e08-8167-47d1-8ce6-b526d6182f4a	7fd214da-d40e-4f05-8d64-f23b9644c0af
bfc76e08-8167-47d1-8ce6-b526d6182f4a	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
8001b294-130c-4948-9fdd-b80f14d2e8ef	c97b29a7-7764-4893-9de9-18e3fee94462
8001b294-130c-4948-9fdd-b80f14d2e8ef	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
8001b294-130c-4948-9fdd-b80f14d2e8ef	b04b6a7e-76a5-4f52-9ece-a163704efa38
8001b294-130c-4948-9fdd-b80f14d2e8ef	b4cd517d-cf3b-4001-bc2d-7109a171dd59
8001b294-130c-4948-9fdd-b80f14d2e8ef	c651765c-ad9d-43c2-853a-cc3e595b2713
8001b294-130c-4948-9fdd-b80f14d2e8ef	156357b5-b39f-4940-85f4-6b58da5ee830
8001b294-130c-4948-9fdd-b80f14d2e8ef	52552512-4b33-47f3-98f5-1f4e60d3a8b1
8001b294-130c-4948-9fdd-b80f14d2e8ef	f8bf3446-59d2-479b-a773-44bb2f17f50b
bfc76e08-8167-47d1-8ce6-b526d6182f4a	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
bfc76e08-8167-47d1-8ce6-b526d6182f4a	f8bf3446-59d2-479b-a773-44bb2f17f50b
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	c97b29a7-7764-4893-9de9-18e3fee94462
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	b04b6a7e-76a5-4f52-9ece-a163704efa38
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	b4cd517d-cf3b-4001-bc2d-7109a171dd59
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	c651765c-ad9d-43c2-853a-cc3e595b2713
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	156357b5-b39f-4940-85f4-6b58da5ee830
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	52552512-4b33-47f3-98f5-1f4e60d3a8b1
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	1f2e2ce8-8798-42f2-bec0-744e14bca51c
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	44e95148-7ff7-4a12-a28f-2e49be00bb98
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	26c9669f-bf10-49df-bab7-c7d222abc082
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	b5dd85d2-caea-4053-95fe-a8a813bfa293
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	45fbacad-1b42-4318-b7c5-01353f3466b7
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	7fd214da-d40e-4f05-8d64-f23b9644c0af
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	f8bf3446-59d2-479b-a773-44bb2f17f50b
d5eebd22-bc0f-4362-888f-f704983d2eb5	156357b5-b39f-4940-85f4-6b58da5ee830
63d8ff19-855e-4cfc-badf-bd3511b3709c	c97b29a7-7764-4893-9de9-18e3fee94462
63d8ff19-855e-4cfc-badf-bd3511b3709c	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
63d8ff19-855e-4cfc-badf-bd3511b3709c	b04b6a7e-76a5-4f52-9ece-a163704efa38
63d8ff19-855e-4cfc-badf-bd3511b3709c	51234121-4440-4eea-8ba9-9a181f0b39a4
63d8ff19-855e-4cfc-badf-bd3511b3709c	b4cd517d-cf3b-4001-bc2d-7109a171dd59
63d8ff19-855e-4cfc-badf-bd3511b3709c	c651765c-ad9d-43c2-853a-cc3e595b2713
63d8ff19-855e-4cfc-badf-bd3511b3709c	156357b5-b39f-4940-85f4-6b58da5ee830
63d8ff19-855e-4cfc-badf-bd3511b3709c	52552512-4b33-47f3-98f5-1f4e60d3a8b1
63d8ff19-855e-4cfc-badf-bd3511b3709c	1f2e2ce8-8798-42f2-bec0-744e14bca51c
63d8ff19-855e-4cfc-badf-bd3511b3709c	44e95148-7ff7-4a12-a28f-2e49be00bb98
63d8ff19-855e-4cfc-badf-bd3511b3709c	83c3b6ae-b146-4ed1-8154-3c13d651ad26
63d8ff19-855e-4cfc-badf-bd3511b3709c	e70ff4ad-1601-4af6-9d46-c635a9118437
63d8ff19-855e-4cfc-badf-bd3511b3709c	26c9669f-bf10-49df-bab7-c7d222abc082
63d8ff19-855e-4cfc-badf-bd3511b3709c	b5dd85d2-caea-4053-95fe-a8a813bfa293
63d8ff19-855e-4cfc-badf-bd3511b3709c	45fbacad-1b42-4318-b7c5-01353f3466b7
63d8ff19-855e-4cfc-badf-bd3511b3709c	7fd214da-d40e-4f05-8d64-f23b9644c0af
63d8ff19-855e-4cfc-badf-bd3511b3709c	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
63d8ff19-855e-4cfc-badf-bd3511b3709c	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
63d8ff19-855e-4cfc-badf-bd3511b3709c	f8bf3446-59d2-479b-a773-44bb2f17f50b
13c7d581-e170-4627-9e43-4650faf4d161	c97b29a7-7764-4893-9de9-18e3fee94462
13c7d581-e170-4627-9e43-4650faf4d161	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
13c7d581-e170-4627-9e43-4650faf4d161	b04b6a7e-76a5-4f52-9ece-a163704efa38
13c7d581-e170-4627-9e43-4650faf4d161	b4cd517d-cf3b-4001-bc2d-7109a171dd59
13c7d581-e170-4627-9e43-4650faf4d161	c651765c-ad9d-43c2-853a-cc3e595b2713
13c7d581-e170-4627-9e43-4650faf4d161	156357b5-b39f-4940-85f4-6b58da5ee830
13c7d581-e170-4627-9e43-4650faf4d161	52552512-4b33-47f3-98f5-1f4e60d3a8b1
13c7d581-e170-4627-9e43-4650faf4d161	1f2e2ce8-8798-42f2-bec0-744e14bca51c
13c7d581-e170-4627-9e43-4650faf4d161	44e95148-7ff7-4a12-a28f-2e49be00bb98
13c7d581-e170-4627-9e43-4650faf4d161	26c9669f-bf10-49df-bab7-c7d222abc082
13c7d581-e170-4627-9e43-4650faf4d161	b5dd85d2-caea-4053-95fe-a8a813bfa293
13c7d581-e170-4627-9e43-4650faf4d161	45fbacad-1b42-4318-b7c5-01353f3466b7
13c7d581-e170-4627-9e43-4650faf4d161	7fd214da-d40e-4f05-8d64-f23b9644c0af
13c7d581-e170-4627-9e43-4650faf4d161	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
13c7d581-e170-4627-9e43-4650faf4d161	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
13c7d581-e170-4627-9e43-4650faf4d161	f8bf3446-59d2-479b-a773-44bb2f17f50b
ca7f15e3-678a-44e0-a8f3-49f780a8dbc2	156357b5-b39f-4940-85f4-6b58da5ee830
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	b4cd517d-cf3b-4001-bc2d-7109a171dd59
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	c651765c-ad9d-43c2-853a-cc3e595b2713
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	156357b5-b39f-4940-85f4-6b58da5ee830
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	52552512-4b33-47f3-98f5-1f4e60d3a8b1
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	1f2e2ce8-8798-42f2-bec0-744e14bca51c
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	44e95148-7ff7-4a12-a28f-2e49be00bb98
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	83c3b6ae-b146-4ed1-8154-3c13d651ad26
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	e70ff4ad-1601-4af6-9d46-c635a9118437
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	26c9669f-bf10-49df-bab7-c7d222abc082
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	b5dd85d2-caea-4053-95fe-a8a813bfa293
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	45fbacad-1b42-4318-b7c5-01353f3466b7
8a452d14-2cc7-452e-ae56-fa1cd72695c1	e70ff4ad-1601-4af6-9d46-c635a9118437
8a452d14-2cc7-452e-ae56-fa1cd72695c1	26c9669f-bf10-49df-bab7-c7d222abc082
8a452d14-2cc7-452e-ae56-fa1cd72695c1	b5dd85d2-caea-4053-95fe-a8a813bfa293
8a452d14-2cc7-452e-ae56-fa1cd72695c1	45fbacad-1b42-4318-b7c5-01353f3466b7
8a452d14-2cc7-452e-ae56-fa1cd72695c1	7fd214da-d40e-4f05-8d64-f23b9644c0af
8a452d14-2cc7-452e-ae56-fa1cd72695c1	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
8a452d14-2cc7-452e-ae56-fa1cd72695c1	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
8a452d14-2cc7-452e-ae56-fa1cd72695c1	f8bf3446-59d2-479b-a773-44bb2f17f50b
48d13e92-dc00-44a7-9865-c34819f5c7d2	c97b29a7-7764-4893-9de9-18e3fee94462
48d13e92-dc00-44a7-9865-c34819f5c7d2	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
48d13e92-dc00-44a7-9865-c34819f5c7d2	b04b6a7e-76a5-4f52-9ece-a163704efa38
48d13e92-dc00-44a7-9865-c34819f5c7d2	b4cd517d-cf3b-4001-bc2d-7109a171dd59
48d13e92-dc00-44a7-9865-c34819f5c7d2	c651765c-ad9d-43c2-853a-cc3e595b2713
48d13e92-dc00-44a7-9865-c34819f5c7d2	156357b5-b39f-4940-85f4-6b58da5ee830
48d13e92-dc00-44a7-9865-c34819f5c7d2	52552512-4b33-47f3-98f5-1f4e60d3a8b1
48d13e92-dc00-44a7-9865-c34819f5c7d2	1f2e2ce8-8798-42f2-bec0-744e14bca51c
48d13e92-dc00-44a7-9865-c34819f5c7d2	44e95148-7ff7-4a12-a28f-2e49be00bb98
48d13e92-dc00-44a7-9865-c34819f5c7d2	26c9669f-bf10-49df-bab7-c7d222abc082
48d13e92-dc00-44a7-9865-c34819f5c7d2	b5dd85d2-caea-4053-95fe-a8a813bfa293
48d13e92-dc00-44a7-9865-c34819f5c7d2	45fbacad-1b42-4318-b7c5-01353f3466b7
48d13e92-dc00-44a7-9865-c34819f5c7d2	7fd214da-d40e-4f05-8d64-f23b9644c0af
48d13e92-dc00-44a7-9865-c34819f5c7d2	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
48d13e92-dc00-44a7-9865-c34819f5c7d2	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
48d13e92-dc00-44a7-9865-c34819f5c7d2	f8bf3446-59d2-479b-a773-44bb2f17f50b
85fcfed7-7b1f-4e51-b84a-2c08366a0f9d	156357b5-b39f-4940-85f4-6b58da5ee830
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	c97b29a7-7764-4893-9de9-18e3fee94462
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	b04b6a7e-76a5-4f52-9ece-a163704efa38
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	51234121-4440-4eea-8ba9-9a181f0b39a4
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	b4cd517d-cf3b-4001-bc2d-7109a171dd59
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	c651765c-ad9d-43c2-853a-cc3e595b2713
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	156357b5-b39f-4940-85f4-6b58da5ee830
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	52552512-4b33-47f3-98f5-1f4e60d3a8b1
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	1f2e2ce8-8798-42f2-bec0-744e14bca51c
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	44e95148-7ff7-4a12-a28f-2e49be00bb98
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	83c3b6ae-b146-4ed1-8154-3c13d651ad26
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	e70ff4ad-1601-4af6-9d46-c635a9118437
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	26c9669f-bf10-49df-bab7-c7d222abc082
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	b5dd85d2-caea-4053-95fe-a8a813bfa293
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	45fbacad-1b42-4318-b7c5-01353f3466b7
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	7fd214da-d40e-4f05-8d64-f23b9644c0af
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	f8bf3446-59d2-479b-a773-44bb2f17f50b
a951eb9a-4863-439a-b935-5f45fc378701	c97b29a7-7764-4893-9de9-18e3fee94462
a951eb9a-4863-439a-b935-5f45fc378701	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
a951eb9a-4863-439a-b935-5f45fc378701	b04b6a7e-76a5-4f52-9ece-a163704efa38
a951eb9a-4863-439a-b935-5f45fc378701	b4cd517d-cf3b-4001-bc2d-7109a171dd59
a951eb9a-4863-439a-b935-5f45fc378701	c651765c-ad9d-43c2-853a-cc3e595b2713
a951eb9a-4863-439a-b935-5f45fc378701	156357b5-b39f-4940-85f4-6b58da5ee830
a951eb9a-4863-439a-b935-5f45fc378701	52552512-4b33-47f3-98f5-1f4e60d3a8b1
a951eb9a-4863-439a-b935-5f45fc378701	1f2e2ce8-8798-42f2-bec0-744e14bca51c
a951eb9a-4863-439a-b935-5f45fc378701	44e95148-7ff7-4a12-a28f-2e49be00bb98
a951eb9a-4863-439a-b935-5f45fc378701	26c9669f-bf10-49df-bab7-c7d222abc082
a951eb9a-4863-439a-b935-5f45fc378701	b5dd85d2-caea-4053-95fe-a8a813bfa293
a951eb9a-4863-439a-b935-5f45fc378701	45fbacad-1b42-4318-b7c5-01353f3466b7
a951eb9a-4863-439a-b935-5f45fc378701	7fd214da-d40e-4f05-8d64-f23b9644c0af
a951eb9a-4863-439a-b935-5f45fc378701	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
a951eb9a-4863-439a-b935-5f45fc378701	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
a951eb9a-4863-439a-b935-5f45fc378701	f8bf3446-59d2-479b-a773-44bb2f17f50b
a61b006b-3e16-44cf-914d-e76f5bc86021	156357b5-b39f-4940-85f4-6b58da5ee830
6139daa9-c20e-47ee-9c25-9e49eca85344	c97b29a7-7764-4893-9de9-18e3fee94462
6139daa9-c20e-47ee-9c25-9e49eca85344	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
6139daa9-c20e-47ee-9c25-9e49eca85344	b04b6a7e-76a5-4f52-9ece-a163704efa38
6139daa9-c20e-47ee-9c25-9e49eca85344	51234121-4440-4eea-8ba9-9a181f0b39a4
6139daa9-c20e-47ee-9c25-9e49eca85344	b4cd517d-cf3b-4001-bc2d-7109a171dd59
6139daa9-c20e-47ee-9c25-9e49eca85344	c651765c-ad9d-43c2-853a-cc3e595b2713
6139daa9-c20e-47ee-9c25-9e49eca85344	156357b5-b39f-4940-85f4-6b58da5ee830
6139daa9-c20e-47ee-9c25-9e49eca85344	52552512-4b33-47f3-98f5-1f4e60d3a8b1
6139daa9-c20e-47ee-9c25-9e49eca85344	1f2e2ce8-8798-42f2-bec0-744e14bca51c
6139daa9-c20e-47ee-9c25-9e49eca85344	44e95148-7ff7-4a12-a28f-2e49be00bb98
6139daa9-c20e-47ee-9c25-9e49eca85344	83c3b6ae-b146-4ed1-8154-3c13d651ad26
6139daa9-c20e-47ee-9c25-9e49eca85344	e70ff4ad-1601-4af6-9d46-c635a9118437
6139daa9-c20e-47ee-9c25-9e49eca85344	26c9669f-bf10-49df-bab7-c7d222abc082
6139daa9-c20e-47ee-9c25-9e49eca85344	b5dd85d2-caea-4053-95fe-a8a813bfa293
6139daa9-c20e-47ee-9c25-9e49eca85344	45fbacad-1b42-4318-b7c5-01353f3466b7
6139daa9-c20e-47ee-9c25-9e49eca85344	7fd214da-d40e-4f05-8d64-f23b9644c0af
6139daa9-c20e-47ee-9c25-9e49eca85344	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
6139daa9-c20e-47ee-9c25-9e49eca85344	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
6139daa9-c20e-47ee-9c25-9e49eca85344	f8bf3446-59d2-479b-a773-44bb2f17f50b
18dfa786-bc8d-4456-8653-81651105b5fc	c97b29a7-7764-4893-9de9-18e3fee94462
18dfa786-bc8d-4456-8653-81651105b5fc	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
18dfa786-bc8d-4456-8653-81651105b5fc	b04b6a7e-76a5-4f52-9ece-a163704efa38
18dfa786-bc8d-4456-8653-81651105b5fc	b4cd517d-cf3b-4001-bc2d-7109a171dd59
18dfa786-bc8d-4456-8653-81651105b5fc	c651765c-ad9d-43c2-853a-cc3e595b2713
18dfa786-bc8d-4456-8653-81651105b5fc	156357b5-b39f-4940-85f4-6b58da5ee830
18dfa786-bc8d-4456-8653-81651105b5fc	52552512-4b33-47f3-98f5-1f4e60d3a8b1
18dfa786-bc8d-4456-8653-81651105b5fc	1f2e2ce8-8798-42f2-bec0-744e14bca51c
18dfa786-bc8d-4456-8653-81651105b5fc	44e95148-7ff7-4a12-a28f-2e49be00bb98
18dfa786-bc8d-4456-8653-81651105b5fc	26c9669f-bf10-49df-bab7-c7d222abc082
18dfa786-bc8d-4456-8653-81651105b5fc	b5dd85d2-caea-4053-95fe-a8a813bfa293
18dfa786-bc8d-4456-8653-81651105b5fc	45fbacad-1b42-4318-b7c5-01353f3466b7
18dfa786-bc8d-4456-8653-81651105b5fc	7fd214da-d40e-4f05-8d64-f23b9644c0af
18dfa786-bc8d-4456-8653-81651105b5fc	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
18dfa786-bc8d-4456-8653-81651105b5fc	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
18dfa786-bc8d-4456-8653-81651105b5fc	f8bf3446-59d2-479b-a773-44bb2f17f50b
4aa5cecb-0650-4572-b047-21c9f3ff0dfa	156357b5-b39f-4940-85f4-6b58da5ee830
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	7fd214da-d40e-4f05-8d64-f23b9644c0af
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	f8bf3446-59d2-479b-a773-44bb2f17f50b
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	c97b29a7-7764-4893-9de9-18e3fee94462
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	b04b6a7e-76a5-4f52-9ece-a163704efa38
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	b4cd517d-cf3b-4001-bc2d-7109a171dd59
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	c651765c-ad9d-43c2-853a-cc3e595b2713
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	156357b5-b39f-4940-85f4-6b58da5ee830
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	52552512-4b33-47f3-98f5-1f4e60d3a8b1
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	1f2e2ce8-8798-42f2-bec0-744e14bca51c
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	44e95148-7ff7-4a12-a28f-2e49be00bb98
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	26c9669f-bf10-49df-bab7-c7d222abc082
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	b5dd85d2-caea-4053-95fe-a8a813bfa293
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	45fbacad-1b42-4318-b7c5-01353f3466b7
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	7fd214da-d40e-4f05-8d64-f23b9644c0af
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	aa42f5b6-6f12-4769-8c6f-5c4363002a5c
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	8ffb4c24-5494-44ae-8e8e-0cc70f05e9c1
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	f8bf3446-59d2-479b-a773-44bb2f17f50b
2bcd66b8-9817-4e31-af16-b8066357f55e	156357b5-b39f-4940-85f4-6b58da5ee830
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	c97b29a7-7764-4893-9de9-18e3fee94462
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	b04b6a7e-76a5-4f52-9ece-a163704efa38
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	b4cd517d-cf3b-4001-bc2d-7109a171dd59
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	c651765c-ad9d-43c2-853a-cc3e595b2713
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	156357b5-b39f-4940-85f4-6b58da5ee830
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	52552512-4b33-47f3-98f5-1f4e60d3a8b1
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	f8bf3446-59d2-479b-a773-44bb2f17f50b
775fe76d-8f31-4bde-a3b5-9b6f78060f10	c97b29a7-7764-4893-9de9-18e3fee94462
775fe76d-8f31-4bde-a3b5-9b6f78060f10	9167fcc1-c0d2-4a66-8fcf-bccb3bceae75
775fe76d-8f31-4bde-a3b5-9b6f78060f10	b04b6a7e-76a5-4f52-9ece-a163704efa38
775fe76d-8f31-4bde-a3b5-9b6f78060f10	b4cd517d-cf3b-4001-bc2d-7109a171dd59
775fe76d-8f31-4bde-a3b5-9b6f78060f10	c651765c-ad9d-43c2-853a-cc3e595b2713
775fe76d-8f31-4bde-a3b5-9b6f78060f10	156357b5-b39f-4940-85f4-6b58da5ee830
775fe76d-8f31-4bde-a3b5-9b6f78060f10	52552512-4b33-47f3-98f5-1f4e60d3a8b1
775fe76d-8f31-4bde-a3b5-9b6f78060f10	f8bf3446-59d2-479b-a773-44bb2f17f50b
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.roles (id, company_id, system_key, name, is_system_role, created_at) FROM stdin;
ce939d90-8c66-4235-a31b-7beef1a33d29	e9c09207-6fea-46d5-8f07-7464472a519a	owner	Owner	t	2026-08-08 18:48:04.593
bfc76e08-8167-47d1-8ce6-b526d6182f4a	77e72b03-ff84-4721-bdbc-a79d00c301a6	owner	Owner	t	2026-08-09 09:01:43.501
02fb6feb-71a8-4bca-baed-0555be0f20d0	c331e53c-fe17-49c2-97f1-9466a87bbe42	owner	Owner	t	2026-08-08 18:14:51.888
71bae2da-4175-44fa-bd7e-a0d4b424f4f1	c331e53c-fe17-49c2-97f1-9466a87bbe42	manager	Manager	t	2026-08-08 18:14:51.891
ff6f78c5-e06b-4a0b-b954-483d2890c815	c331e53c-fe17-49c2-97f1-9466a87bbe42	driver	Driver	t	2026-08-08 18:14:51.893
34be6d44-2265-4373-9f9c-ecf23682170a	c331e53c-fe17-49c2-97f1-9466a87bbe42	farmer	Farmer	t	2026-08-08 18:14:51.895
fc0c0dba-4c4e-4a54-9d5e-49ba858860b6	77e72b03-ff84-4721-bdbc-a79d00c301a6	manager	Manager	t	2026-08-09 09:01:43.526
ce2949bc-4f5a-49e5-87af-6092d06c6d22	40511429-f937-4f0f-8a0a-6869154b7144	owner	Owner	t	2026-08-08 18:04:35.29
1d263619-3889-40b8-a1f7-1b804d6e1403	40511429-f937-4f0f-8a0a-6869154b7144	manager	Manager	t	2026-08-08 18:04:35.337
c4a9352c-f519-4f21-9a42-bb3d2c81b141	40511429-f937-4f0f-8a0a-6869154b7144	driver	Driver	t	2026-08-08 18:04:35.376
42ea61d3-ab64-451c-beb1-e6befee3d2c4	40511429-f937-4f0f-8a0a-6869154b7144	farmer	Farmer	t	2026-08-08 18:04:35.381
05c60e5e-2664-45a2-9cbe-5a766c096f86	8fbaf386-5fd4-44cb-9119-9108a7c653c2	owner	Owner	t	2026-08-08 18:04:35.386
6f006da6-ec24-4082-b62b-ba1197f8f456	8fbaf386-5fd4-44cb-9119-9108a7c653c2	manager	Manager	t	2026-08-08 18:04:35.418
b49ecf65-e7eb-45e2-9a6b-4616f0a0b102	8fbaf386-5fd4-44cb-9119-9108a7c653c2	driver	Driver	t	2026-08-08 18:04:35.446
fe531679-1195-47ce-932b-bf8f7b4de28f	8fbaf386-5fd4-44cb-9119-9108a7c653c2	farmer	Farmer	t	2026-08-08 18:04:35.45
69c95746-861e-4f84-afe4-ec42b734eff9	99690b52-8af1-4813-b8a1-4af071a81549	owner	Owner	t	2026-08-08 18:04:45.649
3c742dbf-418b-49c8-af8b-64d442341049	99690b52-8af1-4813-b8a1-4af071a81549	manager	Manager	t	2026-08-08 18:04:45.699
14844705-cc42-4fbd-87ff-b2804156aedf	99690b52-8af1-4813-b8a1-4af071a81549	driver	Driver	t	2026-08-08 18:04:45.756
448e5a8e-44da-481e-879d-770324c5cd92	99690b52-8af1-4813-b8a1-4af071a81549	farmer	Farmer	t	2026-08-08 18:04:45.76
9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	1a1ead59-2b11-4f2a-85e5-71c30252fbab	owner	Owner	t	2026-08-08 18:04:45.777
aeba451d-4106-4d98-a01e-2821921c1657	1a1ead59-2b11-4f2a-85e5-71c30252fbab	manager	Manager	t	2026-08-08 18:04:45.812
eaf7aad9-739e-418b-8980-24217fb85ac4	1a1ead59-2b11-4f2a-85e5-71c30252fbab	driver	Driver	t	2026-08-08 18:04:45.84
f76ee641-b8d8-4b10-9606-30445eafe5cc	1a1ead59-2b11-4f2a-85e5-71c30252fbab	farmer	Farmer	t	2026-08-08 18:04:45.844
3bf67871-202c-4818-9bae-87e89c161209	98052597-43cc-4b9a-a12b-72260f7e39ff	owner	Owner	t	2026-08-08 18:04:56.062
24c8ae9a-c82f-493f-b44a-5f8f38542f03	98052597-43cc-4b9a-a12b-72260f7e39ff	manager	Manager	t	2026-08-08 18:04:56.106
6b53e881-c542-466e-b77a-f1873f2910c2	98052597-43cc-4b9a-a12b-72260f7e39ff	driver	Driver	t	2026-08-08 18:04:56.134
16828bc6-459a-49d8-b7aa-0dff23086b3b	98052597-43cc-4b9a-a12b-72260f7e39ff	farmer	Farmer	t	2026-08-08 18:04:56.138
a6321639-6f3d-4cb0-aff9-2e9d1e86507f	c40dd20c-a216-4766-8dd3-db89037b4bc4	owner	Owner	t	2026-08-08 18:04:56.155
1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	c40dd20c-a216-4766-8dd3-db89037b4bc4	manager	Manager	t	2026-08-08 18:04:56.189
2e689e58-3786-4264-a6c5-153841b5dca4	c40dd20c-a216-4766-8dd3-db89037b4bc4	driver	Driver	t	2026-08-08 18:04:56.218
dd250806-847b-462d-a6e4-ee5fb7a8e919	c40dd20c-a216-4766-8dd3-db89037b4bc4	farmer	Farmer	t	2026-08-08 18:04:56.221
78653bba-bd97-4d35-bcef-b2583e800502	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	owner	Owner	t	2026-08-08 18:05:07.062
7cc6517a-684a-4814-be72-886b6852cb89	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	manager	Manager	t	2026-08-08 18:05:07.141
df41cd2e-fee0-4e0a-ac5c-bf0718bb63ae	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	driver	Driver	t	2026-08-08 18:05:07.185
60798d6d-38ef-4ae5-89e5-17f3f6e12677	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	farmer	Farmer	t	2026-08-08 18:05:07.189
01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	owner	Owner	t	2026-08-08 18:05:07.206
a585a67a-51eb-4c03-8c32-dd6564a9a099	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	manager	Manager	t	2026-08-08 18:05:07.242
0a811a12-2fa1-49cc-8ca6-3ee0fb4f8523	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	driver	Driver	t	2026-08-08 18:05:07.273
bde9e688-c1a1-4021-9bc0-d24fcc20d732	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	farmer	Farmer	t	2026-08-08 18:05:07.276
6824152d-d3c2-43a8-b23a-189adbe8ffa3	3e8490bb-07a1-497f-8b5b-8f2e470cf284	owner	Owner	t	2026-08-08 18:05:17.293
4e713e8b-86b0-4f77-a93f-a3044be417ce	3e8490bb-07a1-497f-8b5b-8f2e470cf284	manager	Manager	t	2026-08-08 18:05:17.336
fba11cae-715d-41b8-997f-7ebef2def202	3e8490bb-07a1-497f-8b5b-8f2e470cf284	driver	Driver	t	2026-08-08 18:05:17.368
2e26fec5-7c68-45ba-8ed7-45cc6add5e12	3e8490bb-07a1-497f-8b5b-8f2e470cf284	farmer	Farmer	t	2026-08-08 18:05:17.372
380f1e42-a55b-419c-9351-3ff2b8bb0e79	a6565866-d95e-4c4c-a2eb-76f3171c2907	owner	Owner	t	2026-08-08 18:05:17.388
c2c56b7a-7585-4d85-8333-d3a2f0b223f2	a6565866-d95e-4c4c-a2eb-76f3171c2907	manager	Manager	t	2026-08-08 18:05:17.421
3ea4c518-0514-4b80-a547-42b9faa8080c	a6565866-d95e-4c4c-a2eb-76f3171c2907	driver	Driver	t	2026-08-08 18:05:17.448
1e8faf04-f9b5-47f5-ac81-19d3ec9c5da8	a6565866-d95e-4c4c-a2eb-76f3171c2907	farmer	Farmer	t	2026-08-08 18:05:17.451
9c9439fd-b33f-4294-9cd2-a5ca3175e606	74dcfe64-85b0-4051-9c2c-8292caf839ea	owner	Owner	t	2026-08-08 18:05:31.358
67f0bafb-e1b8-4881-aa21-decb8a923e56	74dcfe64-85b0-4051-9c2c-8292caf839ea	manager	Manager	t	2026-08-08 18:05:31.403
85b63c45-8255-4cfe-87f6-8670c7fac862	74dcfe64-85b0-4051-9c2c-8292caf839ea	driver	Driver	t	2026-08-08 18:05:31.44
31803a2d-0aeb-4f1f-854b-96a95ba80726	74dcfe64-85b0-4051-9c2c-8292caf839ea	farmer	Farmer	t	2026-08-08 18:05:31.446
669d9173-d488-40a6-a075-318f30e31250	2fc53fa9-07fd-4172-af37-6a1034df9ecb	owner	Owner	t	2026-08-08 18:05:31.467
65dbd982-7d3b-4ea1-85f7-6e75a5b39658	2fc53fa9-07fd-4172-af37-6a1034df9ecb	manager	Manager	t	2026-08-08 18:05:31.5
7bc70e54-a1fc-4ebf-988d-f75ef4c859f7	2fc53fa9-07fd-4172-af37-6a1034df9ecb	driver	Driver	t	2026-08-08 18:05:31.529
4ba1e9d2-c67f-4d32-8cac-50f031f77c19	2fc53fa9-07fd-4172-af37-6a1034df9ecb	farmer	Farmer	t	2026-08-08 18:05:31.532
d5eebd22-bc0f-4362-888f-f704983d2eb5	77e72b03-ff84-4721-bdbc-a79d00c301a6	driver	Driver	t	2026-08-09 09:01:43.537
22391d47-fb14-405d-b765-ca83dd274140	77e72b03-ff84-4721-bdbc-a79d00c301a6	farmer	Farmer	t	2026-08-09 09:01:43.538
1682b3f9-e252-4568-9326-71a8ad1bac6e	31fdb769-0873-405a-aed7-f54f5303d5c5	owner	Owner	t	2026-08-09 09:03:09.197
aec2c8c0-ce4b-47ed-ba24-f89a49271fc9	31fdb769-0873-405a-aed7-f54f5303d5c5	manager	Manager	t	2026-08-09 09:03:09.218
f7f81fff-2392-479b-b4f2-d009056b0c2a	29c82d91-d80e-4358-a180-dd5df8cae889	owner	Owner	t	2026-08-07 18:54:04.671
dd1145b6-0025-4aa9-a61d-f4b17ac6879b	29c82d91-d80e-4358-a180-dd5df8cae889	manager	Manager	t	2026-08-07 18:54:04.718
ed52a830-1c11-4eac-8fde-75604abab500	29c82d91-d80e-4358-a180-dd5df8cae889	driver	Driver	t	2026-08-07 18:54:04.745
99290fff-bd48-4ba6-9df0-f9094411f12c	29c82d91-d80e-4358-a180-dd5df8cae889	farmer	Farmer	t	2026-08-07 18:54:04.753
d351f3a7-125e-4a25-bacd-29a8040715d1	a7ed8578-e3b6-4aec-91b1-214d09748c0e	owner	Owner	t	2026-08-08 18:14:58.553
a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	a7ed8578-e3b6-4aec-91b1-214d09748c0e	manager	Manager	t	2026-08-08 18:14:58.556
79304598-f759-430d-9028-00e0a5fee776	a7ed8578-e3b6-4aec-91b1-214d09748c0e	driver	Driver	t	2026-08-08 18:14:58.558
8e444def-5a00-4cd5-82a5-3f9a818d5014	a7ed8578-e3b6-4aec-91b1-214d09748c0e	farmer	Farmer	t	2026-08-08 18:14:58.56
9625dc56-7fc2-4f9e-9342-abf91cb27f4a	b51f455a-feb6-445f-8b08-8624162dc98b	owner	Owner	t	2026-08-08 18:15:07.459
36a6513b-ad30-45bc-90be-bd09352b2994	b51f455a-feb6-445f-8b08-8624162dc98b	manager	Manager	t	2026-08-08 18:15:07.463
c6d04e8f-f718-4898-a0f4-987f98331d75	b51f455a-feb6-445f-8b08-8624162dc98b	driver	Driver	t	2026-08-08 18:15:07.466
3b4b6bf2-204e-4e11-a54f-9638ac64bde3	b51f455a-feb6-445f-8b08-8624162dc98b	farmer	Farmer	t	2026-08-08 18:15:07.469
7b05ab36-1597-4696-8dcf-b3f64edff29d	3b4fa961-b987-4207-bade-425969e8e1a5	owner	Owner	t	2026-08-08 18:15:15.56
bbb2c358-1b37-48d1-bd85-f8a097344680	3b4fa961-b987-4207-bade-425969e8e1a5	manager	Manager	t	2026-08-08 18:15:15.562
096d5383-dc82-4306-84b6-a6a7a1234bf8	3b4fa961-b987-4207-bade-425969e8e1a5	driver	Driver	t	2026-08-08 18:15:15.564
df141565-0fc7-4489-b497-3f771020d671	3b4fa961-b987-4207-bade-425969e8e1a5	farmer	Farmer	t	2026-08-08 18:15:15.566
c0b04d2b-fee9-4137-a198-06ae72762722	023866d9-236a-41cc-a36f-b9e516720f54	owner	Owner	t	2026-08-08 18:15:42.848
4e005b1b-d37b-46f9-a834-bd1a7e689917	023866d9-236a-41cc-a36f-b9e516720f54	manager	Manager	t	2026-08-08 18:15:42.851
20f3712f-d8f1-4d1f-80f5-fa0910e25928	023866d9-236a-41cc-a36f-b9e516720f54	driver	Driver	t	2026-08-08 18:15:42.854
bedfcea4-f961-4594-b8c1-88b87ee386a8	023866d9-236a-41cc-a36f-b9e516720f54	farmer	Farmer	t	2026-08-08 18:15:42.856
f3608e87-6101-460f-bf6f-433fe4b61046	024b72fd-44b2-4f38-96c1-78b156fa58c2	owner	Owner	t	2026-08-08 18:22:33.369
ff57d6f5-4c23-4501-9e20-7318a6fca73c	024b72fd-44b2-4f38-96c1-78b156fa58c2	manager	Manager	t	2026-08-08 18:22:33.372
86efdde7-581e-4dc0-aad4-50717decaff2	024b72fd-44b2-4f38-96c1-78b156fa58c2	driver	Driver	t	2026-08-08 18:22:33.374
dcc0a6c3-5ee0-43e8-ab26-a9f7e26fb83d	024b72fd-44b2-4f38-96c1-78b156fa58c2	farmer	Farmer	t	2026-08-08 18:22:33.377
c66722d5-39ff-4773-885e-8117773f906f	f33c8ba7-f382-4217-90cf-d9d133632537	owner	Owner	t	2026-08-08 18:23:51.633
258eb3eb-7195-4f09-ab45-33dd488e92ca	f33c8ba7-f382-4217-90cf-d9d133632537	manager	Manager	t	2026-08-08 18:23:51.636
5e5ba701-e7a5-4d6d-8a77-2df6b2261fd7	f33c8ba7-f382-4217-90cf-d9d133632537	driver	Driver	t	2026-08-08 18:23:51.638
03e0773d-e554-44f1-b5f1-67f454abd10f	f33c8ba7-f382-4217-90cf-d9d133632537	farmer	Farmer	t	2026-08-08 18:23:51.64
f97f8c9b-d880-4356-9c7a-78b97d1da71b	c329669f-35fe-4787-84c9-902251b14695	owner	Owner	t	2026-08-08 18:33:48.885
323747f5-1d98-4b35-88e8-13b6673715b6	c329669f-35fe-4787-84c9-902251b14695	manager	Manager	t	2026-08-08 18:33:48.887
11f705ab-0e4b-42bc-ab8a-3f698de0cf70	c329669f-35fe-4787-84c9-902251b14695	driver	Driver	t	2026-08-08 18:33:48.89
966530fb-54e0-4dd3-b3d7-57c64f708794	c329669f-35fe-4787-84c9-902251b14695	farmer	Farmer	t	2026-08-08 18:33:48.892
6d0530ca-a7b9-44e3-9117-7d39717ebfa7	19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	owner	Owner	t	2026-08-09 09:01:58.066
5ff5a3aa-c28e-466e-9a49-3a277b82d3b0	19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	manager	Manager	t	2026-08-09 09:01:58.097
d27fc6e5-e731-46c5-bb7c-f77c03a18ace	19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	driver	Driver	t	2026-08-09 09:01:58.117
82dbc634-0ff9-4363-b002-b866d8796951	19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	farmer	Farmer	t	2026-08-09 09:01:58.119
7899f446-e041-4367-b317-cacd383726c3	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	owner	Owner	t	2026-08-08 18:48:19.135
5c9f93da-100f-42f2-a5c9-92175d86ab7c	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	manager	Manager	t	2026-08-08 18:48:19.14
fe0df962-cbb3-4e30-8218-c470f87b57c2	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	driver	Driver	t	2026-08-08 18:48:19.142
add2f824-cfbf-487a-9784-08979980101b	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	farmer	Farmer	t	2026-08-08 18:48:19.145
e28d2800-d82f-489d-8af8-0d384cac1b25	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	owner	Owner	t	2026-08-08 19:32:43.754
61e4b9c6-ebc2-49c4-872a-56f7085df0db	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	manager	Manager	t	2026-08-08 19:32:43.757
3f06c163-5e32-4c47-be56-78f0d8d2629c	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	driver	Driver	t	2026-08-08 19:32:43.759
41a1a028-8b97-4e36-95b1-50874d823d43	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	farmer	Farmer	t	2026-08-08 19:32:43.761
12fbe7b8-9c38-4957-a091-e9ef44914617	3968e65b-4204-432c-ad93-26a831a79d3e	owner	Owner	t	2026-08-08 19:38:59.155
afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	3968e65b-4204-432c-ad93-26a831a79d3e	manager	Manager	t	2026-08-08 19:38:59.158
a72068df-8bdf-42cd-98ee-256bbb0b83c6	3968e65b-4204-432c-ad93-26a831a79d3e	driver	Driver	t	2026-08-08 19:38:59.16
e5bbb2c3-5551-4a4e-81d0-c7ce5d29c3bc	3968e65b-4204-432c-ad93-26a831a79d3e	farmer	Farmer	t	2026-08-08 19:38:59.162
f78dc855-bb3a-41f9-a90f-8168d63202a1	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	owner	Owner	t	2026-08-08 19:41:57.926
971784a0-36da-4f0b-8dfd-af5555f1eeb2	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	manager	Manager	t	2026-08-08 19:41:57.929
ae8ba156-83fa-4646-8977-26f4c4653e1b	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	driver	Driver	t	2026-08-08 19:41:57.93
7fd63aac-5a5a-410a-85e1-43cf091f9707	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	farmer	Farmer	t	2026-08-08 19:41:57.932
1415bb15-ba08-4269-b90c-bcc30eee79e8	ecbba26c-b8ee-4455-a09e-86fab13778df	owner	Owner	t	2026-08-08 20:04:25.997
26e28e80-50aa-404b-a833-e1b1e7f442b8	ecbba26c-b8ee-4455-a09e-86fab13778df	manager	Manager	t	2026-08-08 20:04:26
b18786a2-1790-4bcb-b4c0-069189d80fca	ecbba26c-b8ee-4455-a09e-86fab13778df	driver	Driver	t	2026-08-08 20:04:26.004
a6487f8c-0da6-4a7b-a3d2-761b91071076	ecbba26c-b8ee-4455-a09e-86fab13778df	farmer	Farmer	t	2026-08-08 20:04:26.007
d9e655b4-5c5d-420b-95ff-747f6bd0016e	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	owner	Owner	t	2026-08-08 20:53:03.34
6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	manager	Manager	t	2026-08-08 20:53:03.343
8168e1bf-d2a6-4230-b8f8-d8423e0f247a	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	driver	Driver	t	2026-08-08 20:53:03.345
9c52781e-11c0-4437-a54e-70b9b57b7627	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	farmer	Farmer	t	2026-08-08 20:53:03.347
0086c03a-c6fb-4056-872e-7189800b1229	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	owner	Owner	t	2026-08-09 05:57:15.033
de048a83-eec3-4f20-a129-0df23c964503	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	manager	Manager	t	2026-08-09 05:57:15.037
5414a298-c811-4973-9aa3-53b9e41aaefc	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	driver	Driver	t	2026-08-09 05:57:15.04
425d6b11-e986-4751-9806-fbd8c43c05f0	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	farmer	Farmer	t	2026-08-09 05:57:15.044
b8ce9e6d-f9e2-4d2c-b546-161ed18ed509	31fdb769-0873-405a-aed7-f54f5303d5c5	driver	Driver	t	2026-08-09 09:03:09.229
8751267c-ef5b-4990-b619-b826a6e62d84	31fdb769-0873-405a-aed7-f54f5303d5c5	farmer	Farmer	t	2026-08-09 09:03:09.23
63d8ff19-855e-4cfc-badf-bd3511b3709c	1b7025b9-c122-4210-a967-97e8c1d180fd	owner	Owner	t	2026-08-09 09:03:19.959
13c7d581-e170-4627-9e43-4650faf4d161	1b7025b9-c122-4210-a967-97e8c1d180fd	manager	Manager	t	2026-08-09 09:03:19.986
ca7f15e3-678a-44e0-a8f3-49f780a8dbc2	1b7025b9-c122-4210-a967-97e8c1d180fd	driver	Driver	t	2026-08-09 09:03:20.006
50739664-d18f-42e1-9839-0bde6be02307	1b7025b9-c122-4210-a967-97e8c1d180fd	farmer	Farmer	t	2026-08-09 09:03:20.01
ed25e7a3-f13b-4bf1-b95a-81ac25ce126c	d8d7190c-b0f9-42e6-a510-8a401b035039	owner	Owner	t	2026-08-09 06:00:22.422
af3282d2-98da-47ce-b99d-5403e7985b1c	d8d7190c-b0f9-42e6-a510-8a401b035039	manager	Manager	t	2026-08-09 06:00:22.425
c6e30c73-0426-4941-93e2-711b3babed72	d8d7190c-b0f9-42e6-a510-8a401b035039	driver	Driver	t	2026-08-09 06:00:22.427
c0a09fac-9ebb-46c1-aa40-c839366dd7db	d8d7190c-b0f9-42e6-a510-8a401b035039	farmer	Farmer	t	2026-08-09 06:00:22.43
a6bca924-3969-4608-9fb9-672ef5ac4fba	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	owner	Owner	t	2026-08-09 06:00:29.685
35025a83-6d13-4cfb-af1d-5e99a6a2324f	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	manager	Manager	t	2026-08-09 06:00:29.69
6d84a757-509f-4171-a0a9-0579dd1bf854	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	driver	Driver	t	2026-08-09 06:00:29.693
7ffbc384-fcf5-4cf7-b594-1c86af11f140	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	farmer	Farmer	t	2026-08-09 06:00:29.696
06522e1e-ae1f-473e-8f35-9e114118a8d7	7a92e240-df0b-4c44-8bba-bd7574ae788b	owner	Owner	t	2026-08-09 06:00:44.944
f08de487-634d-460f-a1b3-41fa63d3e660	7a92e240-df0b-4c44-8bba-bd7574ae788b	manager	Manager	t	2026-08-09 06:00:44.948
3669c4c7-c8c0-451f-9c8a-665fc63a5a9b	7a92e240-df0b-4c44-8bba-bd7574ae788b	driver	Driver	t	2026-08-09 06:00:44.95
1a01ab75-861e-41ee-bcba-216fa70d348c	7a92e240-df0b-4c44-8bba-bd7574ae788b	farmer	Farmer	t	2026-08-09 06:00:44.952
f39c3948-c146-499f-883c-2e7005334379	8951aa6b-476b-46b7-b12b-de1998c8bbf7	owner	Owner	t	2026-08-09 06:00:59.325
5df2e40a-8234-44b1-acca-7e8e0f43211f	8951aa6b-476b-46b7-b12b-de1998c8bbf7	manager	Manager	t	2026-08-09 06:00:59.328
2fbb4c12-ee06-48b6-b270-0c588162ed94	8951aa6b-476b-46b7-b12b-de1998c8bbf7	driver	Driver	t	2026-08-09 06:00:59.33
667c8aea-5805-4882-943b-7380f61395fe	8951aa6b-476b-46b7-b12b-de1998c8bbf7	farmer	Farmer	t	2026-08-09 06:00:59.332
7fe4099d-6835-422a-b615-5dc43e34bff9	d563fb11-8e19-4079-a843-4d579ba681ee	owner	Owner	t	2026-08-09 06:01:10.591
b83595ac-ac3b-40db-a577-950655cf4070	d563fb11-8e19-4079-a843-4d579ba681ee	manager	Manager	t	2026-08-09 06:01:10.594
85ea8e15-918a-47da-b686-fef9b1ee2ea3	d563fb11-8e19-4079-a843-4d579ba681ee	driver	Driver	t	2026-08-09 06:01:10.596
45a92eb6-099b-4237-8a98-baba02636fbc	d563fb11-8e19-4079-a843-4d579ba681ee	farmer	Farmer	t	2026-08-09 06:01:10.599
db79b2d7-3c5f-4131-a14e-410867b364fe	b3bd9148-5bcf-46c7-aae9-d07d688834ca	owner	Owner	t	2026-08-09 09:03:25.87
225de02f-4f0e-406a-9ed6-6524dd5a3dda	b3bd9148-5bcf-46c7-aae9-d07d688834ca	manager	Manager	t	2026-08-09 09:03:25.872
84932ba2-5347-4cc5-9b2b-61845c5b423c	b3bd9148-5bcf-46c7-aae9-d07d688834ca	driver	Driver	t	2026-08-09 09:03:25.875
b0e26482-a4bb-4270-a42a-2026dad4f305	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	owner	Owner	t	2026-08-09 06:01:24.963
664f88a8-c509-47e4-8e4a-3705d78ad451	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	manager	Manager	t	2026-08-09 06:01:24.965
92108d15-b696-49d5-adf1-e836ae70c2ce	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	driver	Driver	t	2026-08-09 06:01:24.967
5179f9d0-0f35-4e1e-90fc-2057a765e951	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	farmer	Farmer	t	2026-08-09 06:01:24.969
1a445221-dd86-4a20-b4e4-4ceef045602d	b3bd9148-5bcf-46c7-aae9-d07d688834ca	farmer	Farmer	t	2026-08-09 09:03:25.877
8a452d14-2cc7-452e-ae56-fa1cd72695c1	9e4b2764-62cc-4933-9014-de6fc8b82d10	owner	Owner	t	2026-08-09 09:06:13.616
48d13e92-dc00-44a7-9865-c34819f5c7d2	9e4b2764-62cc-4933-9014-de6fc8b82d10	manager	Manager	t	2026-08-09 09:06:13.648
85fcfed7-7b1f-4e51-b84a-2c08366a0f9d	9e4b2764-62cc-4933-9014-de6fc8b82d10	driver	Driver	t	2026-08-09 09:06:13.672
7d9b476c-acb7-499b-b1a9-5175feb98f85	9e4b2764-62cc-4933-9014-de6fc8b82d10	farmer	Farmer	t	2026-08-09 09:06:13.676
24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	owner	Owner	t	2026-08-09 09:06:18.012
a951eb9a-4863-439a-b935-5f45fc378701	d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	manager	Manager	t	2026-08-09 09:06:18.028
a61b006b-3e16-44cf-914d-e76f5bc86021	d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	driver	Driver	t	2026-08-09 09:06:18.041
192d6fe2-a094-409d-b917-27bcce41a7b5	d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	farmer	Farmer	t	2026-08-09 09:06:18.043
6139daa9-c20e-47ee-9c25-9e49eca85344	82d1d4f0-a664-4442-afb1-3c8e8deec8f8	owner	Owner	t	2026-08-09 09:06:19.905
18dfa786-bc8d-4456-8653-81651105b5fc	82d1d4f0-a664-4442-afb1-3c8e8deec8f8	manager	Manager	t	2026-08-09 09:06:19.924
4aa5cecb-0650-4572-b047-21c9f3ff0dfa	82d1d4f0-a664-4442-afb1-3c8e8deec8f8	driver	Driver	t	2026-08-09 09:06:19.937
37556bd3-0d00-49ce-9ec6-2f06d3bc588b	82d1d4f0-a664-4442-afb1-3c8e8deec8f8	farmer	Farmer	t	2026-08-09 09:06:19.939
efba073a-5f49-46a1-b371-37cd2ea1d1fd	6571c3c9-9c94-4b02-ac20-829a9af731b6	owner	Owner	t	2026-08-09 08:45:02.206
9e39bf13-9d8a-437a-96d1-32177d0707c1	6571c3c9-9c94-4b02-ac20-829a9af731b6	manager	Manager	t	2026-08-09 08:45:02.214
1cb05a55-3d38-4df9-9e56-8746c499eb16	6571c3c9-9c94-4b02-ac20-829a9af731b6	driver	Driver	t	2026-08-09 08:45:02.217
3c79f31d-edef-4d4f-ba97-b8b3f20150cd	6571c3c9-9c94-4b02-ac20-829a9af731b6	farmer	Farmer	t	2026-08-09 08:45:02.22
55df06f2-e14b-4afa-9cc6-13f2f924b6a9	4613e40d-bba4-424a-970e-ffc7836a19e2	owner	Owner	t	2026-08-09 08:47:58.651
8001b294-130c-4948-9fdd-b80f14d2e8ef	4613e40d-bba4-424a-970e-ffc7836a19e2	manager	Manager	t	2026-08-09 08:47:58.654
188aa15c-e07b-474a-9fed-4f5ea67f9ba8	4613e40d-bba4-424a-970e-ffc7836a19e2	driver	Driver	t	2026-08-09 08:47:58.656
1a2e4593-3be9-430e-90d7-8ccd86d80e5a	4613e40d-bba4-424a-970e-ffc7836a19e2	farmer	Farmer	t	2026-08-09 08:47:58.658
d628b168-a02a-480c-9374-b116d0a6c888	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	owner	Owner	t	2026-08-09 08:53:41.458
2706db66-9e49-4c62-8a89-1c78328508ae	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	manager	Manager	t	2026-08-09 08:53:41.461
699d540e-63c5-400e-929b-824823849efd	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	driver	Driver	t	2026-08-09 08:53:41.463
8d55cda6-7664-4810-9e2a-947d254f6a64	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	farmer	Farmer	t	2026-08-09 08:53:41.465
007f474a-5501-4d53-8558-8174138cecc3	0757faaa-e55d-4863-9e88-c738651afa4c	owner	Owner	t	2026-08-09 09:06:25.812
775fe76d-8f31-4bde-a3b5-9b6f78060f10	0757faaa-e55d-4863-9e88-c738651afa4c	manager	Manager	t	2026-08-09 09:06:25.815
2411e3d7-0fb3-4c87-b72b-ef39384319fb	0757faaa-e55d-4863-9e88-c738651afa4c	driver	Driver	t	2026-08-09 09:06:25.817
2aac445f-9608-4cc6-8ec9-c559181a6b32	0757faaa-e55d-4863-9e88-c738651afa4c	farmer	Farmer	t	2026-08-09 09:06:25.819
61c08b33-a61f-42da-bb0f-8f82c787becb	1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	owner	Owner	t	2026-08-09 09:10:19.511
5e15cb39-93b2-4f61-af6a-70d7e952fba6	1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	manager	Manager	t	2026-08-09 09:10:19.54
800b0b99-3cf5-4281-a7e3-9585ed707b1b	1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	driver	Driver	t	2026-08-09 09:10:19.56
b903599e-e5b6-46e4-a827-f7295432febd	1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	farmer	Farmer	t	2026-08-09 09:10:19.561
a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	aeb2474e-c378-471b-ab64-81925a1bc912	owner	Owner	t	2026-08-09 09:10:21.504
0b11a7ff-b97f-47d1-b9f6-1c517b4fd00e	aeb2474e-c378-471b-ab64-81925a1bc912	manager	Manager	t	2026-08-09 09:10:21.538
2bcd66b8-9817-4e31-af16-b8066357f55e	aeb2474e-c378-471b-ab64-81925a1bc912	driver	Driver	t	2026-08-09 09:10:21.551
75174d6f-fccd-47af-9552-9bc085187785	aeb2474e-c378-471b-ab64-81925a1bc912	farmer	Farmer	t	2026-08-09 09:10:21.553
139ac13c-8fca-4a87-8fac-03cf341651b0	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	owner	Owner	t	2026-08-09 09:10:27.524
cf5fcc70-58d2-4fae-825b-96bf593fdc2c	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	manager	Manager	t	2026-08-09 09:10:27.528
39186c35-ea7a-4cb3-a9b7-03577d14e6c5	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	driver	Driver	t	2026-08-09 09:10:27.53
f7bc5ca3-e88f-4c74-b510-1f657cf68d83	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	farmer	Farmer	t	2026-08-09 09:10:27.532
\.


--
-- Data for Name: saas_customer_profiles; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.saas_customer_profiles (id, saas_user_id, business_name, contact_person, phone, email, address, city, state, pincode, gstin, pan, created_at, updated_at) FROM stdin;
f4c8dadd-6113-4549-983c-7f22d1c20262	567db271-c727-48d8-a006-cbffd4ef6125	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265135652@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:45:36.056	2026-08-09 08:45:36.056
3667ab81-dbd9-4d2f-ab72-a80a832f799d	eb7c5f04-73cd-4cab-9482-9d226ad5a76d	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265152673@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:45:53.083	2026-08-09 08:45:53.083
2ca04011-3446-4910-941e-40072cbd7822	8f50bd4d-ff05-4f80-b4a0-30467581d715	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265153355@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:45:53.523	2026-08-09 08:45:53.523
50d7b585-ff83-4232-95c1-b9dc3ce2a030	b2dd6b3c-c0af-460c-a1b1-2f51787c621a	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265162992@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:46:03.351	2026-08-09 08:46:03.351
67e52aaa-1041-4d2f-9c6d-0334ca84bd95	dca6e873-da45-4439-a37c-02ac7e773bfe	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265163624@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:46:03.786	2026-08-09 08:46:03.786
a2ceb46f-6ae3-482f-95ee-18ace0b0bf39	c3682f6c-b267-4092-a4a4-4a2ea61eb217	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265170936@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:46:11.334	2026-08-09 08:46:11.334
5d5fcbfa-d1ed-4661-a0db-e064e997e58b	334379fe-8e73-44c0-b273-e85494b33631	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265171601@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:46:11.76	2026-08-09 08:46:11.76
c58f49ef-9be9-43c8-ac38-218e500333ca	93db087c-2924-4c4a-bdbd-06fd6cacd476	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265180226@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:46:20.586	2026-08-09 08:46:20.586
7e88519a-a839-4de6-be14-221b936fc678	db6fe497-8cab-411a-8155-806b0f7b97c2	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265180854@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:46:21.023	2026-08-09 08:46:21.023
5eb26589-0540-4cdb-9bfa-a04281a97584	2a511485-aa8b-4935-8df8-c0342f273d0d	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265187570@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:46:27.946	2026-08-09 08:46:27.946
037d62b2-1f54-4a94-bf11-7b8a82fea0d5	cc521f60-b071-42d3-8181-7a3fc57ca34d	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265188225@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:46:28.41	2026-08-09 08:46:28.41
7f46e61b-c56b-4d21-a340-d82bdf9464e0	fb72511f-4cfc-4336-83b6-89ad5f3a6c33	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265194641@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:46:35.021	2026-08-09 08:46:35.021
91405caf-b377-4609-b758-97f6607d64a6	b2044d11-22a7-4df3-b2fe-5513b1011e2f	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265195305@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:46:35.47	2026-08-09 08:46:35.47
1265ca60-4737-4fd3-b3cf-f2da0f09cd3a	ccdcf26c-e31f-447e-b0df-6f637e12bcce	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265207886@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:46:48.259	2026-08-09 08:46:48.259
99f43da2-42bd-4e4b-9994-bfc81e186c17	42111db9-0356-432f-a7da-3d4d2d0ae543	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265208536@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:46:48.72	2026-08-09 08:46:48.72
3233e3e9-dbfd-48f2-96f4-0875e32f9dee	77ee71dd-600e-45ff-b9c6-2d16d46b0406	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786265219179@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 08:46:59.547	2026-08-09 08:46:59.547
949e8253-866f-4588-83d4-fc0b423b917b	c3e57732-ffb8-4289-b355-b5be0b7a4c4e	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786265219840@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 08:47:00.001	2026-08-09 08:47:00.001
fcabb908-6b36-4f5c-8fe0-8be3bea6e318	c144d6e8-9bbc-48cc-b536-c87b82b2a88d	ShabooAgri Platform Ops	Platform Admin	9876543210	saas_admin_1786266191020@shabooagri.com	\N	Ludhiana	Punjab	\N	\N	\N	2026-08-09 09:03:11.417	2026-08-09 09:03:11.417
6223c994-c736-4a73-b0d7-4dd73c56929c	3788bc3f-7d6f-4b2c-a823-226ca6160bcc	Suresh Custom Hiring Center	Suresh Owner	9811122233	saas_customer_1786266191667@example.com	\N	Karnal	Haryana	\N	\N	\N	2026-08-09 09:03:11.865	2026-08-09 09:03:11.865
\.


--
-- Data for Name: saas_leads; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.saas_leads (id, name, business_name, phone, email, source, status, follow_up_notes, assigned_admin_id, created_by_saas_user_id, created_at, updated_at) FROM stdin;
0cf9e959-d96a-45af-ae18-40a6c295d3f0	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265153294@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:45:53.308	2026-08-09 08:45:53.333
5db1446a-7da9-4cde-8400-2d5b3312bdb8	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265163561@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:46:03.566	2026-08-09 08:46:03.597
415e6631-dc59-42f4-9450-29088fba5082	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265171551@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:46:11.562	2026-08-09 08:46:11.58
dcaf2313-c690-4b6f-a499-900bfb3e7d85	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265180800@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:46:20.812	2026-08-09 08:46:20.831
36539548-a30f-4d5c-ae78-c110a229de02	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265188162@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:46:28.174	2026-08-09 08:46:28.201
274c7cf2-08a5-4485-bbb8-2a68d648f2a0	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265195240@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:46:35.254	2026-08-09 08:46:35.274
3ceb7901-5594-48f1-a2a0-6f6de6d9b620	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265208476@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:46:48.492	2026-08-09 08:46:48.513
5e0581ff-1b3f-4144-a77d-61ebdd9dad57	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786265219785@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 08:46:59.795	2026-08-09 08:46:59.818
e7e8cf8e-6504-4af7-9b67-0e9d0f5e4150	Ramesh Farmer Operations	Ramesh Agrotech Pvt Ltd	9876543210	ramesh_lead_1786266191605@example.com	WEBSITE	CONTACTED	Contacted via phone call for demo	\N	\N	2026-08-09 09:03:11.612	2026-08-09 09:03:11.638
\.


--
-- Data for Name: saas_payments; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.saas_payments (id, saas_user_id, license_id, gateway_order_id, gateway_payment_id, gateway_signature, payment_reference, base_amount, gst_amount, total_amount, cgst_amount, sgst_amount, igst_amount, currency, status, payment_method, gateway_payload, notes, created_at, updated_at) FROM stdin;
03cbe04e-f4cd-4d6e-9dd4-bb5382801245	cc521f60-b071-42d3-8181-7a3fc57ca34d	e5928390-9d9c-4d0c-b142-0efefd644b72	\N	\N	\N	TXN-BANK-998877	4236.44	762.56	4999.00	381.28	381.28	\N	INR	SUCCESS	BANK_TRANSFER	\N	Payment received for 1-year PRO license subscription	2026-08-09 08:46:28.464	2026-08-09 08:46:28.464
9ce19928-8cca-46c6-ac95-792b819b7928	b2044d11-22a7-4df3-b2fe-5513b1011e2f	0e399854-4b1a-4607-ad33-e592a9af6054	\N	\N	\N	TXN-BANK-998877	4236.44	762.56	4999.00	381.28	381.28	\N	INR	SUCCESS	BANK_TRANSFER	\N	Payment received for 1-year PRO license subscription	2026-08-09 08:46:35.528	2026-08-09 08:46:35.528
0cd7edff-989b-454d-bf3e-d8954a8aa2a3	3788bc3f-7d6f-4b2c-a823-226ca6160bcc	7f90a53c-60a8-41e8-a3f3-bcfe76410064	\N	\N	\N	TXN-BANK-998877	4236.44	762.56	4999.00	381.28	381.28	\N	INR	SUCCESS	BANK_TRANSFER	\N	Payment received for 1-year PRO license subscription	2026-08-09 09:03:11.917	2026-08-09 09:03:11.917
\.


--
-- Data for Name: saas_users; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.saas_users (id, email, phone, password_hash, is_email_verified, status, is_platform_admin, last_login_at, created_at, updated_at) FROM stdin;
567db271-c727-48d8-a006-cbffd4ef6125	saas_admin_1786265135652@shabooagri.com	9876543210	$2a$10$8tTDzGTIpQqZ9XGnYMm2XOd08jgm1/qJtHhfbVe.sSqyP4tVuOm2y	f	ACTIVE	t	2026-08-09 08:45:36.245	2026-08-09 08:45:36.054	2026-08-09 08:45:36.247
eb7c5f04-73cd-4cab-9482-9d226ad5a76d	saas_admin_1786265152673@shabooagri.com	9876543210	$2a$10$yfVWcNK5tWerMtQk0Sxix.GlwJ9Kk7hKIEJ8ZdIcwAWd6.Fww30DO	f	ACTIVE	t	2026-08-09 08:45:53.267	2026-08-09 08:45:53.081	2026-08-09 08:45:53.268
8f50bd4d-ff05-4f80-b4a0-30467581d715	saas_customer_1786265153355@example.com	9811122233	$2a$10$mXyRmrq2VikdEOasAt0g4OSWE4fCS2wePQ9H..jhZhIYF40noCUBa	f	ACTIVE	f	\N	2026-08-09 08:45:53.522	2026-08-09 08:45:53.522
b2dd6b3c-c0af-460c-a1b1-2f51787c621a	saas_admin_1786265162992@shabooagri.com	9876543210	$2a$10$DP/nMf3db1EhqzSrOmDKx.tUgFBsJvDvuGiUyW0FsQbxZx8fKMsku	f	ACTIVE	t	2026-08-09 08:46:03.541	2026-08-09 08:46:03.349	2026-08-09 08:46:03.542
dca6e873-da45-4439-a37c-02ac7e773bfe	saas_customer_1786265163624@example.com	9811122233	$2a$10$OZV0WViuzo5GxkmTLsT6T.XW5pbpfleod0658T.pSEB7/Bi.DQMD.	f	ACTIVE	f	\N	2026-08-09 08:46:03.785	2026-08-09 08:46:03.785
c144d6e8-9bbc-48cc-b536-c87b82b2a88d	saas_admin_1786266191020@shabooagri.com	9876543210	$2a$10$7X1O80Ex/NtttN3Lr2TyB.GNI79IpTx6.o7xci6jK6QkS8IaI1w62	f	ACTIVE	t	2026-08-09 09:03:11.57	2026-08-09 09:03:11.415	2026-08-09 09:03:11.571
c3682f6c-b267-4092-a4a4-4a2ea61eb217	saas_admin_1786265170936@shabooagri.com	9876543210	$2a$10$3x5noXn9h/bBXQlEV.gxR.pyOUhoW/l3yi.DOkFATVI/jS271Jxie	f	ACTIVE	t	2026-08-09 08:46:11.521	2026-08-09 08:46:11.332	2026-08-09 08:46:11.522
334379fe-8e73-44c0-b273-e85494b33631	saas_customer_1786265171601@example.com	9811122233	$2a$10$58HICQdvU.d1KkrmZwgo2ucN4Vr.o64l6celXbHtlA447oEeNZLy2	f	ACTIVE	f	\N	2026-08-09 08:46:11.759	2026-08-09 08:46:11.759
93db087c-2924-4c4a-bdbd-06fd6cacd476	saas_admin_1786265180226@shabooagri.com	9876543210	$2a$10$AAjK/oXAZ00Gg7goqbXk3.i1nGyozS9M5osKss1vReJCvf9J9wOW6	f	ACTIVE	t	2026-08-09 08:46:20.776	2026-08-09 08:46:20.584	2026-08-09 08:46:20.777
db6fe497-8cab-411a-8155-806b0f7b97c2	saas_customer_1786265180854@example.com	9811122233	$2a$10$gN0UudB0gS9xEeLrR9ewwubuQht1tcTp0fvRZq6DP3Tynbxj5Qbp6	f	ACTIVE	f	\N	2026-08-09 08:46:21.022	2026-08-09 08:46:21.022
2a511485-aa8b-4935-8df8-c0342f273d0d	saas_admin_1786265187570@shabooagri.com	9876543210	$2a$10$apQcql0i9dPFa0/NS9dL9OyDpZF2iVJ8mU8Rn.ZYgRCyS7YH3FKke	f	ACTIVE	t	2026-08-09 08:46:28.122	2026-08-09 08:46:27.943	2026-08-09 08:46:28.123
cc521f60-b071-42d3-8181-7a3fc57ca34d	saas_customer_1786265188225@example.com	9811122233	$2a$10$pzt6RobCvVbl3l9MzZz/kO4y76a8WzsHRraepJAxelQIooS2Z2NbG	f	ACTIVE	f	\N	2026-08-09 08:46:28.409	2026-08-09 08:46:28.409
3788bc3f-7d6f-4b2c-a823-226ca6160bcc	saas_customer_1786266191667@example.com	9811122233	$2a$10$BUieubAXYf3loeFC5S0DseuPf542l1.cyeH1GSX/yV4QAp72bRLeW	f	ACTIVE	f	\N	2026-08-09 09:03:11.864	2026-08-09 09:03:11.864
fb72511f-4cfc-4336-83b6-89ad5f3a6c33	saas_admin_1786265194641@shabooagri.com	9876543210	$2a$10$4n4WCCh7Rd2UUehRKyWmxOr8BoAOIJyD0fEa3T5WefZMRrCGoiWTu	f	ACTIVE	t	2026-08-09 08:46:35.216	2026-08-09 08:46:35.018	2026-08-09 08:46:35.217
b2044d11-22a7-4df3-b2fe-5513b1011e2f	saas_customer_1786265195305@example.com	9811122233	$2a$10$pdFIkL2.qPL0q9Epm3/QvOiD1zcIUAteGtkjx56wRpdIwhKz.Ap4.	f	ACTIVE	f	\N	2026-08-09 08:46:35.469	2026-08-09 08:46:35.469
ccdcf26c-e31f-447e-b0df-6f637e12bcce	saas_admin_1786265207886@shabooagri.com	9876543210	$2a$10$LxFfMCGwslnfC.B4VQSqKufRMy0C3LaXVv1ONTJ98Cp/BaLlTTj2C	f	ACTIVE	t	2026-08-09 08:46:48.44	2026-08-09 08:46:48.257	2026-08-09 08:46:48.441
42111db9-0356-432f-a7da-3d4d2d0ae543	saas_customer_1786265208536@example.com	9811122233	$2a$10$fs/tmq7NDwjk5cL3szZ/BOOZFApuVC3vPWpU04/wVHryKRvB8Q4vG	f	ACTIVE	f	\N	2026-08-09 08:46:48.718	2026-08-09 08:46:48.718
77ee71dd-600e-45ff-b9c6-2d16d46b0406	saas_admin_1786265219179@shabooagri.com	9876543210	$2a$10$7XJbp9DR/oJkiW4pxX4sfOpFUFs2JZg1baLsIZnTzx.qrDz5XNICu	f	ACTIVE	t	2026-08-09 08:46:59.742	2026-08-09 08:46:59.545	2026-08-09 08:46:59.743
c3e57732-ffb8-4289-b355-b5be0b7a4c4e	saas_customer_1786265219840@example.com	9811122233	$2a$10$5jhGdWAINuxAILL6xiQdau.2j7zG5uoUv0PsfrzhdTwAJjOgd4yc6	f	ACTIVE	f	\N	2026-08-09 08:46:59.999	2026-08-09 08:46:59.999
\.


--
-- Data for Name: sso_tokens; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.sso_tokens (id, token_hash, saas_user_id, company_id, user_id, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: terminology_settings; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.terminology_settings (id, company_id, term_key, display_label_singular, display_label_plural, created_at, updated_at) FROM stdin;
5c83664a-9529-4c10-947a-679e26a7a45d	29c82d91-d80e-4358-a180-dd5df8cae889	driver	Driver	Drivers	2026-08-07 18:54:04.657	2026-08-07 18:54:04.657
e199acf5-42aa-4300-9a20-cf19d4b6264a	29c82d91-d80e-4358-a180-dd5df8cae889	machine	Machine	Machines	2026-08-07 18:54:04.662	2026-08-07 18:54:04.662
3f9e286a-b34e-4569-8c74-cca2832f5c72	29c82d91-d80e-4358-a180-dd5df8cae889	booking	Booking	Bookings	2026-08-07 18:54:04.665	2026-08-07 18:54:04.665
3b7b7375-ac7c-4667-85d2-7c7628ca3418	29c82d91-d80e-4358-a180-dd5df8cae889	invoice	Invoice	Invoices	2026-08-07 18:54:04.668	2026-08-07 18:54:04.668
03dcf604-aa46-4d5f-ab7a-ff261cc231e5	74dcfe64-85b0-4051-9c2c-8292caf839ea	customer	Client	Clients	2026-08-08 18:05:31.911	2026-08-08 18:05:31.911
0bc85ba0-bc65-4310-afaa-4cb6023a6313	74dcfe64-85b0-4051-9c2c-8292caf839ea	driver	Pilot	Pilots	2026-08-08 18:05:31.912	2026-08-08 18:05:31.912
3dc27095-72e6-4151-8d77-2272650affdf	2fc53fa9-07fd-4172-af37-6a1034df9ecb	customer	Grower	Growers	2026-08-08 18:05:31.926	2026-08-08 18:05:31.926
1e5a1ccd-fe56-4280-b018-e7fc40732841	2fc53fa9-07fd-4172-af37-6a1034df9ecb	driver	Operator	Operators	2026-08-08 18:05:31.926	2026-08-08 18:05:31.926
18c66b29-1bf0-4c0d-92fa-577014813e5c	29c82d91-d80e-4358-a180-dd5df8cae889	customer	Farmer	Farmers	2026-08-07 18:54:04.651	2026-08-09 05:12:55.436
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.users (id, company_id, role_id, full_name, email, mobile_number, password_hash, pin_hash, status, last_login_at, created_at, updated_at) FROM stdin;
35b8db9a-eb66-4510-a522-3b1404c795ae	40511429-f937-4f0f-8a0a-6869154b7144	ce2949bc-4f5a-49e5-87af-6092d06c6d22	Alpha Owner	alpha.owner.1786212275037@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:35.456	2026-08-08 18:04:35.456
76d438a4-8d4f-4a0d-9b7c-a68b3d8bfaf0	40511429-f937-4f0f-8a0a-6869154b7144	1d263619-3889-40b8-a1f7-1b804d6e1403	Alpha Manager	alpha.manager.1786212275037@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:35.459	2026-08-08 18:04:35.459
0ceb3511-6cba-4438-8c8c-35cc4135f3ba	8fbaf386-5fd4-44cb-9119-9108a7c653c2	05c60e5e-2664-45a2-9cbe-5a766c096f86	Beta Owner	beta.owner.1786212275037@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:35.461	2026-08-08 18:04:35.461
26ee743e-e3a4-4e26-ade5-4ae11b4396a2	8fbaf386-5fd4-44cb-9119-9108a7c653c2	6f006da6-ec24-4082-b62b-ba1197f8f456	Beta Manager	beta.manager.1786212275037@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:35.463	2026-08-08 18:04:35.463
783a8bf0-e295-4166-a6a4-d2cd3770cf4b	99690b52-8af1-4813-b8a1-4af071a81549	69c95746-861e-4f84-afe4-ec42b734eff9	Alpha Owner	alpha.owner.1786212285428@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:45.859	2026-08-08 18:04:45.859
8ce57427-0917-4c5d-9be3-1e9b8e789364	99690b52-8af1-4813-b8a1-4af071a81549	3c742dbf-418b-49c8-af8b-64d442341049	Alpha Manager	alpha.manager.1786212285428@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:45.862	2026-08-08 18:04:45.862
49d25e18-df9c-401d-b015-56bd09a1fe2c	1a1ead59-2b11-4f2a-85e5-71c30252fbab	9a708670-fd58-41ae-b6ef-8f32b2ba5fe5	Beta Owner	beta.owner.1786212285428@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:45.864	2026-08-08 18:04:45.864
6f26272f-3e56-40b8-a486-c1975429be90	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786194011645@example.com	\N	$2a$10$XRPb057twoEca7O0gXZYd.DhWQ69n1p9kL/zEAlsOch8ZlMwai882	\N	ACTIVE	\N	2026-08-08 13:00:12.184	2026-08-08 13:00:12.184
50d522b8-7408-45ff-92d6-94940afce6d5	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786194024967@example.com	\N	$2a$10$Yj5XsA5p1c5VCjKpzG0vlOGgENAkHmXBS3ZrFxZk8sZ8NNkIVT3KO	\N	ACTIVE	\N	2026-08-08 13:00:25.095	2026-08-08 13:00:25.095
285398bc-25da-468a-a0e4-313e33a05758	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786194024967@example.com	\N	$2a$10$/ZUzxHXHcnIAx4qSX/joPuSf6tBqC5XuAdYygB/L4wSVyTPhzU2Ma	\N	ACTIVE	\N	2026-08-08 13:00:25.216	2026-08-08 13:00:25.216
c694878f-d1df-471d-8b15-c85b96a5dd69	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786194024967@example.com	\N	$2a$10$Ynr9FyY1lNVyq/SRsiEi4uWCN4h5ScvZaAeTaLppoe/ZK8q5u7vTa	\N	ACTIVE	\N	2026-08-08 13:00:25.32	2026-08-08 13:00:25.32
0d2a6a28-0e51-4e12-af93-6e9363d345ac	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786188148080@example.com	\N	$2a$10$asKvFAeIG9b1eQ2UfI3Tiey/bamIT4T1IkvVx4UEtjlIaxiLQ984G	\N	ACTIVE	\N	2026-08-08 11:22:28.307	2026-08-08 11:22:28.307
9fedc74c-7d55-4b9e-a83c-3ee98b982045	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786214839734	farmerA_1786214839734@example.com	\N	$2a$10$V1pbQHSISxpof2eAFBjxFOCgx4VQRpYx/MBy6yGJEzdY5pw95nR6m	\N	ACTIVE	\N	2026-08-08 18:47:19.864	2026-08-08 18:47:19.864
77bd485b-e684-4fdb-82ff-022adbdba3e1	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786214839734	farmerB_1786214839734@example.com	\N	$2a$10$1WnWm6Cxl8Yv4Sndsrbo6OiifKG3Sag0/lSZe0f8TsrGBFHrNH6Lm	\N	ACTIVE	\N	2026-08-08 18:47:19.979	2026-08-08 18:47:19.979
3fc1932a-3cb1-4fc4-95b3-0eec98915d6d	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786214855482	farmerA_1786214855482@example.com	\N	$2a$10$G/8.ERjAbBISf/numjs44udvvXl1WMU7JfF60ThcqrQn9Cn2d2XYu	\N	ACTIVE	\N	2026-08-08 18:47:35.623	2026-08-08 18:47:35.623
d1d6d8e0-0973-49a2-b42f-ad63af9bf613	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786214855482	farmerB_1786214855482@example.com	\N	$2a$10$2qTpI/MPGNGn87MiSzdoA.WkgMYwM6b8L3FPPamzGR5AWJi5EcKIO	\N	ACTIVE	\N	2026-08-08 18:47:35.742	2026-08-08 18:47:35.742
eae1320c-7483-4857-97e1-0e91457d2dac	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786214868737	farmerA_1786214868737@example.com	\N	$2a$10$hh.ae511fIv.wzaaG.2RDONro2dU8ujaDKHvMO8PG6T7XzF0mDgZq	\N	ACTIVE	\N	2026-08-08 18:47:48.869	2026-08-08 18:47:48.869
a53f34f2-1634-4356-a7dd-d662d5045d7b	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786214868737	farmerB_1786214868737@example.com	\N	$2a$10$XGwz0v5ZXgKVeZ5mL4Ve1eUXcy3Vn6tfvhgVnZjEorRaP6FkFIZFG	\N	ACTIVE	\N	2026-08-08 18:47:48.996	2026-08-08 18:47:48.996
8b84b9c2-4955-468b-b628-15d395979415	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786188148080@example.com	\N	$2a$10$clDlwEALCLuOZ7bDVIpZ1uNrBnJpXZWKu8UlvrYo4/1IAVIaM..YK	\N	ACTIVE	\N	2026-08-08 11:22:28.408	2026-08-08 11:22:28.408
83478eef-2314-446a-bb5c-112a5b6cdc1a	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786188148080@example.com	\N	$2a$10$903rdeXS67cECkWzHyNYIOmkQVa0jF4DU.2oFIMIpbuBnVBuJ1BD.	\N	ACTIVE	\N	2026-08-08 11:22:28.53	2026-08-08 11:22:28.53
b1dc55b7-db88-404a-ab36-ceed3d7fa209	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786193958202@example.com	\N	$2a$10$ayFNmvwA9P2.ibibbi6yCuDuz1p9KMrUTjtjFyng06c0ZaIK1dFu6	\N	ACTIVE	\N	2026-08-08 12:59:18.324	2026-08-08 12:59:18.324
1be0e29b-8bcd-4c59-a82b-ca1bd7ac595c	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786193958202@example.com	\N	$2a$10$twUIZXYg9F8ba/zaWMTV.e1WZLpQMuJ/rud13jpKnD13fKuNu5.6O	\N	ACTIVE	\N	2026-08-08 12:59:18.435	2026-08-08 12:59:18.435
1f1be4bf-9cf7-447e-afd3-4d07dd67dbeb	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786193958202@example.com	\N	$2a$10$TVkISxlQmZqcUDdopLT3cOMnsI.g52FQGpapLWSJx2KymXDzL.i0e	\N	ACTIVE	\N	2026-08-08 12:59:18.555	2026-08-08 12:59:18.555
fdcdafd5-3dbb-4313-b56e-2f1be6a05021	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786193965470@example.com	\N	$2a$10$11D6dDo567ZRmgp9dGGPeOm7MsOR2dL4QHIKlcpSaqfn1HUCYwOPa	\N	ACTIVE	\N	2026-08-08 12:59:25.584	2026-08-08 12:59:25.584
1043524c-c719-4b0b-a2ec-50c6f40c2afe	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786193965470@example.com	\N	$2a$10$7qnAPbCMpAL9agzNChyusuN/qpdiMIH4pl3w2.3BdDBLDC3sTfMs2	\N	ACTIVE	\N	2026-08-08 12:59:25.696	2026-08-08 12:59:25.696
a7428dcc-c14f-4458-b037-f642aac32c37	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786193965470@example.com	\N	$2a$10$4IHfkRme4rR5/e3TYfMRHeSPjYAxit.yOHKbjhdYN0CtDUYkdx..y	\N	ACTIVE	\N	2026-08-08 12:59:25.817	2026-08-08 12:59:25.817
2717d7c9-e438-4b56-9912-e1b7fa6c13fe	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786193980360@example.com	\N	$2a$10$SZb.4MGKrxgZy95rYdyY3ujfSX5dYaayGD2OW5Ev6a0CTVM5mUDVy	\N	ACTIVE	\N	2026-08-08 12:59:40.478	2026-08-08 12:59:40.478
7af3ee62-fb06-468e-b1b5-50bbe436ef27	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786193980360@example.com	\N	$2a$10$.S.etN3lMfuscHyM4H7RQOSCKRxhOLos4Mf7azOR.M13Js1qNi0hG	\N	ACTIVE	\N	2026-08-08 12:59:40.59	2026-08-08 12:59:40.59
256b445c-9a8b-4ac2-a9b6-32a4140e3a8c	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786193980360@example.com	\N	$2a$10$EjUMz3rvQseufpfPsCBZ2uNtz37Rdzsi.Gl77u03rc4f15CxwNYye	\N	ACTIVE	\N	2026-08-08 12:59:40.693	2026-08-08 12:59:40.693
8f192145-abd8-4134-a793-cc334fdc39a3	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786194011645@example.com	\N	$2a$10$36gAr0euBzudAoXkF6JLle3AHUqM2evyA7GKrMNoI1321J76i86pa	\N	ACTIVE	\N	2026-08-08 13:00:11.82	2026-08-08 13:00:11.82
494a5df6-94ed-468e-8a28-07391add83e4	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786194011645@example.com	\N	$2a$10$YJfyH9YpdnMS7rWCslt6aubeVQc1KCRdYnfFJDY6ThpYLPrqQxH/K	\N	ACTIVE	\N	2026-08-08 13:00:11.988	2026-08-08 13:00:11.988
f52fc1ff-b111-48bc-9607-6956c468e503	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786194033738@example.com	\N	$2a$10$I8sQtFQ3XEKIB3stq9J/1Oh8yQbv8b.0B00HJB/fBO0bPreieJ93a	\N	ACTIVE	\N	2026-08-08 13:00:33.854	2026-08-08 13:00:33.854
b8beb125-7a83-4630-8d00-29e7fc27135b	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786194033738@example.com	\N	$2a$10$juTTZwKrxFumLsMCJZQ28u4pQEzJsVTHg5d4ctEoVvlQT27CQf.se	\N	ACTIVE	\N	2026-08-08 13:00:33.962	2026-08-08 13:00:33.962
d3f33915-80b8-4831-9454-78ace16917cb	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786194033738@example.com	\N	$2a$10$Fx/lePrPQNTEXRu28IEjEuNo/XeK0XsgU/uLX5Md9tURVWbmA/7i.	\N	ACTIVE	\N	2026-08-08 13:00:34.063	2026-08-08 13:00:34.063
4d6b0f11-97df-48d7-bbeb-38ccbc403d86	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786194042640@example.com	\N	$2a$10$627Icn5vMCPHES7VFPeXGutgmcS92LBCk/79C83EHb87kS8eDqwD6	\N	ACTIVE	\N	2026-08-08 13:00:42.758	2026-08-08 13:00:42.758
2286372b-bfa0-4e12-94e9-1de8b3c3a21c	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786194042640@example.com	\N	$2a$10$APE4LXyw3SrqXbC59PWFzOaYvGIZDr1FCyA68El/w/zcYC/kljqCe	\N	ACTIVE	\N	2026-08-08 13:00:42.882	2026-08-08 13:00:42.882
14b1fccf-438e-455b-a4ac-35cc6093bcfd	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786194042640@example.com	\N	$2a$10$TapzvpLiHhYdQrTt4/v8lOkw1YwMq9eyy..DVN.EaR9EB/.KbLV26	\N	ACTIVE	\N	2026-08-08 13:00:42.984	2026-08-08 13:00:42.984
3d4923f6-aaba-49cf-adf6-742e64110ebd	1a1ead59-2b11-4f2a-85e5-71c30252fbab	aeba451d-4106-4d98-a01e-2821921c1657	Beta Manager	beta.manager.1786212285428@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:45.866	2026-08-08 18:04:45.866
ab5f0de9-29dd-4fa0-935a-240c3e920d5e	98052597-43cc-4b9a-a12b-72260f7e39ff	3bf67871-202c-4818-9bae-87e89c161209	Alpha Owner	alpha.owner.1786212295780@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:56.237	2026-08-08 18:04:56.237
0e841aca-d7dc-4a11-90d2-54ce145147d3	98052597-43cc-4b9a-a12b-72260f7e39ff	24c8ae9a-c82f-493f-b44a-5f8f38542f03	Alpha Manager	alpha.manager.1786212295780@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:56.24	2026-08-08 18:04:56.24
f0fad720-3155-4508-8d2d-67ce7490d6c7	c40dd20c-a216-4766-8dd3-db89037b4bc4	a6321639-6f3d-4cb0-aff9-2e9d1e86507f	Beta Owner	beta.owner.1786212295780@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:56.242	2026-08-08 18:04:56.242
b45d52d2-28f8-42d3-a55d-062a35b825ad	c40dd20c-a216-4766-8dd3-db89037b4bc4	1d449871-5e7b-4dfd-b8ec-7d7cdbe33b40	Beta Manager	beta.manager.1786212295780@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:04:56.244	2026-08-08 18:04:56.244
ddbf6bdf-40ec-4f23-8f80-7f010535199f	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	78653bba-bd97-4d35-bcef-b2583e800502	Alpha Owner	alpha.owner.1786212306832@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:07.293	2026-08-08 18:05:07.293
a8b0f6bc-2165-4a59-9c60-1095c4168540	c1abe6e7-ea71-4ee9-895f-43ce1f22863a	7cc6517a-684a-4814-be72-886b6852cb89	Alpha Manager	alpha.manager.1786212306832@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:07.296	2026-08-08 18:05:07.296
8ca04166-6dfb-4a8e-8b07-04aa362ac5cf	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	01ae030a-f6c3-43e0-89d5-5c2f5ffa66ba	Beta Owner	beta.owner.1786212306832@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:07.298	2026-08-08 18:05:07.298
7c95f16c-442c-4bba-b31a-81b8821e313b	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	a585a67a-51eb-4c03-8c32-dd6564a9a099	Beta Manager	beta.manager.1786212306832@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:07.3	2026-08-08 18:05:07.3
c15d8295-5312-4d4d-921e-e3fa00641348	3e8490bb-07a1-497f-8b5b-8f2e470cf284	6824152d-d3c2-43a8-b23a-189adbe8ffa3	Alpha Owner	alpha.owner.1786212317057@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:17.47	2026-08-08 18:05:17.47
db42f5b8-a06b-4320-9e68-352f423a2757	3e8490bb-07a1-497f-8b5b-8f2e470cf284	4e713e8b-86b0-4f77-a93f-a3044be417ce	Alpha Manager	alpha.manager.1786212317057@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:17.473	2026-08-08 18:05:17.473
45c7c5ba-3a79-4cdd-9c6f-b61488bafe79	a6565866-d95e-4c4c-a2eb-76f3171c2907	380f1e42-a55b-419c-9351-3ff2b8bb0e79	Beta Owner	beta.owner.1786212317057@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:17.475	2026-08-08 18:05:17.475
756343b9-5737-4fe3-8505-0a294e322cd8	a6565866-d95e-4c4c-a2eb-76f3171c2907	c2c56b7a-7585-4d85-8333-d3a2f0b223f2	Beta Manager	beta.manager.1786212317057@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:17.477	2026-08-08 18:05:17.477
6089c6bd-742f-424c-8c9e-e1dba617ec19	74dcfe64-85b0-4051-9c2c-8292caf839ea	9c9439fd-b33f-4294-9cd2-a5ca3175e606	Alpha Owner	alpha.owner.1786212331132@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:31.549	2026-08-08 18:05:31.549
6233fb89-68db-4a83-b72e-7770af3fe2fb	2fc53fa9-07fd-4172-af37-6a1034df9ecb	669d9173-d488-40a6-a075-318f30e31250	Beta Owner	beta.owner.1786212331132@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:31.558	2026-08-08 18:05:31.558
7483a070-5bda-427f-aca4-841789bdd852	2fc53fa9-07fd-4172-af37-6a1034df9ecb	65dbd982-7d3b-4ea1-85f7-6e75a5b39658	Beta Manager	beta.manager.1786212331132@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:31.56	2026-08-08 18:05:31.56
fea848ba-1aa2-419d-891f-c8e4aa8d5ce6	b51f455a-feb6-445f-8b08-8624162dc98b	36a6513b-ad30-45bc-90be-bd09352b2994	Manager Rajesh	manager-1786212907488@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:07.488	2026-08-08 18:15:07.488
8050e139-d2b7-474a-9deb-751e93e8b89b	74dcfe64-85b0-4051-9c2c-8292caf839ea	67f0bafb-e1b8-4881-aa21-decb8a923e56	Alpha Manager	alpha.manager.1786212331132@test.com	\N	hash	\N	ACTIVE	\N	2026-08-08 18:05:31.555	2026-08-08 18:05:31.877
05463cee-4474-49cd-aee6-b6660fa5c4e9	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Rajesh Kumar (Manager)	manager@shabooagri.com	8888888888	$2a$10$H.f5sFDQ/iDFvdwnz5Bu6u8lYLPqAGsdqAAzx2FjwK06Bzl7eH6ty	\N	ACTIVE	\N	2026-08-08 18:28:02.981	2026-08-09 05:12:55.556
c1f7954a-4ecc-41f5-a77c-2954ca9ea5f1	b51f455a-feb6-445f-8b08-8624162dc98b	3b4b6bf2-204e-4e11-a54f-9638ac64bde3	Farmer Ramesh	farmer-1786212907491@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:07.492	2026-08-08 18:15:07.492
ba687c38-786a-44a9-9e55-33eafbe517a2	b51f455a-feb6-445f-8b08-8624162dc98b	c6d04e8f-f718-4898-a0f4-987f98331d75	Hourly Driver Vikas	driver-hourly-1786212907493@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:07.494	2026-08-08 18:15:07.494
457304db-d5ee-4177-a472-0d10bfb78c85	b51f455a-feb6-445f-8b08-8624162dc98b	c6d04e8f-f718-4898-a0f4-987f98331d75	Monthly Driver Sunil	driver-monthly-1786212907495@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:07.496	2026-08-08 18:15:07.496
3a2bd4c2-7411-48fb-ad25-b59fdd5b977f	3b4fa961-b987-4207-bade-425969e8e1a5	bbb2c358-1b37-48d1-bd85-f8a097344680	Manager Rajesh	manager-1786212915586@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:15.587	2026-08-08 18:15:15.587
553a8bfb-583e-488a-9b21-0abf99c52f51	c331e53c-fe17-49c2-97f1-9466a87bbe42	71bae2da-4175-44fa-bd7e-a0d4b424f4f1	Manager Rajesh	manager-1786212891915@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:51.916	2026-08-08 18:14:51.916
3e6b46be-0246-4335-ae72-a7995674e8b5	c331e53c-fe17-49c2-97f1-9466a87bbe42	34be6d44-2265-4373-9f9c-ecf23682170a	Farmer Ramesh	farmer-1786212891919@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:51.919	2026-08-08 18:14:51.919
1d2923b0-675e-4401-81eb-22aad4b75fed	c331e53c-fe17-49c2-97f1-9466a87bbe42	ff6f78c5-e06b-4a0b-b954-483d2890c815	Hourly Driver Vikas	driver-hourly-1786212891921@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:51.922	2026-08-08 18:14:51.922
54068309-1670-4f8b-a2eb-7996f355de0b	c331e53c-fe17-49c2-97f1-9466a87bbe42	ff6f78c5-e06b-4a0b-b954-483d2890c815	Monthly Driver Sunil	driver-monthly-1786212891923@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:51.924	2026-08-08 18:14:51.924
43848b32-25a4-4d4f-81b6-2a0d65d35521	a7ed8578-e3b6-4aec-91b1-214d09748c0e	a14bcc01-6ae6-4d4b-aec2-f20a39c6f1e9	Manager Rajesh	manager-1786212898577@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:58.578	2026-08-08 18:14:58.578
6f67e85e-d36b-49ef-be76-fad2ae9dfe2f	a7ed8578-e3b6-4aec-91b1-214d09748c0e	8e444def-5a00-4cd5-82a5-3f9a818d5014	Farmer Ramesh	farmer-1786212898580@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:58.581	2026-08-08 18:14:58.581
9cac4fe6-b878-4f35-b049-e136dedd6ef4	a7ed8578-e3b6-4aec-91b1-214d09748c0e	79304598-f759-430d-9028-00e0a5fee776	Hourly Driver Vikas	driver-hourly-1786212898582@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:58.583	2026-08-08 18:14:58.583
90390d0c-1c5e-4109-89e2-83ac41372ce6	a7ed8578-e3b6-4aec-91b1-214d09748c0e	79304598-f759-430d-9028-00e0a5fee776	Monthly Driver Sunil	driver-monthly-1786212898584@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:14:58.585	2026-08-08 18:14:58.585
8535a885-c574-417f-b3c4-c8c3c3d32eea	3b4fa961-b987-4207-bade-425969e8e1a5	df141565-0fc7-4489-b497-3f771020d671	Farmer Ramesh	farmer-1786212915589@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:15.59	2026-08-08 18:15:15.59
dd786252-09eb-4204-9bf1-e6a4c7b6edb1	3b4fa961-b987-4207-bade-425969e8e1a5	096d5383-dc82-4306-84b6-a6a7a1234bf8	Hourly Driver Vikas	driver-hourly-1786212915591@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:15.592	2026-08-08 18:15:15.592
f725d362-797b-4e7c-99df-1ece13e5449b	3b4fa961-b987-4207-bade-425969e8e1a5	096d5383-dc82-4306-84b6-a6a7a1234bf8	Monthly Driver Sunil	driver-monthly-1786212915593@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:15.594	2026-08-08 18:15:15.594
0c1afcca-5848-4c3c-a2c0-c9b31b0c93f7	024b72fd-44b2-4f38-96c1-78b156fa58c2	ff57d6f5-4c23-4501-9e20-7318a6fca73c	Manager Rajesh	manager-1786213353396@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.397	2026-08-08 18:22:33.397
88fa7f2f-6dd4-4fda-becd-197706096891	024b72fd-44b2-4f38-96c1-78b156fa58c2	dcc0a6c3-5ee0-43e8-ab26-a9f7e26fb83d	Farmer Ramesh	farmer-1786213353399@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.4	2026-08-08 18:22:33.4
eb3706f2-5558-49f2-9e5e-3e5e4b0829ea	023866d9-236a-41cc-a36f-b9e516720f54	4e005b1b-d37b-46f9-a834-bd1a7e689917	Manager Rajesh	manager-1786212942873@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:42.873	2026-08-08 18:15:42.873
317c474a-ce1f-4313-8dff-0d42ad233b92	023866d9-236a-41cc-a36f-b9e516720f54	bedfcea4-f961-4594-b8c1-88b87ee386a8	Farmer Ramesh	farmer-1786212942876@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:42.876	2026-08-08 18:15:42.876
55559d6e-72ff-4b5b-8316-3e85da1c918a	023866d9-236a-41cc-a36f-b9e516720f54	20f3712f-d8f1-4d1f-80f5-fa0910e25928	Hourly Driver Vikas	driver-hourly-1786212942878@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:42.878	2026-08-08 18:15:42.878
41456b6b-ad9c-4ffc-8450-e92064c099e4	023866d9-236a-41cc-a36f-b9e516720f54	20f3712f-d8f1-4d1f-80f5-fa0910e25928	Monthly Driver Sunil	driver-monthly-1786212942880@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:15:42.88	2026-08-08 18:15:42.88
8adb2011-ff63-42b6-ae52-4f4c93b9cc57	024b72fd-44b2-4f38-96c1-78b156fa58c2	86efdde7-581e-4dc0-aad4-50717decaff2	Hourly Driver Vikas	driver-hourly-1786213353401@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.402	2026-08-08 18:22:33.402
864750ba-da80-415a-982e-ffe3ef62b1eb	024b72fd-44b2-4f38-96c1-78b156fa58c2	86efdde7-581e-4dc0-aad4-50717decaff2	Monthly Driver Sunil	driver-monthly-1786213353404@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.404	2026-08-08 18:22:33.404
4b32f683-4aa3-4e25-ac68-f6304277e701	024b72fd-44b2-4f38-96c1-78b156fa58c2	86efdde7-581e-4dc0-aad4-50717decaff2	Yearly Driver Amit	driver-yearly-1786213353406@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:22:33.406	2026-08-08 18:22:33.406
7d49f586-0061-459d-a0e0-aeffe249a367	f33c8ba7-f382-4217-90cf-d9d133632537	258eb3eb-7195-4f09-ab45-33dd488e92ca	Manager Rajesh	manager-1786213431660@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.661	2026-08-08 18:23:51.661
9cf88260-88ea-460b-a41a-f0b4e4337f74	f33c8ba7-f382-4217-90cf-d9d133632537	03e0773d-e554-44f1-b5f1-67f454abd10f	Farmer Ramesh	farmer-1786213431663@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.664	2026-08-08 18:23:51.664
12089328-66bc-4f40-86d7-90509e6a3d4b	f33c8ba7-f382-4217-90cf-d9d133632537	5e5ba701-e7a5-4d6d-8a77-2df6b2261fd7	Hourly Driver Vikas	driver-hourly-1786213431666@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.667	2026-08-08 18:23:51.667
fb92713a-712d-44e2-9731-faed364966c0	f33c8ba7-f382-4217-90cf-d9d133632537	5e5ba701-e7a5-4d6d-8a77-2df6b2261fd7	Monthly Driver Sunil	driver-monthly-1786213431668@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.669	2026-08-08 18:23:51.669
56da3671-5108-42a2-8609-de67319ad7b7	f33c8ba7-f382-4217-90cf-d9d133632537	5e5ba701-e7a5-4d6d-8a77-2df6b2261fd7	Yearly Driver Amit	driver-yearly-1786213431670@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:23:51.671	2026-08-08 18:23:51.671
72a391c8-c511-46ee-a879-5e6e3a61b77e	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Manoranjan Das	Dasmanoranjan798@gmail.com	9145751663	$2a$10$csV9dniT56DIfIKK9BWJL.wUHpvtZZE1o1bZ9iAMeBObQLEKIFSWS	\N	ACTIVE	2026-08-09 06:45:20.562	2026-08-08 18:28:02.975	2026-08-09 06:45:20.563
0a738759-a63b-4f4e-8862-08939dfec98e	6571c3c9-9c94-4b02-ac20-829a9af731b6	9e39bf13-9d8a-437a-96d1-32177d0707c1	Manager Rajesh	manager-1786265102263@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.264	2026-08-09 08:45:02.264
086fa155-7bda-48c6-bbae-a4d6dfe4635b	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	61e4b9c6-ebc2-49c4-872a-56f7085df0db	Manager Rajesh	manager-1786217563778@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.778	2026-08-08 19:32:43.778
7ac23420-347a-4e44-b10d-3812d333cfa0	6571c3c9-9c94-4b02-ac20-829a9af731b6	3c79f31d-edef-4d4f-ba97-b8b3f20150cd	Farmer Ramesh	farmer-1786265102268@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.269	2026-08-09 08:45:02.269
ec7b3349-dd3b-4742-8462-becffe34e1f5	6571c3c9-9c94-4b02-ac20-829a9af731b6	1cb05a55-3d38-4df9-9e56-8746c499eb16	Hourly Driver Vikas	driver-hourly-1786265102273@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.274	2026-08-09 08:45:02.274
ce6db18a-741e-45f5-8acd-898fccf61844	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	41a1a028-8b97-4e36-95b1-50874d823d43	Farmer Ramesh	farmer-1786217563782@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.782	2026-08-08 19:32:43.782
996abd4c-2156-42f1-8ea5-ee0cdb307289	6571c3c9-9c94-4b02-ac20-829a9af731b6	1cb05a55-3d38-4df9-9e56-8746c499eb16	Monthly Driver Sunil	driver-monthly-1786265102276@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.277	2026-08-09 08:45:02.277
ac8a591d-165b-402f-b7e9-ccaafebd4054	6571c3c9-9c94-4b02-ac20-829a9af731b6	1cb05a55-3d38-4df9-9e56-8746c499eb16	Yearly Driver Amit	driver-yearly-1786265102279@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:45:02.28	2026-08-09 08:45:02.28
37b62ee0-d138-444f-bf02-380e575a7610	c329669f-35fe-4787-84c9-902251b14695	323747f5-1d98-4b35-88e8-13b6673715b6	Manager Rajesh	manager-1786214028909@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.909	2026-08-08 18:33:48.909
e98db2bb-ca64-4d8c-ab56-a171976b2ebc	c329669f-35fe-4787-84c9-902251b14695	966530fb-54e0-4dd3-b3d7-57c64f708794	Farmer Ramesh	farmer-1786214028912@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.912	2026-08-08 18:33:48.912
41f89ed3-dbbb-4f06-964e-c68d7c7cd33e	c329669f-35fe-4787-84c9-902251b14695	11f705ab-0e4b-42bc-ab8a-3f698de0cf70	Hourly Driver Vikas	driver-hourly-1786214028914@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.914	2026-08-08 18:33:48.914
d4a99da4-8433-45c1-8db9-df1b4538fa80	c329669f-35fe-4787-84c9-902251b14695	11f705ab-0e4b-42bc-ab8a-3f698de0cf70	Monthly Driver Sunil	driver-monthly-1786214028916@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.917	2026-08-08 18:33:48.917
58f52a84-76ad-4bfa-b4af-74886ff6c929	c329669f-35fe-4787-84c9-902251b14695	11f705ab-0e4b-42bc-ab8a-3f698de0cf70	Yearly Driver Amit	driver-yearly-1786214028918@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:33:48.919	2026-08-08 18:33:48.919
34ecd01d-696f-4af1-a835-e31a00e7479e	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786214848188	farmerA_1786214848188@example.com	\N	$2a$10$YvSsHtgNSPC6ii0/yCyoAuoFDyii8oM.6B71FrBlmo1aZz6D/etqi	\N	ACTIVE	\N	2026-08-08 18:47:28.321	2026-08-08 18:47:28.321
a61c9c62-35b8-448a-8378-8c379905221b	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786214848188	farmerB_1786214848188@example.com	\N	$2a$10$VVlQHvya0jwRMjbM5O2M5uYPyBtTCvnbb6dVeA5dkk8YoUCB4xq1O	\N	ACTIVE	\N	2026-08-08 18:47:28.441	2026-08-08 18:47:28.441
dd938122-4e3b-4940-a8b7-5c39b9a77b44	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786214863010	farmerA_1786214863010@example.com	\N	$2a$10$WetRDbI4WHWpJ3nqtpzOCeAGQsqXkBxiwL/.A6dwXN03n/9DZj/Cu	\N	ACTIVE	\N	2026-08-08 18:47:43.141	2026-08-08 18:47:43.141
21ad8a73-0e09-49e8-a050-08af9cbf9983	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786214863010	farmerB_1786214863010@example.com	\N	$2a$10$lMCMdxQrhedDjaF0R8TVheeUGu0yOa45GWbkVfksX51XfeRG7hz4.	\N	ACTIVE	\N	2026-08-08 18:47:43.258	2026-08-08 18:47:43.258
bd33372a-c9b3-40fc-9a95-267330b8919d	29c82d91-d80e-4358-a180-dd5df8cae889	dd1145b6-0025-4aa9-a61d-f4b17ac6879b	Test Manager	manager_1786214883825@example.com	\N	$2a$10$Rl81Y1racjW5P8/CczIM1epiffftG6JkG9bUKeWbn4M2qdNVVR2am	\N	ACTIVE	\N	2026-08-08 18:48:04.029	2026-08-08 18:48:04.029
b988a9aa-5954-4037-a9e3-16347aaa03b7	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Test Farmer User	farmer_1786214883825@example.com	\N	$2a$10$nVojZcRNWrwyulwFAcujeufVFjP8I0gT3nnsC4CLZLVlFNryluG2O	\N	ACTIVE	\N	2026-08-08 18:48:04.356	2026-08-08 18:48:04.356
01732611-871f-4326-8e33-f1f80445179d	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Test Driver User	driver_1786214883825@example.com	\N	$2a$10$YrgaTqBnAI1Y4.kLnRRXOuzXQBldAUP.wUM1kUsJx4FxPWBwFHCqK	\N	ACTIVE	\N	2026-08-08 18:48:04.525	2026-08-08 18:48:04.525
0609281d-0639-48ce-aa24-d689213cf2ed	e9c09207-6fea-46d5-8f07-7464472a519a	ce939d90-8c66-4235-a31b-7beef1a33d29	Second Owner	owner2_1786214883825@example.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:48:04.605	2026-08-08 18:48:04.605
484e274b-bb7e-4679-9afd-a984a52a9a43	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786214902868	farmerA_1786214902868@example.com	\N	$2a$10$jOgyoucvJr12/3WewFdn.uDjt.CdiHRsZ5NssmrEc3L.HkEXRIs6K	\N	ACTIVE	\N	2026-08-08 18:48:23	2026-08-08 18:48:23
5ac5cb9c-e6ce-4250-bdd0-f4d3137aa8c6	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786214902868	farmerB_1786214902868@example.com	\N	$2a$10$mm1rKKlmIG.RQmnykpIO0OKpzsQr7IryKhdKb/advWEbOKYHRKW12	\N	ACTIVE	\N	2026-08-08 18:48:23.116	2026-08-08 18:48:23.116
c5ec61b5-7c7c-4b26-ae96-f992bc632677	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	5c9f93da-100f-42f2-a5c9-92175d86ab7c	Manager Rajesh	manager-1786214899163@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.163	2026-08-08 18:48:19.163
7aa92c4e-6d79-4b2d-b121-d6f2fb93ceb6	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	add2f824-cfbf-487a-9784-08979980101b	Farmer Ramesh	farmer-1786214899166@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.166	2026-08-08 18:48:19.166
490667a1-bfe4-4410-ab78-266e227edeca	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	fe0df962-cbb3-4e30-8218-c470f87b57c2	Hourly Driver Vikas	driver-hourly-1786214899168@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.169	2026-08-08 18:48:19.169
7bc6ebaa-1cef-4f10-9c31-e84dca1d14d8	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	fe0df962-cbb3-4e30-8218-c470f87b57c2	Monthly Driver Sunil	driver-monthly-1786214899170@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.171	2026-08-08 18:48:19.171
2aad45f6-d4b6-4dec-a5c8-9ed4bd3de805	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	fe0df962-cbb3-4e30-8218-c470f87b57c2	Yearly Driver Amit	driver-yearly-1786214899172@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 18:48:19.173	2026-08-08 18:48:19.173
7dcc8104-ad91-4d26-9013-dfd2e3198c94	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	3f06c163-5e32-4c47-be56-78f0d8d2629c	Hourly Driver Vikas	driver-hourly-1786217563805@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.806	2026-08-08 19:32:43.806
42f2b8ca-0f35-47e3-92d7-4675030938ad	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	3f06c163-5e32-4c47-be56-78f0d8d2629c	Monthly Driver Sunil	driver-monthly-1786217563807@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.808	2026-08-08 19:32:43.808
e4565401-4b9f-4cd2-9e3d-fd72c5569457	29c82d91-d80e-4358-a180-dd5df8cae889	ed52a830-1c11-4eac-8fde-75604abab500	Vikas Driver (Operator)	driver@shabooagri.com	7777777777	$2a$10$H.f5sFDQ/iDFvdwnz5Bu6u8lYLPqAGsdqAAzx2FjwK06Bzl7eH6ty	\N	ACTIVE	2026-08-08 18:52:46.419	2026-08-08 18:28:02.986	2026-08-09 05:12:55.558
e147436e-fe0c-4b63-a309-5635c65cf72a	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	3f06c163-5e32-4c47-be56-78f0d8d2629c	Yearly Driver Amit	driver-yearly-1786217563809@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:32:43.81	2026-08-08 19:32:43.81
a821940f-4b40-4ada-ba46-153a112fb158	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786217560165	farmerA_1786217560165@example.com	\N	$2a$10$mKJQytT1tY4b9InfSe77nOUEaU/u6eUVzDsbdkVBDuRha800XBgmq	\N	ACTIVE	\N	2026-08-08 19:32:40.301	2026-08-08 19:32:40.301
5a3a556b-3a03-4159-8290-717c8e9959b8	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786217560165	farmerB_1786217560165@example.com	\N	$2a$10$ae3FosGiSg4iGJANFZowA.WTv1oP9D0s5kaVuCwW3Od5mpPYcW0.i	\N	ACTIVE	\N	2026-08-08 19:32:40.412	2026-08-08 19:32:40.412
eaa19bc3-58de-40df-9a23-c5ca0c2c3882	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786217935613	farmerA_1786217935613@example.com	\N	$2a$10$jDCnoD5AbwlIUW9UkAGgyOhXypj8z2Yr7odfv1Y5Cxvn.1wpjn.IS	\N	ACTIVE	\N	2026-08-08 19:38:55.751	2026-08-08 19:38:55.751
9b1f4cb4-6343-4dd9-b093-46bafdc147af	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786217935613	farmerB_1786217935613@example.com	\N	$2a$10$Ob0gqC/0OiYmB6tmai.2ouvDm2PJLXvO2/b.ofblB3jqrUpasYdoS	\N	ACTIVE	\N	2026-08-08 19:38:55.889	2026-08-08 19:38:55.889
5cc119e3-567f-49f8-b986-13b82bc3f960	3968e65b-4204-432c-ad93-26a831a79d3e	afd0f0ed-a03c-44b2-b5ad-ba448c222fbc	Manager Rajesh	manager-1786217939183@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.184	2026-08-08 19:38:59.184
15e9d8c0-3e2e-44f5-b379-dd22e9b654ca	3968e65b-4204-432c-ad93-26a831a79d3e	e5bbb2c3-5551-4a4e-81d0-c7ce5d29c3bc	Farmer Ramesh	farmer-1786217939186@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.187	2026-08-08 19:38:59.187
df4f5305-606d-4b4f-b7ce-f8bc44195415	3968e65b-4204-432c-ad93-26a831a79d3e	a72068df-8bdf-42cd-98ee-256bbb0b83c6	Hourly Driver Vikas	driver-hourly-1786217939188@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.189	2026-08-08 19:38:59.189
012367d9-5050-4d91-b603-baa9d02de1c3	3968e65b-4204-432c-ad93-26a831a79d3e	a72068df-8bdf-42cd-98ee-256bbb0b83c6	Monthly Driver Sunil	driver-monthly-1786217939190@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.191	2026-08-08 19:38:59.191
cb4ca09e-c02c-4b8d-9666-eb4265ada630	3968e65b-4204-432c-ad93-26a831a79d3e	a72068df-8bdf-42cd-98ee-256bbb0b83c6	Yearly Driver Amit	driver-yearly-1786217939193@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:38:59.193	2026-08-08 19:38:59.193
3466c4a7-2011-4cf5-ba8d-3464c9cd4bc9	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786218114338	farmerA_1786218114338@example.com	\N	$2a$10$lhWHMifNLP8hj18hTcRZKOyQMeaMvEmHgop13fafVOn2FXf4d.1Qy	\N	ACTIVE	\N	2026-08-08 19:41:54.475	2026-08-08 19:41:54.475
bb9708fb-194b-49e0-b1e6-3e53a638c75d	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786218114338	farmerB_1786218114338@example.com	\N	$2a$10$FvG89u4f9gIspnCXiE2f2uZqd7mt3sUuZiNx6gT.ybAvXsQhnGXNG	\N	ACTIVE	\N	2026-08-08 19:41:54.588	2026-08-08 19:41:54.588
c2b27c01-e11a-45a5-be98-78d4d91a03d5	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	971784a0-36da-4f0b-8dfd-af5555f1eeb2	Manager Rajesh	manager-1786218117947@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.948	2026-08-08 19:41:57.948
950a0247-8d2c-4c94-9b3d-b1fa7ed5a270	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	7fd63aac-5a5a-410a-85e1-43cf091f9707	Farmer Ramesh	farmer-1786218117951@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.952	2026-08-08 19:41:57.952
dc2de281-6ad0-4c27-9d2d-39cbd0d6bcb8	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	ae8ba156-83fa-4646-8977-26f4c4653e1b	Hourly Driver Vikas	driver-hourly-1786218117953@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.954	2026-08-08 19:41:57.954
9bc79574-7999-4025-803b-fd40af6bf187	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	ae8ba156-83fa-4646-8977-26f4c4653e1b	Monthly Driver Sunil	driver-monthly-1786218117955@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.956	2026-08-08 19:41:57.956
842b57fe-01a5-4da4-8a7a-0260a27386af	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	ae8ba156-83fa-4646-8977-26f4c4653e1b	Yearly Driver Amit	driver-yearly-1786218117957@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 19:41:57.958	2026-08-08 19:41:57.958
f43e02d6-4a6f-4f39-a0e6-d9650053b7d9	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Pradeep Swain (Owner)	owner@shabooagri.com	9999999999	$2a$10$H.f5sFDQ/iDFvdwnz5Bu6u8lYLPqAGsdqAAzx2FjwK06Bzl7eH6ty	\N	ACTIVE	2026-08-09 05:13:02.208	2026-08-09 05:12:55.551	2026-08-09 05:13:02.21
9c67ad52-cfac-458c-a7e1-41410326bb87	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786219462382	farmerA_1786219462382@example.com	\N	$2a$10$SOJerPjEpUD.W3hNU8LG4OpFbDqfYBJS0PgZimJIWsfRhz6jSeTzK	\N	ACTIVE	\N	2026-08-08 20:04:22.521	2026-08-08 20:04:22.521
994b0f5a-10b4-4d85-962a-308d9117a193	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786219462382	farmerB_1786219462382@example.com	\N	$2a$10$LKfgZzF9/oyZHs9rFokH8eXpdKxaeO1avdocheDMinAyRfTooxMCC	\N	ACTIVE	\N	2026-08-08 20:04:22.635	2026-08-08 20:04:22.635
ef9723a8-a307-4ce6-a6f3-4db7d49bd774	ecbba26c-b8ee-4455-a09e-86fab13778df	26e28e80-50aa-404b-a833-e1b1e7f442b8	Manager Rajesh	manager-1786219466028@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.029	2026-08-08 20:04:26.029
fda5639a-b94f-429d-af17-46825997029d	ecbba26c-b8ee-4455-a09e-86fab13778df	a6487f8c-0da6-4a7b-a3d2-761b91071076	Farmer Ramesh	farmer-1786219466031@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.032	2026-08-08 20:04:26.032
5538f754-b4cc-4c03-b2bd-1ba39594a3ff	ecbba26c-b8ee-4455-a09e-86fab13778df	b18786a2-1790-4bcb-b4c0-069189d80fca	Hourly Driver Vikas	driver-hourly-1786219466033@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.034	2026-08-08 20:04:26.034
18709e85-b4f1-49c6-8f5b-ce940e921fe2	ecbba26c-b8ee-4455-a09e-86fab13778df	b18786a2-1790-4bcb-b4c0-069189d80fca	Monthly Driver Sunil	driver-monthly-1786219466035@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.036	2026-08-08 20:04:26.036
e80ca75e-3155-4101-a708-7bc06d07402f	ecbba26c-b8ee-4455-a09e-86fab13778df	b18786a2-1790-4bcb-b4c0-069189d80fca	Yearly Driver Amit	driver-yearly-1786219466037@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:04:26.038	2026-08-08 20:04:26.038
18ce6092-441a-4cde-8970-c358a3353eb0	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Owner	owner_1786188148080@example.com	\N	$2a$10$wqoWWuGQgWUsnMMhtuN5W.yMR.dJ2M7kjvv1F4xSWpcC48ASqnnSa	\N	INACTIVE	\N	2026-08-08 11:22:28.195	2026-08-08 20:25:30.17
37f9f0b0-e014-45c2-b044-510d8660a6f8	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786217543503	reset_owner_1786217543503@example.com	\N	$2a$10$hvh5VKQK8bvGRzd27rNzMenMa7fXsBJgaQzv3S9okpAOtHBiQm8ze	$2a$10$wzfMCK.oXG4mUhYE.o7S1eQWgcsZX74jYpjqxeVmwWetX1Y/iE86K	INACTIVE	2026-08-08 19:32:24.332	2026-08-08 19:32:23.773	2026-08-08 20:25:30.174
75a3cc39-f85f-4ce0-b9a1-bd08ec29fb5b	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786217931387	reset_owner_1786217931387@example.com	\N	$2a$10$ZYRd4wy3wrJI3jlwvAzgauBnB2Zbp4pCF.BDylb6D0Jxh1kVhPcfC	$2a$10$UFNik5NebREbJebb/dKPOe6rNKggo37v5GBUJ.CI/Tw7OO9mCuo9K	INACTIVE	2026-08-08 19:38:52.131	2026-08-08 19:38:51.582	2026-08-08 20:25:30.176
b6fe1aab-9658-48dc-a559-906a39a56cf7	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786218108542	reset_owner_1786218108542@example.com	\N	$2a$10$zHMQMpNTwDC81G3jrxsdVe5j4Pm4mkmnQTH63UlrRGN7mV8dBq7Wm	$2a$10$cBFv91k51cnCqxIsIE6JGeiiEJH7kUNu32B1u0E50/HBRbnvTRjAO	INACTIVE	2026-08-08 19:41:50.548	2026-08-08 19:41:48.773	2026-08-08 20:25:30.179
5ddc850e-1c7e-4d79-b983-ba56e51c27ed	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786219453681	reset_owner_1786219453681@example.com	\N	$2a$10$DqHOiP3EdR7iyQvi7EczB.nLV6ogxbIZl9MrM6m2KSjWK6iP0Qg3C	$2a$10$swuwAKAyntyMxGDsYauH7.VRrFaMGy/qzNP6rs3CA0a7xthCqrxHS	INACTIVE	2026-08-08 20:04:15.99	2026-08-08 20:04:13.896	2026-08-08 20:25:30.181
b2a57d48-e4a2-455e-b1d5-ea0c10cb1da6	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	de048a83-eec3-4f20-a129-0df23c964503	Manager Rajesh	manager-1786255035068@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.069	2026-08-09 05:57:15.069
ad0a0e47-80be-4a23-82a6-d72e3de88b87	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786222370490	reset_owner_1786222370490@example.com	\N	$2a$10$KDdkGwue6P0rjztRBS8xO.SWR95L1qheBtfHzpSOf9CLkLXPJ7Hzq	$2a$10$9XTE4xykgdMJN.1ZHUoF9e47h57px6a4/0U3nbA5a2dMTKqx5Whs.	ACTIVE	2026-08-08 20:52:52.76	2026-08-08 20:52:50.712	2026-08-08 20:52:52.761
ca0cdfc2-f5e5-4ece-ad98-1eff2c260a57	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786222379208	farmerA_1786222379208@example.com	\N	$2a$10$SuWz9spfJpGJVxxMRdcvO.A/LuLeC75bd1nxxSMRkVNitMV4iwFJa	\N	ACTIVE	\N	2026-08-08 20:52:59.339	2026-08-08 20:52:59.339
e8ba27e3-6834-4dec-9318-5acc6d073df3	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	425d6b11-e986-4751-9806-fbd8c43c05f0	Farmer Ramesh	farmer-1786255035071@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.072	2026-08-09 05:57:15.072
8d91ec10-47b8-4903-b9d0-a82d31bbd909	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786222379208	farmerB_1786222379208@example.com	\N	$2a$10$gaG3YV6fpXsFwK852La5PeUiFf7RpK9I1wt4JwCFz9z4huaOSESzy	\N	ACTIVE	\N	2026-08-08 20:52:59.454	2026-08-08 20:52:59.454
22b76af9-0d7b-4d4e-828c-7cbd84dc9599	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	6c3a09b3-f02d-4f3e-811d-bbdd0ba20378	Manager Rajesh	manager-1786222383365@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.366	2026-08-08 20:53:03.366
dfa5837a-d057-4cf3-9ac3-ccc1d888634f	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	9c52781e-11c0-4437-a54e-70b9b57b7627	Farmer Ramesh	farmer-1786222383368@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.369	2026-08-08 20:53:03.369
73fcb91f-a715-4fd7-bd41-7f991e236593	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	8168e1bf-d2a6-4230-b8f8-d8423e0f247a	Hourly Driver Vikas	driver-hourly-1786222383371@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.371	2026-08-08 20:53:03.371
3333f0a3-1a9b-4474-a710-4edad92b0682	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	8168e1bf-d2a6-4230-b8f8-d8423e0f247a	Monthly Driver Sunil	driver-monthly-1786222383373@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.374	2026-08-08 20:53:03.374
2b8b8378-69f4-4df5-9105-e9d357716393	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	8168e1bf-d2a6-4230-b8f8-d8423e0f247a	Yearly Driver Amit	driver-yearly-1786222383375@test.com	\N	\N	\N	ACTIVE	\N	2026-08-08 20:53:03.376	2026-08-08 20:53:03.376
c9ee60f9-f6a5-4255-96be-db06e220dc3e	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	5414a298-c811-4973-9aa3-53b9e41aaefc	Hourly Driver Vikas	driver-hourly-1786255035075@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.076	2026-08-09 05:57:15.076
08d7dfb3-6328-4aab-8a2d-a7aa3aec8df3	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	5414a298-c811-4973-9aa3-53b9e41aaefc	Monthly Driver Sunil	driver-monthly-1786255035079@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.08	2026-08-09 05:57:15.08
c36b48fb-00a0-46df-9e04-18f98f0b59fd	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	5414a298-c811-4973-9aa3-53b9e41aaefc	Yearly Driver Amit	driver-yearly-1786255035104@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 05:57:15.106	2026-08-09 05:57:15.106
5ebfc665-cac7-4cf1-850e-0ca55f7de574	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786255047288	farmerA_1786255047288@example.com	\N	$2a$10$0A9hHC3JTFF8oUApc4wwq.hNErSpS1ulayr5Kw3OO2j92dpE3p.dS	\N	ACTIVE	\N	2026-08-09 05:57:27.433	2026-08-09 05:57:27.433
0b961000-86e2-410b-99a8-4055fb9a4136	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786255047288	farmerB_1786255047288@example.com	\N	$2a$10$glDGNXmcX/nyFB6CBQea4.DkHsTB3JdUoZM1wzw39KhnbyWu01gpm	\N	ACTIVE	\N	2026-08-09 05:57:27.551	2026-08-09 05:57:27.551
b897eb1f-88e7-4875-8c07-75360b11a2e5	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786255052458	reset_owner_1786255052458@example.com	\N	$2a$10$/lVxRV6BwAuBgXCN4z2SK.1Suvbbs.I5jU.WwmC3NacSJ51vyAzZC	$2a$10$ZMNBIpMltlwGmbaX8b.eWeDYuxR0uwdV58N63riCCc3nKGG/vEBma	ACTIVE	2026-08-09 05:57:35.464	2026-08-09 05:57:32.753	2026-08-09 05:57:35.465
5f50d0cf-c313-4543-aeeb-4fb8a3737b2e	d8d7190c-b0f9-42e6-a510-8a401b035039	af3282d2-98da-47ce-b99d-5403e7985b1c	Ramesh Manager	manager_1786255222431@shabooagri.com	91255222431	\N	\N	ACTIVE	\N	2026-08-09 06:00:22.432	2026-08-09 06:00:22.432
1d03f950-4037-4957-9885-db13b9443b23	d8d7190c-b0f9-42e6-a510-8a401b035039	c6e30c73-0426-4941-93e2-711b3babed72	Suresh Driver	driver_1786255222438@shabooagri.com	92255222438	\N	\N	ACTIVE	\N	2026-08-09 06:00:22.439	2026-08-09 06:00:22.439
2b6d8bc7-7c6c-4a77-ba3b-91535ac06f83	d8d7190c-b0f9-42e6-a510-8a401b035039	c0a09fac-9ebb-46c1-aa40-c839366dd7db	Bhabani Sankar Farmer	\N	93255222451	\N	\N	ACTIVE	\N	2026-08-09 06:00:22.452	2026-08-09 06:00:22.452
acc88958-188e-4a76-b23b-14847cb66a95	d8d7190c-b0f9-42e6-a510-8a401b035039	c0a09fac-9ebb-46c1-aa40-c839366dd7db	Kalinga Agro Pvt Ltd	\N	94255222457	\N	\N	ACTIVE	\N	2026-08-09 06:00:22.458	2026-08-09 06:00:22.458
1d1b9bf2-0cec-4b11-bb43-b5e827458a37	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	35025a83-6d13-4cfb-af1d-5e99a6a2324f	Ramesh Manager	manager_1786255229697@shabooagri.com	91255229697	\N	\N	ACTIVE	\N	2026-08-09 06:00:29.699	2026-08-09 06:00:29.699
1fbd1ff0-9a6f-4e6f-af26-11540a7ddcf2	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	6d84a757-509f-4171-a0a9-0579dd1bf854	Suresh Driver	driver_1786255229702@shabooagri.com	92255229702	\N	\N	ACTIVE	\N	2026-08-09 06:00:29.703	2026-08-09 06:00:29.703
6b159e7f-7c9c-4ee1-914d-7d85ad552be8	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	7ffbc384-fcf5-4cf7-b594-1c86af11f140	Bhabani Sankar Farmer	\N	93255229719	\N	\N	ACTIVE	\N	2026-08-09 06:00:29.72	2026-08-09 06:00:29.72
9bff56ae-01ca-462f-b13f-79a44df6ce06	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	7ffbc384-fcf5-4cf7-b594-1c86af11f140	Kalinga Agro Pvt Ltd	\N	94255229726	\N	\N	ACTIVE	\N	2026-08-09 06:00:29.727	2026-08-09 06:00:29.727
1f0db783-3016-444b-ad21-3d8834cadb60	7a92e240-df0b-4c44-8bba-bd7574ae788b	f08de487-634d-460f-a1b3-41fa63d3e660	Ramesh Manager	manager_1786255244954@shabooagri.com	91255244954	\N	\N	ACTIVE	\N	2026-08-09 06:00:44.955	2026-08-09 06:00:44.955
f1b9be23-e341-4245-a1b1-0f0a169ca82d	7a92e240-df0b-4c44-8bba-bd7574ae788b	3669c4c7-c8c0-451f-9c8a-665fc63a5a9b	Suresh Driver	driver_1786255244959@shabooagri.com	92255244959	\N	\N	ACTIVE	\N	2026-08-09 06:00:44.96	2026-08-09 06:00:44.96
f8eb821b-c1de-454b-9444-c18f0bb2ae74	7a92e240-df0b-4c44-8bba-bd7574ae788b	1a01ab75-861e-41ee-bcba-216fa70d348c	Bhabani Sankar Farmer	\N	93255244974	\N	\N	ACTIVE	\N	2026-08-09 06:00:44.975	2026-08-09 06:00:44.975
524858ec-9ccb-47e7-a3bb-251785b01dfc	7a92e240-df0b-4c44-8bba-bd7574ae788b	1a01ab75-861e-41ee-bcba-216fa70d348c	Kalinga Agro Pvt Ltd	\N	94255244980	\N	\N	ACTIVE	\N	2026-08-09 06:00:44.981	2026-08-09 06:00:44.981
5917a103-06b6-41b4-81bd-5ef527f43954	8951aa6b-476b-46b7-b12b-de1998c8bbf7	5df2e40a-8234-44b1-acca-7e8e0f43211f	Ramesh Manager	manager_1786255259334@shabooagri.com	91255259334	\N	\N	ACTIVE	\N	2026-08-09 06:00:59.335	2026-08-09 06:00:59.335
50107b72-b633-4592-a949-d53c0fd323cf	8951aa6b-476b-46b7-b12b-de1998c8bbf7	2fbb4c12-ee06-48b6-b270-0c588162ed94	Suresh Driver	driver_1786255259339@shabooagri.com	92255259339	\N	\N	ACTIVE	\N	2026-08-09 06:00:59.34	2026-08-09 06:00:59.34
c678bb88-aabe-4504-bce3-5e9e5b372cfd	8951aa6b-476b-46b7-b12b-de1998c8bbf7	667c8aea-5805-4882-943b-7380f61395fe	Bhabani Sankar Farmer	\N	93255259352	\N	\N	ACTIVE	\N	2026-08-09 06:00:59.353	2026-08-09 06:00:59.353
69732086-76d1-4923-858d-1aa0a8fcf27e	8951aa6b-476b-46b7-b12b-de1998c8bbf7	667c8aea-5805-4882-943b-7380f61395fe	Kalinga Agro Pvt Ltd	\N	94255259360	\N	\N	ACTIVE	\N	2026-08-09 06:00:59.361	2026-08-09 06:00:59.361
808c6af1-8955-4803-8580-fa136df6aad2	d563fb11-8e19-4079-a843-4d579ba681ee	b83595ac-ac3b-40db-a577-950655cf4070	Ramesh Manager	manager_1786255270600@shabooagri.com	91255270600	\N	\N	ACTIVE	\N	2026-08-09 06:01:10.601	2026-08-09 06:01:10.601
245f9e57-ddd8-4d1b-a0c1-658443c3af82	d563fb11-8e19-4079-a843-4d579ba681ee	85ea8e15-918a-47da-b686-fef9b1ee2ea3	Suresh Driver	driver_1786255270603@shabooagri.com	92255270603	\N	\N	ACTIVE	\N	2026-08-09 06:01:10.604	2026-08-09 06:01:10.604
4ad43eba-4797-42e3-8438-a4e4fb29bdc1	d563fb11-8e19-4079-a843-4d579ba681ee	45a92eb6-099b-4237-8a98-baba02636fbc	Bhabani Sankar Farmer	\N	93255270619	\N	\N	ACTIVE	\N	2026-08-09 06:01:10.62	2026-08-09 06:01:10.62
50e72b9c-e0e5-40f6-bc12-13210d1d43c9	d563fb11-8e19-4079-a843-4d579ba681ee	45a92eb6-099b-4237-8a98-baba02636fbc	Kalinga Agro Pvt Ltd	\N	94255270625	\N	\N	ACTIVE	\N	2026-08-09 06:01:10.626	2026-08-09 06:01:10.626
96697222-d7a6-403a-9d25-c9fa4a78dbfe	4613e40d-bba4-424a-970e-ffc7836a19e2	8001b294-130c-4948-9fdd-b80f14d2e8ef	Manager Rajesh	manager-1786265278677@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.678	2026-08-09 08:47:58.678
c686a3f2-dc1c-4cd1-989e-58625b645450	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	664f88a8-c509-47e4-8e4a-3705d78ad451	Manager Rajesh	manager-1786255284988@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 06:01:24.988	2026-08-09 06:01:24.988
40602102-1df0-492b-b35c-2080f2ef83a6	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	5179f9d0-0f35-4e1e-90fc-2057a765e951	Farmer Ramesh	farmer-1786255284990@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 06:01:24.991	2026-08-09 06:01:24.991
6065b7a6-480a-49b8-8c31-6fd4be470fc9	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	92108d15-b696-49d5-adf1-e836ae70c2ce	Hourly Driver Vikas	driver-hourly-1786255284992@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 06:01:24.993	2026-08-09 06:01:24.993
9026f75f-32e7-44e8-88b0-afa9a9429f18	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	92108d15-b696-49d5-adf1-e836ae70c2ce	Monthly Driver Sunil	driver-monthly-1786255284994@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 06:01:24.995	2026-08-09 06:01:24.995
06e6b2dd-3d99-43be-87a0-31e2df212a94	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	92108d15-b696-49d5-adf1-e836ae70c2ce	Yearly Driver Amit	driver-yearly-1786255284996@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 06:01:24.997	2026-08-09 06:01:24.997
c6619c64-6d4e-42a8-8247-d3d8785b272b	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786265105884	farmerA_1786265105884@example.com	\N	$2a$10$9dHjVf6bpvGQtYP999c.k.vFkmXCAPWh9TRQGNY/SON4ds/.WjvlO	\N	ACTIVE	\N	2026-08-09 08:45:06.035	2026-08-09 08:45:06.035
810d95f6-de08-475e-924f-5d7d251a7ab7	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786265105884	farmerB_1786265105884@example.com	\N	$2a$10$gNoLAYnT00KczLTlrfV3Qehl5duv3SGn.NDAlty78WiILtP5fvipe	\N	ACTIVE	\N	2026-08-09 08:45:06.155	2026-08-09 08:45:06.155
a10fd152-89b4-4b11-9968-641ecaa2d89d	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786255296835	farmerA_1786255296835@example.com	\N	$2a$10$w5AiIp2emaD2h4.n7.SSuOPwFIm.B6k3bTf2zmj34NDZYHPglByDm	\N	ACTIVE	\N	2026-08-09 06:01:37.089	2026-08-09 06:01:37.089
b589ee8d-f3f9-4568-b358-bee9035a1eb9	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786255296835	farmerB_1786255296835@example.com	\N	$2a$10$PY2dzUIUxGKJYqYRSxri9eCNiD2LVcKYh7gf3PWRlEwFzAlI5z8JC	\N	ACTIVE	\N	2026-08-09 06:01:37.362	2026-08-09 06:01:37.362
d52439eb-75bb-400a-8355-d2f9aebd9bbe	4613e40d-bba4-424a-970e-ffc7836a19e2	1a2e4593-3be9-430e-90d7-8ccd86d80e5a	Farmer Ramesh	farmer-1786265278680@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.681	2026-08-09 08:47:58.681
5ffd7f84-6e5c-43ed-ac10-9488bfa37744	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786255301687	reset_owner_1786255301687@example.com	\N	$2a$10$BDcO35eYZuFoce6RWMYopej79TKv3vC7g6RjwS4O4XJzmhyluwGHS	$2a$10$7HliGxyUoh8juf7nNyQrL.qpzeXmiKgMyZaJletF2L7QQDH3dbYme	ACTIVE	2026-08-09 06:01:44.173	2026-08-09 06:01:41.907	2026-08-09 06:01:44.174
55c8f0bb-3bea-4765-98e9-3679ecd656f7	4613e40d-bba4-424a-970e-ffc7836a19e2	188aa15c-e07b-474a-9fed-4f5ea67f9ba8	Hourly Driver Vikas	driver-hourly-1786265278682@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.683	2026-08-09 08:47:58.683
9a78beb7-3f4e-4332-9fff-30d286259eaf	4613e40d-bba4-424a-970e-ffc7836a19e2	188aa15c-e07b-474a-9fed-4f5ea67f9ba8	Monthly Driver Sunil	driver-monthly-1786265278684@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.685	2026-08-09 08:47:58.685
4a29d44d-7090-441a-81e1-c15b532fee2a	4613e40d-bba4-424a-970e-ffc7836a19e2	188aa15c-e07b-474a-9fed-4f5ea67f9ba8	Yearly Driver Amit	driver-yearly-1786265278686@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:47:58.687	2026-08-09 08:47:58.687
a800bba5-52a3-4259-b5cf-4cf943beac89	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786265281066	farmerA_1786265281066@example.com	\N	$2a$10$gxlD4aB8ILhUCcDqA2WzgOaMSo7WlUCvzkyxxzw2nJy5pgU2cp.Pi	\N	ACTIVE	\N	2026-08-09 08:48:01.48	2026-08-09 08:48:01.48
ef799722-fbd6-4054-95df-0d7575ca050e	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786265281066	farmerB_1786265281066@example.com	\N	$2a$10$r2u6Py8WW3B2s2TVMHstGOYGW4GRRMoaqcGQjWsNHtMdUg6FflcaK	\N	ACTIVE	\N	2026-08-09 08:48:01.853	2026-08-09 08:48:01.853
7f6e1fdf-d430-4681-b662-ebc188e57e8d	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786265623397	farmerA_1786265623397@example.com	\N	$2a$10$T1wvm0YXAsEuHlYwhZQBIOAxxDdBDMn5wCNGhjN6uzlklWa1ryz0G	\N	ACTIVE	\N	2026-08-09 08:53:43.532	2026-08-09 08:53:43.532
77c52960-f67a-4edf-8eae-90c2c32a94df	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786265623397	farmerB_1786265623397@example.com	\N	$2a$10$ZyzVxddHl6pd1hsA4V6RIOv2b1YqC9Z96ZtFZM7T9Tx345W1xPgwa	\N	ACTIVE	\N	2026-08-09 08:53:43.648	2026-08-09 08:53:43.648
9036cb4f-1bea-47d6-9922-316dabacac20	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786265295542	reset_owner_1786265295542@example.com	\N	$2a$10$n/4OAhXo17ucht87.asqoueMEa1nP2RYHx.CNB3fAqaeM1nm7E6Uu	$2a$10$nOXvAUh2j4QjveEbXLPzYeGBxnzgdPCejksdtxRitlRJ8Br6fVIhq	ACTIVE	2026-08-09 08:48:17.923	2026-08-09 08:48:15.738	2026-08-09 08:48:17.924
b1aace75-9cca-4012-815b-e391c66c31c5	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	2706db66-9e49-4c62-8a89-1c78328508ae	Manager Rajesh	manager-1786265621506@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.507	2026-08-09 08:53:41.507
e1704839-2e87-41bc-adad-a95d3fcf81e5	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	8d55cda6-7664-4810-9e2a-947d254f6a64	Farmer Ramesh	farmer-1786265621510@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.511	2026-08-09 08:53:41.511
a9e18075-e691-4161-b6dc-5db06dc2e6d8	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	699d540e-63c5-400e-929b-824823849efd	Hourly Driver Vikas	driver-hourly-1786265621512@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.513	2026-08-09 08:53:41.513
e51d60c4-274b-4c41-babd-e05208b5c7b4	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	699d540e-63c5-400e-929b-824823849efd	Monthly Driver Sunil	driver-monthly-1786265621515@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.515	2026-08-09 08:53:41.515
189dcabb-4a1b-45f6-a95f-20cc44b3fff1	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	699d540e-63c5-400e-929b-824823849efd	Yearly Driver Amit	driver-yearly-1786265621517@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 08:53:41.518	2026-08-09 08:53:41.518
02a23e8c-a718-47b1-84f0-d1478336e639	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786266215512	reset_owner_1786266215512@example.com	\N	$2a$10$PNREY0DnIArwMOgVDtY0V.p6WLQqb5O6w.KIEaRquGPhn71BkETa2	$2a$10$3KjVjAHvgq9BFE6IM1jCtefp0DsIAvanFPBmGsd9.LGxw1bPH9ycW	ACTIVE	2026-08-09 09:03:37.781	2026-08-09 09:03:35.714	2026-08-09 09:03:37.782
973b0190-b2c6-49d3-9d28-2d1cdb7a74ca	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786265631347	reset_owner_1786265631347@example.com	\N	$2a$10$59/l2j56XhgckfFgpFNP1ueJdqqM.PavRtmDY9OnQBsEoy/kR.2zW	$2a$10$u2/YI3ZVGyFT9llNsgZCQ.M7z7mAdNK3HA9XITJa2DpaXxiW6ivGC	ACTIVE	2026-08-09 08:53:53.821	2026-08-09 08:53:51.629	2026-08-09 08:53:53.822
bc5503b0-0534-42e0-ad18-948c51afbdac	9e4b2764-62cc-4933-9014-de6fc8b82d10	8a452d14-2cc7-452e-ae56-fa1cd72695c1	Vijay Singh	s4_user_a_1786266373161@example.com	9166373161	\N	\N	ACTIVE	2026-08-09 09:06:13.725	2026-08-09 09:06:13.678	2026-08-09 09:06:13.727
d70555da-2c13-4e27-b7c9-b45d6c444f42	19ca25d7-5e1e-4bcd-8e88-8f9356a5119b	6d0530ca-a7b9-44e3-9117-7d39717ebfa7	Ramesh Patel	customer_a_1786266117437@example.com	9866117437	\N	\N	ACTIVE	2026-08-09 09:01:58.174	2026-08-09 09:01:58.122	2026-08-09 09:01:58.175
1babed97-82f7-4d16-b447-a5eda1e9ed43	31fdb769-0873-405a-aed7-f54f5303d5c5	1682b3f9-e252-4568-9326-71a8ad1bac6e	Ramesh Patel	customer_a_1786266188564@example.com	9866188564	\N	\N	ACTIVE	2026-08-09 09:03:09.287	2026-08-09 09:03:09.231	2026-08-09 09:03:09.289
7cd48ff9-31bd-42a4-ae19-464d58b14a1a	1b7025b9-c122-4210-a967-97e8c1d180fd	63d8ff19-855e-4cfc-badf-bd3511b3709c	Ramesh Patel	customer_a_1786266199334@example.com	9866199334	\N	\N	ACTIVE	2026-08-09 09:03:20.069	2026-08-09 09:03:20.012	2026-08-09 09:03:20.07
92c67ac8-d7f7-4daf-82c6-52942d5d0e49	d5aa3c72-3bb7-464d-ac65-ba79fc2285c1	24ae24e5-a6bc-4cd3-b30e-28d0460db8f8	Vijay Singh	s4_user_a_1786266377512@example.com	9166377512	\N	\N	ACTIVE	2026-08-09 09:06:18.089	2026-08-09 09:06:18.045	2026-08-09 09:06:18.09
d52da64f-dddb-44ab-95b1-daa8f46cacdb	b3bd9148-5bcf-46c7-aae9-d07d688834ca	225de02f-4f0e-406a-9ed6-6524dd5a3dda	Manager Rajesh	manager-1786266205894@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.894	2026-08-09 09:03:25.894
9679fc51-b546-447c-a1f6-715fb9d8538f	b3bd9148-5bcf-46c7-aae9-d07d688834ca	1a445221-dd86-4a20-b4e4-4ceef045602d	Farmer Ramesh	farmer-1786266205897@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.898	2026-08-09 09:03:25.898
48f8866c-c5d5-48b2-9568-c4e675e0ea9c	b3bd9148-5bcf-46c7-aae9-d07d688834ca	84932ba2-5347-4cc5-9b2b-61845c5b423c	Hourly Driver Vikas	driver-hourly-1786266205899@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.9	2026-08-09 09:03:25.9
11d4f63d-9c03-42f4-9c8e-b00f02b44466	b3bd9148-5bcf-46c7-aae9-d07d688834ca	84932ba2-5347-4cc5-9b2b-61845c5b423c	Monthly Driver Sunil	driver-monthly-1786266205901@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.902	2026-08-09 09:03:25.902
9e4dea60-f36e-400e-a12d-829e8bb6c084	b3bd9148-5bcf-46c7-aae9-d07d688834ca	84932ba2-5347-4cc5-9b2b-61845c5b423c	Yearly Driver Amit	driver-yearly-1786266205904@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:03:25.904	2026-08-09 09:03:25.904
ecbf156d-5a65-4245-819b-99b784b28987	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786266207750	farmerA_1786266207750@example.com	\N	$2a$10$jTw.9KGuWlB5jDTKfOUAiOL.Nu/3TEyjY4ei2jJniCpgdyqJtPSgC	\N	ACTIVE	\N	2026-08-09 09:03:27.91	2026-08-09 09:03:27.91
6e253a09-09c5-4851-ba06-278fcd1868e0	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786266207750	farmerB_1786266207750@example.com	\N	$2a$10$sVdJ/VHE4qoJbi20JK9fgue7FML72.cqWBfDSWBe42fIqibiW6ibu	\N	ACTIVE	\N	2026-08-09 09:03:28.028	2026-08-09 09:03:28.028
1ab2e0e6-638e-445b-a32a-e51c5cb3a627	82d1d4f0-a664-4442-afb1-3c8e8deec8f8	6139daa9-c20e-47ee-9c25-9e49eca85344	Ramesh Patel	customer_a_1786266379295@example.com	9866379295	\N	\N	ACTIVE	2026-08-09 09:06:19.99	2026-08-09 09:06:19.94	2026-08-09 09:06:19.992
96b57699-b7b4-41a7-ac6d-9dd94a946280	0757faaa-e55d-4863-9e88-c738651afa4c	775fe76d-8f31-4bde-a3b5-9b6f78060f10	Manager Rajesh	manager-1786266385842@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.842	2026-08-09 09:06:25.842
ca19496d-cd8e-413d-86e4-2250ca84daa7	0757faaa-e55d-4863-9e88-c738651afa4c	2aac445f-9608-4cc6-8ec9-c559181a6b32	Farmer Ramesh	farmer-1786266385846@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.847	2026-08-09 09:06:25.847
871b4c6b-fc8c-4eb6-98cc-806d58383705	0757faaa-e55d-4863-9e88-c738651afa4c	2411e3d7-0fb3-4c87-b72b-ef39384319fb	Hourly Driver Vikas	driver-hourly-1786266385849@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.849	2026-08-09 09:06:25.849
c81e19bb-e3ec-4b60-bbf4-9c2b2c7029ad	0757faaa-e55d-4863-9e88-c738651afa4c	2411e3d7-0fb3-4c87-b72b-ef39384319fb	Monthly Driver Sunil	driver-monthly-1786266385852@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.853	2026-08-09 09:06:25.853
2940ccdb-8b42-4bb1-87eb-4efa17615db2	0757faaa-e55d-4863-9e88-c738651afa4c	2411e3d7-0fb3-4c87-b72b-ef39384319fb	Yearly Driver Amit	driver-yearly-1786266385854@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:06:25.855	2026-08-09 09:06:25.855
9da4dd60-708c-4173-8849-826b269a6eb7	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786266387848	farmerA_1786266387848@example.com	\N	$2a$10$QoVJ.ynOtmzf2exf5Y1ujuLDtfYff6wYmOMrzpMz6be2owgPugUbi	\N	ACTIVE	\N	2026-08-09 09:06:28.059	2026-08-09 09:06:28.059
14378809-2834-430c-a48a-a6b54d6516c2	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786266387848	farmerB_1786266387848@example.com	\N	$2a$10$sljMCQJS0ULy/cPH9OslO.26c3ZdHIms/HgohEGOtaxaaK2.ozdve	\N	ACTIVE	\N	2026-08-09 09:06:28.173	2026-08-09 09:06:28.173
7a5cb131-4d1b-4ae4-822b-840832188c6a	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786266395729	reset_owner_1786266395729@example.com	\N	$2a$10$X7s53r2Kf6ii7DxspE48POK2PId/BmYVLvAZfN7wSRZagos3L7dAS	$2a$10$5x5iCOH/d1CRcxhCaMcWLeBqdLnohErGw6ZABh/8spese6QD9wwc6	ACTIVE	2026-08-09 09:06:38.032	2026-08-09 09:06:35.931	2026-08-09 09:06:38.034
12117c2e-11f4-4f32-b96e-2afb05256e74	1e8cd6d1-17f8-44cb-aa98-227dbb4337ca	61c08b33-a61f-42da-bb0f-8f82c787becb	Vijay Singh	s4_user_a_1786266618997@example.com	9166618997	\N	\N	ACTIVE	2026-08-09 09:10:19.616	2026-08-09 09:10:19.565	2026-08-09 09:10:19.617
f5d6d9de-b8ad-43a9-95c2-5bc5b3d119d5	aeb2474e-c378-471b-ab64-81925a1bc912	a7f5ca56-4b5c-4e52-aabf-556add5cfdbe	Ramesh Patel	customer_a_1786266620795@example.com	9866620795	\N	\N	ACTIVE	2026-08-09 09:10:21.607	2026-08-09 09:10:21.554	2026-08-09 09:10:21.609
5fe2b5b8-d137-490e-920b-e323a6aa8f5e	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	cf5fcc70-58d2-4fae-825b-96bf593fdc2c	Manager Rajesh	manager-1786266627549@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.549	2026-08-09 09:10:27.549
4edfbe22-8080-4b10-96db-caa3a17bb7ee	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	f7bc5ca3-e88f-4c74-b510-1f657cf68d83	Farmer Ramesh	farmer-1786266627552@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.552	2026-08-09 09:10:27.552
8b024334-4a27-4d38-b587-d7e1afa3643d	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	39186c35-ea7a-4cb3-a9b7-03577d14e6c5	Hourly Driver Vikas	driver-hourly-1786266627554@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.554	2026-08-09 09:10:27.554
1ca775b5-3d6d-4ec9-88d5-2f22f4e963c8	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	39186c35-ea7a-4cb3-a9b7-03577d14e6c5	Monthly Driver Sunil	driver-monthly-1786266627556@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.557	2026-08-09 09:10:27.557
e8253196-3d1a-4b26-8b9c-2b82084a65f1	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	39186c35-ea7a-4cb3-a9b7-03577d14e6c5	Yearly Driver Amit	driver-yearly-1786266627558@test.com	\N	\N	\N	ACTIVE	\N	2026-08-09 09:10:27.559	2026-08-09 09:10:27.559
23041a8d-daa0-4e82-9317-51c813e311a5	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer A 1786266629477	farmerA_1786266629477@example.com	\N	$2a$10$xMZes2Hqvz1OG.3Vhaa6BeYrLPOm08kykoL3dKVo8M5Wx92Ow5RVS	\N	ACTIVE	\N	2026-08-09 09:10:29.624	2026-08-09 09:10:29.624
c0c24478-f3dd-4fca-b741-34cc76430fc1	29c82d91-d80e-4358-a180-dd5df8cae889	99290fff-bd48-4ba6-9df0-f9094411f12c	Farmer B 1786266629477	farmerB_1786266629477@example.com	\N	$2a$10$KYCdTxMylze/lcGk2/tnK.PCRXq6/XUoTS6/yy64/YScKriejy1H6	\N	ACTIVE	\N	2026-08-09 09:10:29.738	2026-08-09 09:10:29.738
e8801b4e-a320-4029-bbcc-d87ca2c10ca4	29c82d91-d80e-4358-a180-dd5df8cae889	f7f81fff-2392-479b-b4f2-d009056b0c2a	Test Reset Owner 1786266637089	reset_owner_1786266637089@example.com	\N	$2a$10$fyDUv6xg.ZczpW.svLlfeuUbKRl9087JaEZCm0kW.EbTTm6n6bH5i	$2a$10$wjKjalPxFO61Fka6liBj/erLFj5BWxoV0d2s5iLZrvg76.SSjdl0a	ACTIVE	2026-08-09 09:10:39.373	2026-08-09 09:10:37.282	2026-08-09 09:10:39.374
\.


--
-- Data for Name: villages; Type: TABLE DATA; Schema: public; Owner: shabooagri
--

COPY public.villages (id, company_id, name) FROM stdin;
a5a598af-0791-453b-8ce7-19e346b5ed67	655207e4-3278-43ad-862c-ded9ebab17ad	Village B 1786217560165
a202a13a-2f16-42e8-b3dd-8b5bfd5854da	cc2e54c0-2bba-40b8-a85a-28ae00aebbf5	Village Alpha 1786217563811
a10673b8-5c31-4173-a7de-c4fb65cf9ed8	a131ac13-2fcf-4978-b15d-625caa686889	Village B 1786217935613
8b485ab8-fd4f-4c80-827f-fb7a1448386d	3968e65b-4204-432c-ad93-26a831a79d3e	Village Alpha 1786217939195
ac5d1ed6-2862-4fdb-b080-397a412f43bb	32c8de26-7af9-42c6-ad11-7c29676eedef	Village B 1786218114338
278e7946-06ca-4111-81af-3852352dd65d	fbf2c4d6-447e-428e-af3b-6ac4c76204c1	Village Alpha 1786218117959
c452d00d-311c-4948-ad49-ed3f2fc76b34	f45447c4-0020-483d-b359-07f94c2c5f63	Village B 1786219462382
5d1e6b71-e380-4ffc-9171-dbec16359e6c	ecbba26c-b8ee-4455-a09e-86fab13778df	Village Alpha 1786219466039
8a887c2a-304b-467f-b484-96dd0317acf6	bf2044b6-c144-49f8-99ad-4c8b553c7bab	Village B 1786222379208
4c5c7805-d59e-4619-bb06-6894e92a6200	af0ff4c8-01da-4eaf-b558-e7c11e2daa7d	Village Alpha 1786222383378
5e5f9626-de91-44e6-aceb-f4b99963e0b0	40511429-f937-4f0f-8a0a-6869154b7144	Test Village Audit
1ec6ce3d-103d-4180-aedd-350c64ea226d	8fbaf386-5fd4-44cb-9119-9108a7c653c2	Beta Village 1786212275037
a526ffb4-06fc-4f98-9ad8-f94c3264ee94	1a1ead59-2b11-4f2a-85e5-71c30252fbab	Beta Village 1786212285428
01dd9cc2-cf05-4d0f-b9ab-04bbcbb22f33	c40dd20c-a216-4766-8dd3-db89037b4bc4	Beta Village 1786212295780
ce2a7e08-e1c3-418e-8059-72b172600737	24c5d7df-9154-40a6-a5a2-3c4ace5c31dc	Beta Village 1786212306832
8383bb42-c809-45fc-8a7c-48783821f67c	a6565866-d95e-4c4c-a2eb-76f3171c2907	Beta Village 1786212317057
98793a83-0a3b-4b0e-a702-18b016b066cc	2fc53fa9-07fd-4172-af37-6a1034df9ecb	Beta Village 1786212331132
96a02a8f-73c3-4d04-83d4-866c3c257409	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786253991202
57843258-bc6b-4965-9e26-9d7e813481a8	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786253997145
e32fdea7-8bfe-4de6-91c9-a990fb5aeb6d	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254005118
b2242270-ae26-4990-9a70-90a088825e77	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254015380
2f81339e-5dab-4d9e-8812-b5eaefb06cdb	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village Alpha 1786212891925
701c97fe-64af-4f1e-8ab5-258d9b55a779	a7ed8578-e3b6-4aec-91b1-214d09748c0e	Village Alpha 1786212898586
b8f7f8d7-b477-4160-b80e-f9294813fdb0	b51f455a-feb6-445f-8b08-8624162dc98b	Village Alpha 1786212907497
c98af7ca-0414-4c84-af7c-0297151be246	3b4fa961-b987-4207-bade-425969e8e1a5	Village Alpha 1786212915595
73656ab2-2173-46da-8944-532d5415fda6	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254034403
e23254ae-bb35-42b2-a708-ab1416f29dbb	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254046674
aa9bbd64-00c1-4d3b-8983-2e5df9912d77	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254053236
2ebca4ce-328f-4921-b644-d74b8e7dd8a7	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254061179
b2704e0f-319e-4ed7-9586-786d9069a0fb	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254075310
e2f0366d-60b5-44fc-90f6-5d2551a8b38a	c331e53c-fe17-49c2-97f1-9466a87bbe42	Village 1786254084415
3b6d3980-f22c-4054-a419-0aac2d98146a	023866d9-236a-41cc-a36f-b9e516720f54	Village Alpha 1786212942882
0b671c70-3cb9-4f0a-8f96-1e1900f9b5d0	024b72fd-44b2-4f38-96c1-78b156fa58c2	Village Alpha 1786213353408
427966af-2fd9-4754-ab40-80aab7b15d93	42adcdf6-7d43-4c6d-b2d8-23f43ae27208	Village Alpha 1786255035110
51ac0f4f-78b2-4bbb-8a96-0d1334f44760	f33c8ba7-f382-4217-90cf-d9d133632537	Village Alpha 1786213431673
62f47a22-3bb7-46a0-91b7-efd07d47743e	81a49a66-8a66-412a-baa0-0e6c9dbe9ee4	Village B 1786255047288
14cdcf24-a596-4b26-89b0-76b76a77f8e4	d8d7190c-b0f9-42e6-a510-8a401b035039	Sakhigopal
2d549ea5-d153-4d08-b460-465a6631e540	36bfd1b2-0ab4-4f49-a541-20c9e2c31271	Sakhigopal
935d7918-51f5-4e1e-8f02-a332962f56da	7a92e240-df0b-4c44-8bba-bd7574ae788b	Sakhigopal
50e72c1f-2888-407c-89e5-43e5b7d58a7e	8951aa6b-476b-46b7-b12b-de1998c8bbf7	Sakhigopal
3406cd08-5ee9-420e-a59b-d3e786e71e4c	d563fb11-8e19-4079-a843-4d579ba681ee	Sakhigopal
59a5ac9d-590a-48f7-a96f-c9ac07b1d62d	c329669f-35fe-4787-84c9-902251b14695	Village Alpha 1786214028920
db14b940-1fa2-4bc0-ab59-c42998f09b85	3decee45-30cb-44d3-aa82-9c76aaaf17f9	Village B 1786214823848
1ff9a0ce-ea77-4f87-ac75-76b9cbb68836	4f6de13b-a39b-41e2-a146-d0708f7f7d0e	Village Alpha 1786255284999
3bf7de50-c4bf-4012-ad2d-4c2634fa5241	0d649779-853e-4a6a-8293-0065b1d3244b	Village B 1786214834397
ac784502-de6a-43ca-bee1-5141ff8ff154	1f766620-668a-48de-8607-7683021a0a54	Village B 1786214839734
34a48422-6c9b-47c8-bc86-2240e7ab9a95	91a9917a-f0fd-4190-9e08-bdffb119b6a2	Village B 1786214848188
dd502489-c026-4ed2-a81d-0e0c19409b38	ecc55e3b-6b1a-438b-8ca4-e87e85c5ad18	Village B 1786214855482
494b7c2e-ee1a-41c9-ba9a-eff59c7ef6bf	bf778816-9b29-4799-8e98-12ad5e14f1cc	Village B 1786214863010
11bdc116-f852-478b-a2eb-88d406435f8b	00a648e6-059a-4f7c-8a0a-db23f4b72728	Village B 1786255296835
1c4b3c5c-bfd0-4a4e-affa-c3553ff8287a	8216654d-92e2-4c32-a802-59e105e5e231	Village B 1786214868737
442ddcd9-735f-4e9d-8c65-ef55f4303931	6571c3c9-9c94-4b02-ac20-829a9af731b6	Village Alpha 1786265102283
1d59fcd1-d99e-44ce-8daa-216c6e2fe4a8	f0681dbc-3b45-4e34-a013-3a3da6ef3a1a	Village Alpha 1786214899174
79ac0cf3-c7e6-4838-bbe2-24ccdb278eab	c8db4f1b-5092-4569-bea4-eaf2910c6faa	Village B 1786214902868
18aad780-2c2f-46f4-b038-ff2875d763f2	9e6118fb-f9a3-4475-bc22-65171cb0b8a9	Village B 1786265105884
2eb23ed9-6350-4df3-8c3a-88ded33f116f	4613e40d-bba4-424a-970e-ffc7836a19e2	Village Alpha 1786265278688
bd9a7330-3c1e-40d5-807c-84c188ceac0d	6a965ec6-8bec-4b37-abe7-fcc032b63905	Village B 1786265281066
72706676-33f5-48f6-875e-0e712950ce32	d6a5d93d-71b9-44f7-b69a-c04f12a160a5	Village Alpha 1786265621519
65ac3689-4bf7-4964-a3c7-933cc055d3f0	23d1d972-91e4-4bb1-a69d-fd78bc56e666	Village B 1786265623397
64873d6e-d33c-407e-8a77-9da3526a0e22	b3bd9148-5bcf-46c7-aae9-d07d688834ca	Village Alpha 1786266205906
fe590f22-5dd9-436b-818f-7e2510486cae	83a7bea6-85d2-46e7-a1e1-b6be122ead57	Village B 1786266207750
66cfcc20-703f-4d71-98da-651d29c33d2c	0757faaa-e55d-4863-9e88-c738651afa4c	Village Alpha 1786266385856
e5e1b240-1294-4236-a83a-754043ad2455	f029f473-5cf7-4e43-a467-53bf749c007f	Village B 1786266387848
6cf34412-8c6a-4c94-8830-f20679e57499	1b7b1871-7a21-4e8c-9861-e5dd11985e8f	Village Alpha 1786266627560
213c6915-962c-4622-bfa1-d090aeb001f7	e0d94522-f11b-4854-bc46-fbea888f97fe	Village B 1786266629477
0f9d8622-4e77-4c92-bbdb-4ab467522734	29c82d91-d80e-4358-a180-dd5df8cae889	Pricing Village 1786266633631
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: booking_attachments booking_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.booking_attachments
    ADD CONSTRAINT booking_attachments_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: contact_enquiries contact_enquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.contact_enquiries
    ADD CONSTRAINT contact_enquiries_pkey PRIMARY KEY (id);


--
-- Name: customer_feedbacks customer_feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.customer_feedbacks
    ADD CONSTRAINT customer_feedbacks_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: job_fuel_entries job_fuel_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_fuel_entries
    ADD CONSTRAINT job_fuel_entries_pkey PRIMARY KEY (id);


--
-- Name: job_photos job_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_photos
    ADD CONSTRAINT job_photos_pkey PRIMARY KEY (id);


--
-- Name: job_status_log job_status_log_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_status_log
    ADD CONSTRAINT job_status_log_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: licenses licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: machine_types machine_types_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.machine_types
    ADD CONSTRAINT machine_types_pkey PRIMARY KEY (id);


--
-- Name: machines machines_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.machines
    ADD CONSTRAINT machines_pkey PRIMARY KEY (id);


--
-- Name: maintenance_records maintenance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_pkey PRIMARY KEY (id);


--
-- Name: maintenance_schedules maintenance_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.maintenance_schedules
    ADD CONSTRAINT maintenance_schedules_pkey PRIMARY KEY (id);


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: pricing_methods pricing_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.pricing_methods
    ADD CONSTRAINT pricing_methods_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: saas_customer_profiles saas_customer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_customer_profiles
    ADD CONSTRAINT saas_customer_profiles_pkey PRIMARY KEY (id);


--
-- Name: saas_leads saas_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_leads
    ADD CONSTRAINT saas_leads_pkey PRIMARY KEY (id);


--
-- Name: saas_payments saas_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_payments
    ADD CONSTRAINT saas_payments_pkey PRIMARY KEY (id);


--
-- Name: saas_users saas_users_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_users
    ADD CONSTRAINT saas_users_pkey PRIMARY KEY (id);


--
-- Name: sso_tokens sso_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.sso_tokens
    ADD CONSTRAINT sso_tokens_pkey PRIMARY KEY (id);


--
-- Name: terminology_settings terminology_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.terminology_settings
    ADD CONSTRAINT terminology_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: villages villages_pkey; Type: CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT villages_pkey PRIMARY KEY (id);


--
-- Name: bookings_company_id_booking_number_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX bookings_company_id_booking_number_key ON public.bookings USING btree (company_id, booking_number);


--
-- Name: bookings_company_id_status_idx; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE INDEX bookings_company_id_status_idx ON public.bookings USING btree (company_id, status);


--
-- Name: companies_slug_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX companies_slug_key ON public.companies USING btree (slug);


--
-- Name: customers_user_id_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX customers_user_id_key ON public.customers USING btree (user_id);


--
-- Name: drivers_employee_id_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX drivers_employee_id_key ON public.drivers USING btree (employee_id);


--
-- Name: employees_user_id_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX employees_user_id_key ON public.employees USING btree (user_id);


--
-- Name: expense_categories_company_id_name_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX expense_categories_company_id_name_key ON public.expense_categories USING btree (company_id, name);


--
-- Name: invoices_booking_id_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX invoices_booking_id_key ON public.invoices USING btree (booking_id);


--
-- Name: invoices_company_id_invoice_number_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX invoices_company_id_invoice_number_key ON public.invoices USING btree (company_id, invoice_number);


--
-- Name: invoices_company_id_status_idx; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE INDEX invoices_company_id_status_idx ON public.invoices USING btree (company_id, status);


--
-- Name: jobs_booking_id_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX jobs_booking_id_key ON public.jobs USING btree (booking_id);


--
-- Name: jobs_company_id_status_idx; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE INDEX jobs_company_id_status_idx ON public.jobs USING btree (company_id, status);


--
-- Name: licenses_license_number_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX licenses_license_number_key ON public.licenses USING btree (license_number);


--
-- Name: licenses_payment_id_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX licenses_payment_id_key ON public.licenses USING btree (payment_id);


--
-- Name: machine_types_company_id_name_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX machine_types_company_id_name_key ON public.machine_types USING btree (company_id, name);


--
-- Name: machines_company_id_registration_number_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX machines_company_id_registration_number_key ON public.machines USING btree (company_id, registration_number);


--
-- Name: payments_invoice_id_idx; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE INDEX payments_invoice_id_idx ON public.payments USING btree (invoice_id);


--
-- Name: permissions_key_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX permissions_key_key ON public.permissions USING btree (key);


--
-- Name: pricing_methods_company_id_key_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX pricing_methods_company_id_key_key ON public.pricing_methods USING btree (company_id, key);


--
-- Name: roles_company_id_name_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX roles_company_id_name_key ON public.roles USING btree (company_id, name);


--
-- Name: saas_customer_profiles_saas_user_id_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX saas_customer_profiles_saas_user_id_key ON public.saas_customer_profiles USING btree (saas_user_id);


--
-- Name: saas_users_email_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX saas_users_email_key ON public.saas_users USING btree (email);


--
-- Name: sso_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX sso_tokens_token_hash_key ON public.sso_tokens USING btree (token_hash);


--
-- Name: terminology_settings_company_id_term_key_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX terminology_settings_company_id_term_key_key ON public.terminology_settings USING btree (company_id, term_key);


--
-- Name: users_company_id_email_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX users_company_id_email_key ON public.users USING btree (company_id, email);


--
-- Name: users_company_id_mobile_number_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX users_company_id_mobile_number_key ON public.users USING btree (company_id, mobile_number);


--
-- Name: villages_company_id_name_key; Type: INDEX; Schema: public; Owner: shabooagri
--

CREATE UNIQUE INDEX villages_company_id_name_key ON public.villages USING btree (company_id, name);


--
-- Name: audit_log audit_log_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_log audit_log_saas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_saas_user_id_fkey FOREIGN KEY (saas_user_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: booking_attachments booking_attachments_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.booking_attachments
    ADD CONSTRAINT booking_attachments_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: booking_attachments booking_attachments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.booking_attachments
    ADD CONSTRAINT booking_attachments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: booking_attachments booking_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.booking_attachments
    ADD CONSTRAINT booking_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bookings bookings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bookings bookings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bookings bookings_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bookings bookings_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bookings bookings_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bookings bookings_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bookings bookings_pricing_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pricing_method_id_fkey FOREIGN KEY (pricing_method_id) REFERENCES public.pricing_methods(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bookings bookings_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.villages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contact_enquiries contact_enquiries_assigned_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.contact_enquiries
    ADD CONSTRAINT contact_enquiries_assigned_admin_id_fkey FOREIGN KEY (assigned_admin_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_feedbacks customer_feedbacks_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.customer_feedbacks
    ADD CONSTRAINT customer_feedbacks_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_feedbacks customer_feedbacks_saas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.customer_feedbacks
    ADD CONSTRAINT customer_feedbacks_saas_user_id_fkey FOREIGN KEY (saas_user_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customers customers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customers customers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customers customers_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.villages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: drivers drivers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: drivers drivers_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: employees employees_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expense_categories expense_categories_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: expenses expenses_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.expense_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: expenses expenses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: expenses expenses_incurred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_incurred_by_fkey FOREIGN KEY (incurred_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: expenses expenses_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_fuel_entries job_fuel_entries_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_fuel_entries
    ADD CONSTRAINT job_fuel_entries_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_fuel_entries job_fuel_entries_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_fuel_entries
    ADD CONSTRAINT job_fuel_entries_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_fuel_entries job_fuel_entries_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_fuel_entries
    ADD CONSTRAINT job_fuel_entries_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_fuel_entries job_fuel_entries_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_fuel_entries
    ADD CONSTRAINT job_fuel_entries_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_photos job_photos_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_photos
    ADD CONSTRAINT job_photos_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_photos job_photos_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_photos
    ADD CONSTRAINT job_photos_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_photos job_photos_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_photos
    ADD CONSTRAINT job_photos_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_status_log job_status_log_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_status_log
    ADD CONSTRAINT job_status_log_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_status_log job_status_log_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_status_log
    ADD CONSTRAINT job_status_log_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: job_status_log job_status_log_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.job_status_log
    ADD CONSTRAINT job_status_log_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: jobs jobs_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: jobs jobs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: jobs jobs_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: jobs jobs_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: licenses licenses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: licenses licenses_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.saas_payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: licenses licenses_saas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_saas_user_id_fkey FOREIGN KEY (saas_user_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: machine_types machine_types_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.machine_types
    ADD CONSTRAINT machine_types_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: machines machines_assigned_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.machines
    ADD CONSTRAINT machines_assigned_driver_id_fkey FOREIGN KEY (assigned_driver_id) REFERENCES public.drivers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: machines machines_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.machines
    ADD CONSTRAINT machines_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: machines machines_machine_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.machines
    ADD CONSTRAINT machines_machine_type_id_fkey FOREIGN KEY (machine_type_id) REFERENCES public.machine_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: maintenance_records maintenance_records_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: maintenance_records maintenance_records_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: maintenance_records maintenance_records_maintenance_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_maintenance_schedule_id_fkey FOREIGN KEY (maintenance_schedule_id) REFERENCES public.maintenance_schedules(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: maintenance_schedules maintenance_schedules_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.maintenance_schedules
    ADD CONSTRAINT maintenance_schedules_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: maintenance_schedules maintenance_schedules_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.maintenance_schedules
    ADD CONSTRAINT maintenance_schedules_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_received_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_received_by_fkey FOREIGN KEY (received_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pricing_methods pricing_methods_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.pricing_methods
    ADD CONSTRAINT pricing_methods_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: roles roles_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: saas_customer_profiles saas_customer_profiles_saas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_customer_profiles
    ADD CONSTRAINT saas_customer_profiles_saas_user_id_fkey FOREIGN KEY (saas_user_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: saas_leads saas_leads_assigned_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_leads
    ADD CONSTRAINT saas_leads_assigned_admin_id_fkey FOREIGN KEY (assigned_admin_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: saas_leads saas_leads_created_by_saas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_leads
    ADD CONSTRAINT saas_leads_created_by_saas_user_id_fkey FOREIGN KEY (created_by_saas_user_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: saas_payments saas_payments_saas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.saas_payments
    ADD CONSTRAINT saas_payments_saas_user_id_fkey FOREIGN KEY (saas_user_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sso_tokens sso_tokens_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.sso_tokens
    ADD CONSTRAINT sso_tokens_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sso_tokens sso_tokens_saas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.sso_tokens
    ADD CONSTRAINT sso_tokens_saas_user_id_fkey FOREIGN KEY (saas_user_id) REFERENCES public.saas_users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sso_tokens sso_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.sso_tokens
    ADD CONSTRAINT sso_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: terminology_settings terminology_settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.terminology_settings
    ADD CONSTRAINT terminology_settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users users_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: villages villages_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: shabooagri
--

ALTER TABLE ONLY public.villages
    ADD CONSTRAINT villages_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict jNvvFfsAMaCrqyy0hjZwcIbKuDF4qiPpKBhMNJUfUdSdGcVBb5FQ9txXun5ZLl8

